<?php
/**
 * NFC Card Redirect
 * URL: /card.php?id=123
 * Redirects to the user's profile page
 */
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$cardId = sanitize($_GET['id'] ?? '');

if (!$cardId) {
    redirect(BASE_URL . '/');
}

$stmt = $pdo->prepare("SELECT u.username FROM cards c JOIN users u ON c.user_id = u.id WHERE c.card_uid = ? AND c.is_active = 1");
$stmt->execute([$cardId]);
$row = $stmt->fetch();

if ($row) {
    redirect(BASE_URL . '/' . urlencode($row['username']) . '?src=nfc');
} else {
    // Card not assigned or not found
    redirect(BASE_URL . '/?card=notfound');
}
