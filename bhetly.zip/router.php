<?php
/**
 * router.php — Profile URL Router
 * Handles both short /:username and legacy /u/:username paths.
 * Called from .htaccess.
 */
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

// Username may come from GET param (set by .htaccess RewriteRule)
$username = sanitize($_GET['username'] ?? '');

// Fallback: parse from URI for /u/username legacy paths
if (!$username) {
    $uri = $_SERVER['REQUEST_URI'];
    preg_match('#/(?:u/)?([a-zA-Z0-9_-]+)#', $uri, $m);
    $username = isset($m[1]) ? sanitize($m[1]) : '';
}

if ($username) {
    $_GET['username'] = $username;
    include __DIR__ . '/u.php';
} else {
    redirect(BASE_URL . '/');
}
