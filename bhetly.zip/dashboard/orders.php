<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$user = getCurrentUser();

if (!isPro()) {
    setFlash('danger', 'Order management is available for Pro users only. Please upgrade your plan.');
    redirect(BASE_URL . '/dashboard/subscription');
}

$uid = $_SESSION['user_id'];

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action   = $_POST['action'] ?? '';
    $orderId  = (int)($_POST['order_id'] ?? 0);

    if ($action === 'update_status' && $orderId > 0) {
        $newStatus = $_POST['status'] ?? '';
        $allowed   = ['pending','confirmed','processing','shipped','delivered','cancelled'];
        if (in_array($newStatus, $allowed)) {
            $pdo->prepare("UPDATE product_orders SET status=? WHERE id=? AND seller_user_id=?")
                ->execute([$newStatus, $orderId, $uid]);
            setFlash('success', 'Order status updated.');
        }
    } elseif ($action === 'delete' && $orderId > 0) {
        $pdo->prepare("DELETE FROM product_orders WHERE id=? AND seller_user_id=?")->execute([$orderId, $uid]);
        setFlash('success', 'Order removed.');
    }
    redirect(BASE_URL . '/dashboard/orders');
}

// Filters
$statusFilter = $_GET['status'] ?? 'all';
$search       = trim($_GET['q'] ?? '');

$where = "po.seller_user_id = ?";
$params = [$uid];

if ($statusFilter !== 'all') {
    $where  .= " AND po.status = ?";
    $params[] = $statusFilter;
}
if ($search !== '') {
    $where  .= " AND (po.buyer_name LIKE ? OR po.buyer_phone LIKE ? OR p.name LIKE ?)";
    $like     = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$stmt = $pdo->prepare("
    SELECT po.*, p.name AS product_name, p.image_path AS product_image
    FROM product_orders po
    JOIN products p ON p.id = po.product_id
    WHERE $where
    ORDER BY po.created_at DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Summary counts
$counts = $pdo->prepare("
    SELECT status, COUNT(*) as cnt
    FROM product_orders
    WHERE seller_user_id = ?
    GROUP BY status
");
$counts->execute([$uid]);
$statusCounts = [];
foreach ($counts->fetchAll() as $row) {
    $statusCounts[$row['status']] = $row['cnt'];
}
$totalOrders   = array_sum($statusCounts);
$pendingOrders = $statusCounts['pending'] ?? 0;

include __DIR__ . '/../includes/header.php';
?>

<style>
/* ===== ORDERS PAGE STYLES ===== */
.ord-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
  padding: 0.25rem 0.65rem;
  border-radius: 50px;
  font-size: 0.72rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.ord-pending    { background: rgba(255,181,71,0.15);   color: #e6a020; }
.ord-confirmed  { background: rgba(67,217,180,0.15);   color: #2bb59e; }
.ord-processing { background: rgba(108,99,255,0.15);   color: #6C63FF; }
.ord-shipped    { background: rgba(79,195,247,0.15);   color: #0288d1; }
.ord-delivered  { background: rgba(67,217,180,0.18);   color: #16a34a; }
.ord-cancelled  { background: rgba(255,101,132,0.15);  color: #dc3545; }

.ord-stat-row {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.ord-stat {
  background: var(--card-bg);
  border: 1px solid var(--border-color);
  border-radius: 14px;
  padding: 1rem 1.25rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
  transition: all 0.2s;
  text-decoration: none;
  color: inherit;
}
.ord-stat:hover, .ord-stat.active {
  border-color: var(--primary);
  box-shadow: 0 4px 16px rgba(15,76,129,0.12);
  color: inherit;
}
.ord-stat-icon {
  width: 40px;
  height: 40px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  flex-shrink: 0;
}
.ord-stat-num {
  font-size: 1.4rem;
  font-weight: 900;
  line-height: 1;
}
.ord-stat-label {
  font-size: 0.72rem;
  color: var(--text-muted);
  margin-top: 0.15rem;
}

.ord-filter-bar {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
  align-items: center;
  margin-bottom: 1rem;
}
.ord-filter-btn {
  padding: 0.4rem 0.9rem;
  border-radius: 50px;
  border: 1px solid var(--border-color);
  background: none;
  font-size: 0.8rem;
  font-weight: 600;
  cursor: pointer;
  color: var(--text-muted);
  transition: all 0.2s;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}
.ord-filter-btn:hover, .ord-filter-btn.active {
  background: var(--primary);
  border-color: var(--primary);
  color: white;
}
.ord-search {
  flex: 1;
  min-width: 200px;
  display: flex;
  gap: 0.5rem;
}
.ord-search input {
  flex: 1;
  padding: 0.5rem 1rem;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  font-size: 0.875rem;
  background: var(--card-bg);
  color: var(--text-primary);
  outline: none;
}
.ord-search input:focus { border-color: var(--primary); }

/* Order cards on mobile */
.ord-card {
  background: var(--card-bg);
  border: 1px solid var(--border-color);
  border-radius: 14px;
  padding: 1.1rem 1.25rem;
  margin-bottom: 0.9rem;
  transition: all 0.2s;
}
.ord-card:hover {
  border-color: rgba(108,99,255,0.3);
  box-shadow: 0 4px 16px rgba(0,0,0,0.07);
}
.ord-card-top {
  display: flex;
  align-items: flex-start;
  gap: 0.9rem;
  margin-bottom: 0.75rem;
}
.ord-product-thumb {
  width: 52px;
  height: 52px;
  border-radius: 10px;
  object-fit: cover;
  flex-shrink: 0;
  background: rgba(108,99,255,0.08);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  color: var(--primary);
  overflow: hidden;
}
.ord-product-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ord-card-meta {
  flex: 1;
  min-width: 0;
}
.ord-product-title {
  font-weight: 700;
  font-size: 0.95rem;
  margin-bottom: 0.15rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ord-buyer-info {
  font-size: 0.82rem;
  color: var(--text-secondary);
}
.ord-card-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  flex-wrap: wrap;
}
.ord-price {
  font-weight: 800;
  font-size: 1rem;
  color: var(--primary);
}
.ord-qty {
  font-size: 0.78rem;
  color: var(--text-muted);
  margin-top: 0.1rem;
}
.ord-actions {
  display: flex;
  gap: 0.4rem;
  align-items: center;
}
.ord-select {
  padding: 0.35rem 0.6rem;
  border-radius: 6px;
  border: 1px solid var(--border-color);
  font-size: 0.78rem;
  background: var(--card-bg);
  color: var(--text-primary);
  cursor: pointer;
}

@media(max-width:600px) {
  .ord-card-top { gap: 0.6rem; }
  .ord-product-thumb { width: 44px; height: 44px; }
}
</style>

<div class="page-content">
  <!-- Page Header -->
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
    <div>
      <h2 class="page-title">
        Order Management
      </h2>
      <p class="page-subtitle">View and manage customer orders for your products & services.</p>
    </div>
    <a href="<?= BASE_URL ?>/dashboard/products" class="btn btn-secondary btn-sm">
      <i class="fas fa-box-open"></i> Manage Products
    </a>
  </div>

  <!-- Summary Stats -->
  <div class="ord-stat-row">
    <a href="?status=all" class="ord-stat <?= $statusFilter === 'all' ? 'active' : '' ?>">
      <div class="ord-stat-icon" style="background:rgba(108,99,255,0.12);color:#6C63FF;">
        <i class="fas fa-shopping-bag"></i>
      </div>
      <div>
        <div class="ord-stat-num"><?= $totalOrders ?></div>
        <div class="ord-stat-label">All Orders</div>
      </div>
    </a>
    <a href="?status=pending" class="ord-stat <?= $statusFilter === 'pending' ? 'active' : '' ?>">
      <div class="ord-stat-icon" style="background:rgba(255,181,71,0.12);color:#e6a020;">
        <i class="fas fa-clock"></i>
      </div>
      <div>
        <div class="ord-stat-num"><?= $statusCounts['pending'] ?? 0 ?></div>
        <div class="ord-stat-label">Pending</div>
      </div>
    </a>
    <a href="?status=confirmed" class="ord-stat <?= $statusFilter === 'confirmed' ? 'active' : '' ?>">
      <div class="ord-stat-icon" style="background:rgba(67,217,180,0.12);color:#2bb59e;">
        <i class="fas fa-check-circle"></i>
      </div>
      <div>
        <div class="ord-stat-num"><?= $statusCounts['confirmed'] ?? 0 ?></div>
        <div class="ord-stat-label">Confirmed</div>
      </div>
    </a>
    <a href="?status=delivered" class="ord-stat <?= $statusFilter === 'delivered' ? 'active' : '' ?>">
      <div class="ord-stat-icon" style="background:rgba(22,163,74,0.12);color:#16a34a;">
        <i class="fas fa-box-check"></i>
      </div>
      <div>
        <div class="ord-stat-num"><?= $statusCounts['delivered'] ?? 0 ?></div>
        <div class="ord-stat-label">Delivered</div>
      </div>
    </a>
    <a href="?status=cancelled" class="ord-stat <?= $statusFilter === 'cancelled' ? 'active' : '' ?>">
      <div class="ord-stat-icon" style="background:rgba(255,101,132,0.12);color:#dc3545;">
        <i class="fas fa-times-circle"></i>
      </div>
      <div>
        <div class="ord-stat-num"><?= $statusCounts['cancelled'] ?? 0 ?></div>
        <div class="ord-stat-label">Cancelled</div>
      </div>
    </a>
  </div>

  <div class="card-box">
    <!-- Filter Bar -->
    <div class="ord-filter-bar">
      <div class="ord-search">
        <form method="GET" style="display:flex;gap:0.5rem;width:100%;">
          <?php if ($statusFilter !== 'all'): ?>
          <input type="hidden" name="status" value="<?= htmlspecialchars($statusFilter) ?>">
          <?php endif; ?>
          <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                 placeholder="Search by buyer, phone or product…" id="ordSearchInput">
          <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
          <?php if ($search): ?>
          <a href="?status=<?= urlencode($statusFilter) ?>" class="btn btn-secondary btn-sm">Clear</a>
          <?php endif; ?>
        </form>
      </div>
    </div>

    <!-- Orders -->
    <?php if (empty($orders)): ?>
    <div style="text-align:center;padding:4rem 2rem;">
      <div style="font-size:3.5rem;margin-bottom:1rem;">📦</div>
      <h3 style="font-size:1.2rem;font-weight:800;margin-bottom:0.5rem;">
        <?= $statusFilter !== 'all' || $search ? 'No matching orders' : 'No Orders Yet' ?>
      </h3>
      <p style="color:var(--text-secondary);max-width:380px;margin:0 auto 1.5rem;">
        <?= $statusFilter !== 'all' || $search
            ? 'Try a different filter or search term.'
            : 'When customers place orders from your profile, they will appear here.' ?>
      </p>
      <?php if ($search || $statusFilter !== 'all'): ?>
      <a href="?" class="btn btn-secondary btn-sm">View All Orders</a>
      <?php endif; ?>
    </div>

    <?php else: ?>
    <?php foreach ($orders as $o):
      $statusClass = 'ord-' . $o['status'];
      $statusLabel = ucfirst($o['status']);
    ?>
    <div class="ord-card" id="order-<?= $o['id'] ?>">
      <div class="ord-card-top">
        <!-- Product Thumbnail -->
        <div class="ord-product-thumb">
          <?php if ($o['product_image']): ?>
          <img src="<?= UPLOAD_URL ?>products/<?= htmlspecialchars($o['product_image']) ?>"
               alt="<?= htmlspecialchars($o['product_name']) ?>">
          <?php else: ?>
          <i class="fas fa-box-open"></i>
          <?php endif; ?>
        </div>

        <div class="ord-card-meta">
          <div class="ord-product-title"><?= htmlspecialchars($o['product_name']) ?></div>
          <div class="ord-buyer-info">
            <strong><?= htmlspecialchars($o['buyer_name']) ?></strong>
            <?php if ($o['buyer_phone']): ?>
            · <a href="tel:<?= htmlspecialchars($o['buyer_phone']) ?>" style="color:inherit;"><?= htmlspecialchars($o['buyer_phone']) ?></a>
            <?php endif; ?>
            <?php if ($o['buyer_email']): ?>
            · <a href="mailto:<?= htmlspecialchars($o['buyer_email']) ?>" style="color:inherit;"><?= htmlspecialchars($o['buyer_email']) ?></a>
            <?php endif; ?>
          </div>
          <?php if ($o['note']): ?>
          <div style="font-size:0.78rem;color:var(--text-muted);margin-top:0.25rem;font-style:italic;">
            "<?= htmlspecialchars(mb_substr($o['note'], 0, 100)) ?><?= mb_strlen($o['note']) > 100 ? '…' : '' ?>"
          </div>
          <?php endif; ?>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.2rem;">
            <i class="fas fa-calendar" style="font-size:0.65rem;"></i>
            <?= date('M d, Y · h:i A', strtotime($o['created_at'])) ?>
          </div>
        </div>

        <span class="ord-badge <?= $statusClass ?>">
          <?= $statusLabel ?>
        </span>
      </div>

      <div class="ord-card-bottom">
        <div>
          <div class="ord-price">Rs. <?= number_format($o['total_price'], 0) ?></div>
          <div class="ord-qty">Qty: <?= $o['quantity'] ?> × Rs. <?= number_format($o['unit_price'], 0) ?></div>
        </div>

        <div class="ord-actions">
          <form method="POST" style="display:flex;gap:0.4rem;align-items:center;">
            <input type="hidden" name="action" value="update_status">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <select name="status" class="ord-select" onchange="this.form.submit()" title="Change Status">
              <?php foreach (['pending','confirmed','processing','shipped','delivered','cancelled'] as $s): ?>
              <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </form>
          <form method="POST" onsubmit="return confirm('Remove this order permanently?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete Order">
              <i class="fas fa-trash"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
