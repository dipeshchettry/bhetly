﻿<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
$isGetConfirm = $_SERVER['REQUEST_METHOD'] === 'GET' && (($_GET['confirm'] ?? '') === '1');

if (!$isPost && !$isGetConfirm) {
    redirect(BASE_URL . '/dashboard/settings');
}

$userId = (int) ($_SESSION['user_id'] ?? 0);
$confirmValue = $isPost ? ($_POST['confirm_delete'] ?? '') : 'DELETE';
$confirm = strtoupper(trim($confirmValue ?: 'DELETE'));

$userStmt = $pdo->prepare('SELECT name, email FROM users WHERE id = ? LIMIT 1');
$userStmt->execute([$userId]);
$user = $userStmt->fetch();

if ($confirm !== 'DELETE') {
    setFlash('error', 'Please type DELETE to confirm account deletion.');
    redirect(BASE_URL . '/dashboard/settings');
}

try {
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
    $stmt->execute([$userId]);

    if ($stmt->rowCount() < 1) {
        setFlash('error', 'Account not found or already deleted.');
        redirect(BASE_URL . '/dashboard/settings');
    }

    if ($user && !empty($user['email'])) {
        // Best effort only; deletion should not fail because of email issues.
        sendAccountDeletedEmail($user['name'] ?? 'User', $user['email']);
    }

    session_unset();
    session_destroy();
    redirect(BASE_URL . '/?deleted=1');
} catch (Throwable $e) {
    setFlash('error', 'Unable to delete account right now: ' . $e->getMessage());
    redirect(BASE_URL . '/dashboard/settings');
}
