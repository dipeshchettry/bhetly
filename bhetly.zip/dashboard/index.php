<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$user = getCurrentUser();
$stats = getAnalyticsSummary($_SESSION['user_id']);

// Total link clicks
$stmt = $pdo->prepare("SELECT SUM(click_count) as total FROM social_links WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$clicks = $stmt->fetch()['total'] ?? 0;

// Chart data - last 14 days
$chartData = $pdo->prepare("SELECT visit_date, SUM(visit_count) as cnt FROM analytics WHERE user_id = ? AND visit_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) GROUP BY visit_date ORDER BY visit_date ASC");
$chartData->execute([$_SESSION['user_id']]);
$rows = $chartData->fetchAll();

$labels = []; $values = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $labels[] = date('M d', strtotime($d));
    $found = array_filter($rows, fn($r) => $r['visit_date'] === $d);
    $values[] = !empty($found) ? array_values($found)[0]['cnt'] : 0;
}

// Recent visitors device breakdown
$devices = $pdo->prepare("SELECT device_type, SUM(visit_count) as cnt FROM analytics WHERE user_id = ? AND visit_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY device_type");
$devices->execute([$_SESSION['user_id']]);
$deviceData = $devices->fetchAll();

$profileUrl = BASE_URL . '/' . $user['username'];
include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Welcome back, <?= htmlspecialchars(explode(' ', $user['name'])[0]) ?></h2>
    <p class="page-subtitle">Here's what's happening with your digital card today</p>
  </div>

  <!-- Stat Cards -->
  <div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
      <div class="stat-card" style="--stat-color:#6C63FF;">
        <div class="stat-icon" style="background:rgba(108,99,255,0.15);color:#6C63FF;"><i class="fas fa-eye"></i></div>
        <div class="stat-value"><?= number_format($stats['total'] ?? 0) ?></div>
        <div class="stat-label">Total Profile Views</div>
      </div>
    </div>
    <div class="col-sm-6 col-xl-3">
      <div class="stat-card" style="--stat-color:#43D9B4;">
        <div class="stat-icon" style="background:rgba(67,217,180,0.15);color:#43D9B4;"><i class="fas fa-calendar-day"></i></div>
        <div class="stat-value"><?= number_format($stats['today'] ?? 0) ?></div>
        <div class="stat-label">Views Today</div>
      </div>
    </div>
    <div class="col-sm-6 col-xl-3">
      <div class="stat-card" style="--stat-color:#FFB547;">
        <div class="stat-icon" style="background:rgba(255,181,71,0.15);color:#FFB547;"><i class="fas fa-mouse-pointer"></i></div>
        <div class="stat-value"><?= number_format($clicks) ?></div>
        <div class="stat-label">Total Link Clicks</div>
      </div>
    </div>
    <div class="col-sm-6 col-xl-3">
      <div class="stat-card" style="--stat-color:#FF6584;">
        <div class="stat-icon" style="background:rgba(255,101,132,0.15);color:#FF6584;"><i class="fas fa-calendar-week"></i></div>
        <div class="stat-value"><?= number_format($stats['week'] ?? 0) ?></div>
        <div class="stat-label">Views This Week</div>
      </div>
    </div>
  </div>

  <div class="row g-3">
    <!-- Chart -->
    <div class="col-lg-8">
      <div class="card-box">
        <div class="card-box-header">
          <span class="card-box-title">Profile Views (Last 14 Days)</span>
          <span style="font-size:0.8rem;color:var(--text-muted);">Daily breakdown</span>
        </div>
        <div class="chart-container">
          <canvas id="visitChart"
            data-labels='<?= json_encode($labels) ?>'
            data-values='<?= json_encode($values) ?>'>
          </canvas>
        </div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="col-lg-4">
      <div class="card-box">
        <div class="card-box-header">
          <span class="card-box-title">Your Digital Card</span>
        </div>
        <div class="qr-wrapper mb-3" style="display:block;max-width:180px;margin:0 auto 1rem;">
          <img src="<?= generateQR($profileUrl, 180) ?>" alt="QR Code" style="width:100%;border-radius:8px;">
        </div>
        <div style="font-size:0.82rem;color:var(--text-muted);text-align:center;margin-bottom:1rem;word-break:break-all;"><?= $profileUrl ?></div>
        <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
          <a href="<?= $profileUrl ?>" target="_blank" class="btn btn-primary btn-sm" style="flex:1;justify-content:center;"><i class="fas fa-external-link-alt"></i> View</a>
          <button class="btn btn-secondary btn-sm" style="flex:1;justify-content:center;" data-copy="<?= $profileUrl ?>"><i class="fas fa-copy"></i> Copy</button>
          <a href="<?= BASE_URL ?>/api/download_qr" class="btn btn-secondary btn-sm" style="flex:1;justify-content:center;" title="Download QR Code"><i class="fas fa-download"></i> Download</a>
        </div>
      </div>

      <!-- Device Breakdown -->
      <?php if (!empty($deviceData)): ?>
      <div class="card-box">
        <div class="card-box-header"><span class="card-box-title">Device Types</span></div>
        <?php foreach ($deviceData as $d): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.75rem;">
          <span style="font-size:0.85rem;display:flex;align-items:center;gap:0.5rem;">
            <i class="fas fa-<?= $d['device_type'] === 'mobile' ? 'mobile-alt' : ($d['device_type'] === 'tablet' ? 'tablet-alt' : 'desktop') ?>" style="color:var(--primary);width:18px;"></i>
            <?= ucfirst($d['device_type']) ?>
          </span>
          <span class="badge badge-info"><?= $d['cnt'] ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
