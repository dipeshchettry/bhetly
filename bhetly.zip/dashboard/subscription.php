﻿<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$userId = $_SESSION['user_id'];

// Handle subscription submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $method = sanitize($_POST['payment_method'] ?? '');
  $txnId = sanitize($_POST['transaction_id'] ?? '');
  $screenshotFile = $_FILES['screenshot'] ?? null;

  if (!in_array($method, ['esewa', 'khalti'])) {
    setFlash('error', 'Invalid payment method.');
    redirect(BASE_URL . '/dashboard/subscription');
  }

  $screenshotPath = null;
  if ($screenshotFile && $screenshotFile['error'] === UPLOAD_ERR_OK) {
    $result = uploadFile($screenshotFile, 'payments');
    if (isset($result['error'])) {
      setFlash('error', $result['error']);
      redirect(BASE_URL . '/dashboard/subscription');
    }
    $screenshotPath = $result['filename'];
  } else {
    setFlash('error', 'Please upload payment screenshot.');
    redirect(BASE_URL . '/dashboard/subscription');
  }

  // Insert or update subscription
  $pdo->prepare("INSERT INTO subscriptions (user_id, plan, payment_method, transaction_id, screenshot_path, amount, status)
        VALUES (?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE payment_method=?, transaction_id=?, screenshot_path=?, amount=?, status='pending', updated_at=NOW()")
    ->execute([$userId, 'pro', $method, $txnId, $screenshotPath, PRO_PRICE, 'pending', $method, $txnId, $screenshotPath, PRO_PRICE]);

  setFlash('success', 'Payment submitted! Admin will verify and activate your Pro plan within 24 hours.');
  redirect(BASE_URL . '/dashboard/subscription');
}

// Current subscription
$sub = $pdo->prepare("SELECT * FROM subscriptions WHERE user_id = ?");
$sub->execute([$userId]);
$sub = $sub->fetch();

$user = getCurrentUser();
include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Subscription</h2>
    <p class="page-subtitle">Manage your plan and unlock premium features</p>
  </div>

  <!-- Current Status -->
  <div class="card-box mb-4">
    <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
      <div
        style="width:56px;height:56px;border-radius:16px;background:<?= isPro($userId) ? 'rgba(255,181,71,0.15)' : 'rgba(108,99,255,0.15)' ?>;display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:<?= isPro($userId) ? '#FFB547' : 'var(--primary)' ?>;">
        <i class="fas fa-<?= isPro($userId) ? 'crown' : 'user' ?>"></i>
      </div>
      <div>
        <div style="font-size:1.2rem;font-weight:700;"><?= isPro($userId) ? 'Pro Plan' : 'Free Plan' ?></div>
        <div style="color:var(--text-secondary);font-size:0.85rem;">
          <?php if ($sub): ?>
            Status: <span
              class="badge badge-<?= $sub['status'] === 'approved' ? 'success' : ($sub['status'] === 'pending' ? 'warning' : 'danger') ?>"><?= ucfirst($sub['status']) ?></span>
          <?php else: ?>Current active plan<?php endif; ?>
        </div>
      </div>
      <?php if ($sub && $sub['status'] === 'pending'): ?>
        <div style="margin-left:auto;"><span class="badge badge-warning"><i class="fas fa-clock"></i> Verification
            Pending</span></div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Plans -->
  <div class="row g-3 mb-4">
    <div class="col-md-6">
      <div class="sub-card <?= !isPro($userId) ? 'active' : '' ?>">
        <div style="font-size:1rem;font-weight:700;margin-bottom:0.5rem;">Free Plan</div>
        <div class="price-tag">Free <span>/forever</span></div>
        <ul class="pricing-features">
          <li><i class="fas fa-check"></i> 2 social links</li>
          <li><i class="fas fa-check"></i> Public profile page</li>
          <li><i class="fas fa-check"></i> QR code</li>
          <li><i class="fas fa-check"></i> Basic profile</li>
          <li><i class="fas fa-times" style="color:var(--danger);"></i> Analytics</li>
          <li><i class="fas fa-times" style="color:var(--danger);"></i> Custom themes</li>
          <li><i class="fas fa-times" style="color:var(--danger);"></i> Portfolio</li>
        </ul>
        <?php if (!isPro($userId)): ?>
          <div style="color:var(--accent);font-weight:600;"><i class="fas fa-check-circle"></i> Current Plan</div>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-md-6">
      <div class="sub-card <?= isPro($userId) ? 'active' : '' ?>"
        style="border-color:<?= isPro($userId) ? 'var(--primary)' : '#FFB547' ?>;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="font-size:1rem;font-weight:700;">Pro Plan</div>
          <span
            style="padding:0.25rem 0.75rem;background:linear-gradient(135deg,rgba(255,181,71,0.2),rgba(255,140,0,0.2));border:1px solid rgba(255,181,71,0.3);color:#FFB547;border-radius:50px;font-size:0.75rem;font-weight:700;"><i
              class="fas fa-fire"></i> Popular</span>
        </div>
        <div class="price-tag">Rs <?= number_format(PRO_PRICE) ?> <span>/year</span></div>
        <ul class="pricing-features">
          <li><i class="fas fa-check"></i> Unlimited links</li>
          <li><i class="fas fa-check"></i> Full analytics</li>
          <li><i class="fas fa-check"></i> Custom themes & colors</li>
          <li><i class="fas fa-check"></i> Portfolio section</li>
          <li><i class="fas fa-check"></i> Download vCard</li>
          <li><i class="fas fa-check"></i> Priority support</li>
          <li><i class="fas fa-check"></i> NFC card management</li>
          <?php if (isPro($userId)): ?>
            <div style="color:var(--accent);font-weight:600;margin-bottom:0.5rem;"><i class="fas fa-check-circle"></i>
              Current Plan</div>
            <?php if ($sub && $sub['admin_message']): ?>
              <div
                style="background:rgba(96, 187, 70, 0.1);color:#3d7a2e;padding:0.75rem;border-radius:8px;font-size:0.85rem;border:1px solid rgba(96, 187, 70, 0.2);">
                <i class="fas fa-info-circle"></i> <strong>Admin Note:</strong>
                <?= htmlspecialchars($sub['admin_message']) ?>
              </div>
            <?php endif; ?>
          <?php elseif ($sub && $sub['status'] === 'pending'): ?>
            <div style="color:var(--warning);font-weight:600;"><i class="fas fa-clock"></i> Verification Pending</div>
          <?php elseif ($sub && $sub['status'] === 'rejected'): ?>
            <div style="color:var(--danger);font-weight:600;margin-bottom:0.5rem;"><i class="fas fa-times-circle"></i>
              Payment Rejected</div>
            <?php if ($sub['admin_message']): ?>
              <div
                style="background:rgba(220, 53, 69, 0.1);color:#a71d2a;padding:0.75rem;border-radius:8px;font-size:0.85rem;border:1px solid rgba(220, 53, 69, 0.2);">
                <i class="fas fa-exclamation-circle"></i> <strong>Reason:</strong>
                <?= htmlspecialchars($sub['admin_message']) ?>
              </div>
            <?php endif; ?>
          <?php endif; ?>
      </div>
    </div>
  </div>

  <?php if (!isPro($userId) && (!$sub || $sub['status'] !== 'pending')): ?>
    <div class="card-box mb-4">
      <div class="card-box-header"><span class="card-box-title"><i class="fas fa-crown" style="color:#FFB547;"></i>
          Upgrade to Pro Plan</span></div>
      <form method="POST" action="<?= BASE_URL ?>/dashboard/subscription" enctype="multipart/form-data">
        <div class="row">
          <div class="col-md-6">
            <div
              style="background:rgba(108,99,255,0.08);border:1px solid rgba(108,99,255,0.2);border-radius:10px;padding:1.5rem;text-align:center;margin-bottom:1rem;">
              <div style="font-size:2rem;font-weight:900;color:var(--primary);">Rs <?= number_format(PRO_PRICE) ?></div>
              <div style="color:var(--text-muted);font-size:0.9rem;">Annual subscription</div>
            </div>
            <div class="form-group">
              <label class="form-label">Payment Method</label>
              <div style="display:flex;gap:1rem;">
                <label style="flex:1;cursor:pointer;">
                  <input type="radio" name="payment_method" value="esewa" id="esewa"
                    style="position:absolute; opacity:0; pointer-events:none;" required>
                  <div class="pay-method-btn" id="esewaBtn"
                    style="text-align:center;padding:1rem;border:2px solid var(--border);border-radius:12px;transition:all 0.2s;"
                    onclick="selectMethod('esewa')">
                    <div style="font-size:1.5rem;color:#60BB46;margin-bottom:0.25rem;"><i class="fas fa-wallet"></i></div>
                    <div style="font-weight:700;font-size:0.9rem;">eSewa</div>
                  </div>
                </label>
                <label style="flex:1;cursor:pointer;">
                  <input type="radio" name="payment_method" value="khalti" id="khalti"
                    style="position:absolute; opacity:0; pointer-events:none;">
                  <div class="pay-method-btn" id="khaltiBtn"
                    style="text-align:center;padding:1rem;border:2px solid var(--border);border-radius:12px;transition:all 0.2s;"
                    onclick="selectMethod('khalti')">
                    <div style="font-size:1.5rem;color:#5C2D91;margin-bottom:0.25rem;"><i class="fas fa-mobile-alt"></i>
                    </div>
                    <div style="font-weight:700;font-size:0.9rem;">Khalti</div>
                  </div>
                </label>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label class="form-label">Transaction ID / Reference *</label>
              <input type="text" name="transaction_id" class="form-control"
                placeholder="Enter transaction ID after payment" required>
            </div>
            <div class="form-group">
              <label class="form-label">Payment Screenshot *</label>
              <input type="file" name="screenshot" class="form-control" accept="image/*" required>
              <small style="color:var(--text-muted);font-size:0.78rem;">Upload screenshot of successful payment</small>
            </div>
            <!-- QR Codes -->
            <div id="esewaQR"
              style="display:none;text-align:center;margin-bottom:1rem;background:#f8f9fa;padding:1rem;border-radius:10px;">
              <p style="color:var(--text-secondary);font-size:0.85rem;margin-bottom:0.75rem;">Scan this QR code with your
                eSewa app:</p>
              <div
                style="background:white;padding:0.5rem;border-radius:12px;display:inline-block;border:2px solid #60BB46;">
                <?php if (file_exists(UPLOAD_PATH . 'payments/esewa-qr.png')): ?>
                  <img src="<?= UPLOAD_URL ?>payments/esewa-qr.png" style="width:160px;border-radius:8px;">
                <?php else: ?>
                  <div
                    style="width:120px;height:120px;background:linear-gradient(135deg,#60BB46,#3d7a2e);display:flex;align-items:center;justify-content:center;color:white;font-size:3rem;border-radius:8px;">
                    <i class="fas fa-qrcode"></i>
                  </div>
                <?php endif; ?>
              </div>
            </div>
            <div id="khaltiQR"
              style="display:none;text-align:center;margin-bottom:1rem;background:#f8f9fa;padding:1rem;border-radius:10px;">
              <p style="color:var(--text-secondary);font-size:0.85rem;margin-bottom:0.75rem;">Scan this QR code with your
                Khalti app:</p>
              <div
                style="background:white;padding:0.5rem;border-radius:12px;display:inline-block;border:2px solid #5C2D91;">
                <?php if (file_exists(UPLOAD_PATH . 'payments/khalti-qr.png')): ?>
                  <img src="<?= UPLOAD_URL ?>payments/khalti-qr.png" style="width:160px;border-radius:8px;">
                <?php else: ?>
                  <div
                    style="width:120px;height:120px;background:linear-gradient(135deg,#5C2D91,#3a1a5e);display:flex;align-items:center;justify-content:center;color:white;font-size:3rem;border-radius:8px;">
                    <i class="fas fa-qrcode"></i>
                  </div>
                <?php endif; ?>
              </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%;padding:1rem;"><i
                class="fas fa-paper-plane"></i> Submit for Verification</button>
          </div>
        </div>
      </form>
    </div>
  <?php endif; ?>



  <script>
    function selectMethod(method) {
      document.getElementById('esewa').checked = method === 'esewa';
      document.getElementById('khalti').checked = method === 'khalti';
      document.getElementById('esewaQR').style.display = method === 'esewa' ? 'block' : 'none';
      document.getElementById('khaltiQR').style.display = method === 'khalti' ? 'block' : 'none';
      document.getElementById('esewaBtn').style.borderColor = method === 'esewa' ? '#60BB46' : 'var(--border)';
      document.getElementById('khaltiBtn').style.borderColor = method === 'khalti' ? '#5C2D91' : 'var(--border)';
    }
  </script>
  <?php include __DIR__ . '/../includes/footer.php'; ?>