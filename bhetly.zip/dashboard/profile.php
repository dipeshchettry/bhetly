<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($_POST['name'] ?? '');
    $bio     = sanitize($_POST['bio'] ?? '');
    $about_me = sanitize($_POST['about_me'] ?? '');
    $phone   = sanitize($_POST['phone'] ?? '');
    $whatsapp = sanitize($_POST['whatsapp'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $website = sanitize($_POST['website'] ?? '');
    $theme   = in_array($_POST['theme'] ?? '', ['light','dark','custom']) ? $_POST['theme'] : 'light';
    $color   = sanitize($_POST['custom_color'] ?? '#6C63FF');
    $showEmail = isset($_POST['show_email']) ? 1 : 0;
    $showPhone = isset($_POST['show_phone']) ? 1 : 0;

    // Update username
    $newUsername = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', $_POST['username'] ?? ''));
    if ($newUsername && $newUsername !== $user['username']) {
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $check->execute([$newUsername, $_SESSION['user_id']]);
        if ($check->fetch()) {
            setFlash('error', 'Username already taken.');
            redirect(BASE_URL . '/dashboard/profile');
        }
        $pdo->prepare("UPDATE users SET username = ? WHERE id = ?")->execute([$newUsername, $_SESSION['user_id']]);
        $_SESSION['username'] = $newUsername;
    }

    // Update name
    $pdo->prepare("UPDATE users SET name = ? WHERE id = ?")->execute([$name, $_SESSION['user_id']]);

    // Handle profile picture upload
    $picFile = $_FILES['profile_picture'] ?? null;
    $newPic  = $user['profile_picture'] ?? null;
    if ($picFile && $picFile['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($picFile, 'profiles');
        if (isset($result['error'])) {
            setFlash('error', $result['error']);
            redirect(BASE_URL . '/dashboard/profile');
        }
        // Delete old picture
        if ($newPic) @unlink(UPLOAD_PATH . 'profiles/' . $newPic);
        $newPic = $result['filename'];
    }

    // Handle cover photo upload
    $coverFile = $_FILES['cover_photo'] ?? null;
    $newCover  = $user['cover_photo'] ?? null;
    if ($coverFile && $coverFile['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($coverFile, 'profiles');
        if (isset($result['error'])) {
            setFlash('error', $result['error']);
            redirect(BASE_URL . '/dashboard/profile');
        }
        if ($newCover) @unlink(UPLOAD_PATH . 'profiles/' . $newCover);
        $newCover = $result['filename'];
    }

    // Update profile
    $pdo->prepare("UPDATE profiles SET bio=?, about_me=?, phone=?, whatsapp=?, address=?, website=?, theme=?, custom_color=?, show_email=?, show_phone=?, profile_picture=?, cover_photo=? WHERE user_id=?")
        ->execute([$bio, $about_me, $phone, $whatsapp, $address, $website, $theme, $color, $showEmail, $showPhone, $newPic, $newCover, $_SESSION['user_id']]);

    setFlash('success', 'Profile updated successfully!');
    redirect(BASE_URL . '/dashboard/profile');
}

$user = getCurrentUser();
$profileUrl = BASE_URL . '/' . $user['username'];
include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Edit Profile</h2>
    <p class="page-subtitle">Customize your digital business card</p>
  </div>

  <div class="row g-3">
    <!-- Form -->
    <div class="col-lg-8">
      <form method="POST" enctype="multipart/form-data" data-loading="true">
        <!-- Basic Info -->
        <div class="card-box mb-3">
          <div class="card-box-header"><span class="card-box-title"><i class="fas fa-user"></i> Basic Information</span></div>

          <!-- Images (Cover & Profile) -->
          <div style="display:flex; flex-direction:column; gap:1.5rem; margin-bottom:2rem;">
            
            <div style="flex:1;">
              <label style="font-weight:600; font-size:0.9rem; margin-bottom:0.5rem; display:block;">Cover Photo</label>
              <div style="position:relative; width:100%; height:120px; border-radius:12px; overflow:hidden; border:2px dashed var(--border); background:#f8f9fa;">
                <?php if ($user['cover_photo']): ?>
                <img id="coverPreview" src="<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($user['cover_photo']) ?>" style="width:100%; height:100%; object-fit:cover;">
                <?php else: ?>
                <div id="coverPreview" style="width:100%; height:100%; background:linear-gradient(135deg, <?= htmlspecialchars($user['custom_color'] ?? '#0f4c81') ?>, #43D9B4);"></div>
                <?php endif; ?>
                <label class="btn btn-secondary btn-sm" style="position:absolute; bottom:10px; right:10px; cursor:pointer; background:rgba(255,255,255,0.9); border:none;">
                  <i class="fas fa-camera"></i> Edit Cover
                  <input type="file" name="cover_photo" style="display:none;" accept="image/*" onchange="previewImg(this,'coverPreview', false)">
                </label>
              </div>
            </div>

            <div style="display:flex;align-items:center;gap:1.5rem;">
              <div style="position:relative;">
                <?php if ($user['profile_picture']): ?>
                <img id="picPreview" src="<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($user['profile_picture']) ?>" alt="Profile" style="width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--primary); display:block;">
                <?php else: ?>
                <div id="picPreview" style="width:90px;height:90px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:2rem;color:white;border:3px solid var(--primary);">
                  <?= strtoupper(substr($user['name'],0,1)) ?>
                </div>
                <?php endif; ?>
              </div>
              <div>
                <label class="btn btn-secondary" style="cursor:pointer;">
                  <i class="fas fa-camera"></i> Change Avatar
                  <input type="file" name="profile_picture" style="display:none;" accept="image/*" onchange="previewImg(this,'picPreview', true)">
                </label>
                <p style="color:var(--text-muted);font-size:0.78rem;margin-top:0.5rem;">JPG, PNG, WebP. Max 5MB.</p>
              </div>
            </div>
          </div>

          <div class="row g-3">
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars(htmlspecialchars_decode($user['name'] ?? '', ENT_QUOTES), ENT_QUOTES, 'UTF-8') ?>" required>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Username *</label>
                <div class="input-group">
                  <i class="fas fa-at input-icon"></i>
                  <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" pattern="[a-zA-Z0-9_]{3,30}" required>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="form-group">
                <label class="form-label">Bio / Description</label>
                <textarea name="bio" class="form-control" rows="2" placeholder="Short tagline or bio..."><?= htmlspecialchars(htmlspecialchars_decode($user['bio'] ?? '', ENT_QUOTES), ENT_QUOTES, 'UTF-8') ?></textarea>
              </div>
            </div>
            <div class="col-12">
              <div class="form-group">
                <label class="form-label">About Me</label>
                <textarea name="about_me" class="form-control" rows="4" placeholder="Detailed about me..."><?= htmlspecialchars(htmlspecialchars_decode($user['about_me'] ?? '', ENT_QUOTES), ENT_QUOTES, 'UTF-8') ?></textarea>
              </div>
            </div>
          </div>
        </div>

        <!-- Contact Info -->
        <div class="card-box mb-3">
          <div class="card-box-header"><span class="card-box-title"><i class="fas fa-address-book"></i> Contact Information</span></div>
          <div class="row g-3">
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <div class="input-group">
                  <i class="fas fa-phone input-icon"></i>
                  <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+977-98XXXXXXXX">
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">WhatsApp Number</label>
                <div class="input-group">
                  <i class="fab fa-whatsapp input-icon"></i>
                  <input type="text" name="whatsapp" class="form-control" value="<?= htmlspecialchars($user['whatsapp'] ?? '') ?>" placeholder="+977-98XXXXXXXX">
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Website</label>
                <div class="input-group">
                  <i class="fas fa-globe input-icon"></i>
                  <input type="url" name="website" class="form-control" value="<?= htmlspecialchars($user['website'] ?? '') ?>" placeholder="https://yoursite.com">
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Address</label>
                <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($user['address'] ?? '') ?>" placeholder="City, Country">
              </div>
            </div>
          </div>

          <!-- Visibility toggles -->
          <div style="display:flex;gap:2rem;margin-top:1rem;flex-wrap:wrap;">
            <label style="display:flex;align-items:center;gap:0.75rem;cursor:pointer;">
              <label class="toggle-switch">
                <input type="checkbox" name="show_email" <?= ($user['show_email'] ?? 1) ? 'checked' : '' ?>>
                <span class="toggle-slider"></span>
              </label>
              <span style="font-size:0.9rem;">Show Email</span>
            </label>
            <label style="display:flex;align-items:center;gap:0.75rem;cursor:pointer;">
              <label class="toggle-switch">
                <input type="checkbox" name="show_phone" <?= ($user['show_phone'] ?? 1) ? 'checked' : '' ?>>
                <span class="toggle-slider"></span>
              </label>
              <span style="font-size:0.9rem;">Show Phone</span>
            </label>
          </div>
        </div>

        <!-- Theme -->
        <div class="card-box mb-3">
          <div class="card-box-header"><span class="card-box-title"><i class="fas fa-palette"></i> Card Theme</span></div>
          <div style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:1rem;">
            <?php foreach (['light','dark','custom'] as $t): ?>
            <label style="cursor:pointer;display:flex;align-items:center;gap:0.5rem;padding:0.6rem 1.2rem;border-radius:50px;border:2px solid <?= ($user['theme'] ?? 'light') === $t ? 'var(--primary)' : 'var(--border)' ?>;background:<?= ($user['theme'] ?? 'light') === $t ? 'rgba(108,99,255,0.1)' : 'transparent' ?>;transition:all 0.2s;">
              <input type="radio" name="theme" value="<?= $t ?>" <?= ($user['theme'] ?? 'light') === $t ? 'checked' : '' ?> style="accent-color:var(--primary);">
              <?= ucfirst($t) ?>
            </label>
            <?php endforeach; ?>
          </div>
          <div class="form-group">
            <label class="form-label">Custom Brand Color</label>
            <div style="display:flex;align-items:center;gap:1rem;">
              <input type="color" name="custom_color" id="customColor" value="<?= htmlspecialchars($user['custom_color'] ?? '#6C63FF') ?>" style="width:50px;height:40px;border-radius:10px;border:1px solid var(--border);background:none;cursor:pointer;padding:2px;">
              <span style="font-size:0.85rem;color:var(--text-secondary);">Used for buttons and accent on your public card</span>
              <span class="color-preview" style="width:30px;height:30px;border-radius:8px;background:<?= htmlspecialchars($user['custom_color'] ?? '#6C63FF') ?>;display:inline-block;"></span>
            </div>
          </div>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Profile</button>
      </form>
    </div>

    <!-- Preview -->
    <div class="col-lg-4">
      <div class="card-box" style="position:sticky;top:80px;">
        <div class="card-box-header"><span class="card-box-title">Live Preview</span></div>
        <div class="profile-preview">
          <?php if ($user['cover_photo']): ?>
          <div class="profile-preview-cover" style="height:100px; background:url('<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($user['cover_photo']) ?>') center/cover;"></div>
          <?php else: ?>
          <div class="profile-preview-cover" style="height:100px; background:linear-gradient(135deg, <?= htmlspecialchars($user['custom_color'] ?? '#0f4c81') ?>, #43D9B4);"></div>
          <?php endif; ?>
          <div class="profile-preview-body">
            <div style="display:flex; justify-content:center; margin-top:-40px; text-align:center; width:100%; position:relative; z-index:10;">
              <?php if ($user['profile_picture']): ?>
              <img id="picPreviewCard" src="<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($user['profile_picture']) ?>" class="profile-preview-avatar" alt="Profile" style="margin:0 auto; display:block;">
              <?php else: ?>
              <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:2rem;color:white;border:4px solid var(--dark-3);margin:0 auto;">
                <?= strtoupper(substr($user['name'],0,1)) ?>
              </div>
              <?php endif; ?>
            </div>
            <div class="profile-preview-name" style="margin-top:0.75rem;">
              <?= htmlspecialchars(htmlspecialchars_decode($user['name'] ?? '', ENT_QUOTES), ENT_QUOTES, 'UTF-8') ?>
              <?php if (isset($user['is_verified']) && $user['is_verified']): ?>
              <span style="color:var(--primary); font-size:1rem; margin-left:2px;"><i class="fas fa-check-circle"></i></span>
              <?php endif; ?>
            </div>
            <div class="profile-preview-bio"><?= htmlspecialchars(htmlspecialchars_decode($user['bio'] ?? 'Your bio here...', ENT_QUOTES), ENT_QUOTES, 'UTF-8') ?></div>
            <div style="display:flex;gap:0.5rem;justify-content:center;flex-wrap:wrap;">
              <?php if ($user['phone']): ?>
              <span style="padding:0.4rem 0.9rem;background:var(--primary);color:white;border-radius:50px;font-size:0.75rem;"><i class="fas fa-phone"></i> Call</span>
              <?php endif; ?>
              <?php if ($user['whatsapp']): ?>
              <span style="padding:0.4rem 0.9rem;background:#25D366;color:white;border-radius:50px;font-size:0.75rem;"><i class="fab fa-whatsapp"></i> WhatsApp</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php if (isset($user['is_verified']) && !$user['is_verified']): ?>
        <div class="alert alert-warning" style="margin-top:1rem;">
          <i class="fas fa-hourglass-half"></i>
          Your profile is pending admin approval. Public URL will work after approval.
        </div>
        <?php endif; ?>
        <div style="margin-top:1rem;text-align:center;">
          <?php if (isset($user['is_verified']) && $user['is_verified']): ?>
          <a href="<?= $profileUrl ?>" target="_blank" class="btn btn-secondary btn-sm"><i class="fas fa-external-link-alt"></i> View Public Card</a>
          <?php else: ?>
          <button type="button" class="btn btn-secondary btn-sm" disabled style="opacity:.7;cursor:not-allowed;"><i class="fas fa-lock"></i> Awaiting Approval</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function previewImg(input, previewId, isAvatar) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      const el = document.getElementById(previewId);
      if (el.tagName === 'IMG') {
          el.src = e.target.result;
      } else {
        const img = document.createElement('img');
        img.id = previewId; 
        img.src = e.target.result;
        if (isAvatar) {
            img.style.cssText = 'width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--primary);display:block;';
        } else {
            img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
        }
        el.parentNode.replaceChild(img, el);
      }
    };
    reader.readAsDataURL(input.files[0]);
  }
}
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
