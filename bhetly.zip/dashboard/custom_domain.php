<?php
/**
 * dashboard/custom_domain.php
 * Custom Domain feature has been removed. Redirect to dashboard.
 */
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
setFlash('danger', 'The Custom Domain feature is no longer available. Use Order Management to manage your product orders.');
redirect(BASE_URL . '/dashboard/orders');
