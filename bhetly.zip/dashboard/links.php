<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$userId = $_SESSION['user_id'];
$isPro  = isPro($userId);

// Function to detect platform from URL
function detectPlatformFromUrl($url) {
    $url_lower = strtolower($url);
    
    $platforms = [
        'facebook' => ['facebook.com', 'fb.com'],
        'instagram' => ['instagram.com'],
        'linkedin' => ['linkedin.com'],
        'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
        'youtube' => ['youtube.com', 'youtu.be'],
        'twitter' => ['twitter.com', 'x.com'],
        'snapchat' => ['snapchat.com'],
        'github' => ['github.com'],
        'whatsapp' => ['whatsapp.com', 'wa.me', 'api.whatsapp.com'],
        'telegram' => ['telegram.org', 't.me'],
        'website' => ['website', 'mysite'],
    ];
    
    foreach ($platforms as $platform => $domains) {
        foreach ($domains as $domain) {
            if (strpos($url_lower, $domain) !== false) {
                return $platform;
            }
        }
    }
    
    return 'custom';
}

// Handle Add/Edit Link
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action   = $_POST['action'] ?? '';
    $url      = filter_var(trim($_POST['url'] ?? ''), FILTER_SANITIZE_URL);
    $linkId   = intval($_POST['link_id'] ?? 0);

    // Pro plan link limit check
    if ($action === 'add') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM social_links WHERE user_id = ?");
        $countStmt->execute([$userId]);
        $linkCount = $countStmt->fetchColumn();
        if (!$isPro && $linkCount >= 2) {
            setFlash('error', 'Free plan allows up to 2 links. Upgrade to Pro for unlimited links!');
            redirect(BASE_URL . '/dashboard/links');
        }
    }

    if ($action === 'add') {
        if (!$url) {
            setFlash('error', 'Please enter a valid URL.');
        } else {
            $platform = detectPlatformFromUrl($url);
            $stmt = $pdo->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM social_links WHERE user_id = ?");
            $stmt->execute([$userId]);
            $sortOrder = $stmt->fetchColumn();
            
            $pdo->prepare("INSERT INTO social_links (user_id, platform, url, icon, sort_order) VALUES (?, ?, ?, ?, ?)")
                ->execute([$userId, $platform, $url, getSocialIcon($platform), $sortOrder]);
            setFlash('success', 'Link added successfully!');
        }
    } elseif ($action === 'edit' && $linkId) {
        if (!$url) {
            setFlash('error', 'Please enter a valid URL.');
        } else {
            $platform = detectPlatformFromUrl($url);
            $pdo->prepare("UPDATE social_links SET platform=?, url=?, icon=? WHERE id=? AND user_id=?")
                ->execute([$platform, $url, getSocialIcon($platform), $linkId, $userId]);
            setFlash('success', 'Link updated!');
        }
    } elseif ($action === 'delete' && $linkId) {
        $pdo->prepare("DELETE FROM social_links WHERE id=? AND user_id=?")->execute([$linkId, $userId]);
        setFlash('success', 'Link removed.');
    } elseif ($action === 'toggle' && $linkId) {
        $pdo->prepare("UPDATE social_links SET is_active = 1 - is_active WHERE id=? AND user_id=?")->execute([$linkId, $userId]);
    }
    // Correct extensionless redirect
    redirect(BASE_URL . '/dashboard/links');
}

$links = $pdo->prepare("SELECT * FROM social_links WHERE user_id = ? ORDER BY sort_order ASC");
$links->execute([$userId]);
$links = $links->fetchAll();

$platforms = ['facebook','instagram','linkedin','tiktok','youtube','twitter','snapchat','github','whatsapp','telegram','website','custom'];

include __DIR__ . '/../includes/header.php';
?>

<!-- LINKS-SPECIFIC ISOLATED CSS (ll- prefix) to avoid Bootstrap conflicts -->
<style>
/* ===== IN-PAGE FORM ===== */
.ll-form-wrap {
  background: var(--dark-2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}
.ll-form-header {
  font-size: 1rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.ll-label {
  display: block;
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 0.4rem;
}
/* Input wrapper - isolated from .input-group */
.ll-input-box {
  position: relative !important;
  display: block !important;
}
.ll-input-icon {
  position: absolute !important;
  left: 1rem !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  color: #9ca3af !important;
  font-size: 0.95rem !important;
  pointer-events: none !important;
  z-index: 2 !important;
}
/* The main input field - heavily isolated */
.ll-input {
  display: block !important;
  width: 100% !important;
  padding: 0.75rem 1rem !important;
  padding-left: 2.8rem !important;
  font-size: 0.95rem !important;
  font-family: inherit !important;
  color: #1d1d1f !important;
  background-color: #fff !important;
  border: 1.5px solid rgba(15,23,42,0.15) !important;
  border-radius: 10px !important;
  outline: none !important;
  box-shadow: none !important;
  cursor: text !important;
  pointer-events: auto !important;
  position: static !important;
  z-index: auto !important;
  transition: border-color 0.2s, box-shadow 0.2s !important;
  -webkit-appearance: none !important;
  appearance: none !important;
  box-sizing: border-box !important;
}
.ll-input:focus {
  border-color: var(--primary) !important;
  box-shadow: 0 0 0 3px rgba(15,76,129,0.12) !important;
}
.ll-hint {
  display: block;
  font-size: 0.75rem;
  color: var(--text-muted);
  margin-top: 0.35rem;
}
.ll-submit {
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, var(--primary), var(--primary-light));
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  pointer-events: auto !important;
  transition: transform 0.2s, box-shadow 0.2s;
}
.ll-submit:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 14px rgba(15,76,129,0.3);
}

/* ===== EDIT MODAL ===== */
.ll-modal-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.55);
  backdrop-filter: blur(4px);
  z-index: 9999;
  align-items: center;
  justify-content: center;
  padding: 1rem;
}
.ll-modal-overlay.ll-show {
  display: flex !important;
}
.ll-modal-box {
  background: #fff;
  border-radius: 16px;
  width: 100%;
  max-width: 500px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
  animation: llSlideIn 0.2s ease;
}
@keyframes llSlideIn {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
.ll-modal-head {
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid rgba(0,0,0,0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ll-modal-title {
  font-size: 1.05rem;
  font-weight: 700;
  color: #1d1d1f;
}
.ll-modal-close {
  background: none;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: #86868b;
  pointer-events: auto !important;
}
.ll-modal-close:hover { color: #dc3545; }
.ll-modal-body {
  padding: 1.5rem;
}
.ll-modal-foot {
  padding: 1rem 1.5rem;
  border-top: 1px solid rgba(0,0,0,0.08);
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
}
.ll-btn-cancel {
  padding: 0.6rem 1.25rem;
  background: #f3f4f6;
  color: #374151;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  pointer-events: auto !important;
}
</style>

<div class="page-content">
  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
    <div>
      <h2 class="page-title">Social Links</h2>
      <p class="page-subtitle">Add and manage your social media profiles and links</p>
    </div>
  </div>

  <!-- In-page Add Link Form -->
  <div class="ll-form-wrap mb-4">
    <div class="ll-form-header">
      <i class="fas fa-plus-circle" style="color:var(--primary);"></i> Add New Link
    </div>
    <form method="POST" action="<?= BASE_URL ?>/dashboard/links" style="display:flex; gap:1rem; flex-wrap:wrap; align-items:flex-end;">
      <input type="hidden" name="action" value="add">
      <div style="flex:1; min-width:300px;">
        <label class="ll-label">Paste Your Link</label>
        <div class="ll-input-box">
          <i class="fas fa-link ll-input-icon"></i>
          <input type="url" name="url" class="ll-input" placeholder="https://facebook.com/yourprofile" required autocomplete="off">
        </div>
        <span class="ll-hint">Platform will be detected automatically</span>
      </div>
      <div>
        <button type="submit" class="ll-submit"><i class="fas fa-plus"></i> Add Link</button>
      </div>
    </form>
  </div>

  <?php if (!$isPro): ?>
  <div class="alert alert-info alert-auto-dismiss">
    <i class="fas fa-crown"></i> You're on the <strong>Free plan</strong> (<?= count($links) ?>/2 links). <a href="<?= BASE_URL ?>/dashboard/subscription" style="color:var(--primary-light);font-weight:700;">Upgrade to Pro</a> for unlimited links.
  </div>
  <?php endif; ?>

  <!-- Link List -->
  <?php if (empty($links)): ?>
  <div class="card-box" style="text-align:center;padding:3rem;">
    <i class="fas fa-link" style="font-size:3rem;color:var(--text-muted);margin-bottom:1rem;display:block;"></i>
    <p style="color:var(--text-secondary);">No links added yet. Click "Add Link" to get started.</p>
  </div>
  <?php else: ?>
  <div id="linkList">
    <?php foreach ($links as $link): $color = getSocialColor($link['platform']); ?>
    <div class="link-item" data-id="<?= $link['id'] ?>">
      <div class="link-icon" style="background:<?= $color ?>;">
        <i class="<?= htmlspecialchars($link['icon'] ?: getSocialIcon($link['platform'])) ?>"></i>
      </div>
      <div class="link-info">
        <div class="link-platform"><?= htmlspecialchars(ucfirst($link['platform'])) ?></div>
        <div class="link-url"><?= htmlspecialchars($link['url']) ?></div>
      </div>
      <div class="link-clicks"><i class="fas fa-mouse-pointer"></i> <?= $link['click_count'] ?></div>
      <div style="display:flex;align-items:center;gap:0.5rem;">
        <form method="POST" style="display:inline;">
          <input type="hidden" name="action" value="toggle">
          <input type="hidden" name="link_id" value="<?= $link['id'] ?>">
          <button type="submit" class="btn btn-secondary btn-icon" title="<?= $link['is_active'] ? 'Deactivate' : 'Activate' ?>">
            <i class="fas fa-<?= $link['is_active'] ? 'eye' : 'eye-slash' ?>"></i>
          </button>
        </form>
        <button class="btn btn-secondary btn-icon" onclick='llOpenEdit(<?= $link['id'] ?>, <?= json_encode($link['platform']) ?>, <?= json_encode($link['url']) ?>)'>
          <i class="fas fa-edit"></i>
        </button>
        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this link?')">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="link_id" value="<?= $link['id'] ?>">
          <button type="submit" class="btn btn-danger btn-icon"><i class="fas fa-trash"></i></button>
        </form>
        <i class="fas fa-grip-vertical" style="color:var(--text-muted);cursor:grab;margin-left:0.25rem;"></i>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Edit Link Modal (Isolated CSS) -->
<div class="ll-modal-overlay" id="llEditModal">
  <div class="ll-modal-box" onclick="event.stopPropagation()">
    <div class="ll-modal-head">
      <span class="ll-modal-title"><i class="fas fa-edit" style="color:var(--primary);margin-right:0.5rem;"></i> Edit Link</span>
      <button class="ll-modal-close" type="button" onclick="llCloseEdit()"><i class="fas fa-times"></i></button>
    </div>
    <div class="ll-modal-body">
      <form method="POST" action="<?= BASE_URL ?>/dashboard/links" id="llEditForm">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="link_id" id="editLinkId">
        
        <div style="margin-bottom:1.5rem;">
          <label class="ll-label">URL</label>
          <div class="ll-input-box">
            <i class="fas fa-link ll-input-icon"></i>
            <input type="url" name="url" id="editUrl" class="ll-input" placeholder="https://facebook.com/yourprofile" required autocomplete="off">
          </div>
          <span class="ll-hint">Platform will be detected automatically</span>
        </div>

        <div class="ll-modal-foot" style="padding:0;border:none;">
          <button type="button" class="ll-btn-cancel" onclick="llCloseEdit()">Cancel</button>
          <button type="submit" class="ll-submit" style="padding:0.6rem 1.5rem;font-size:0.875rem;"><i class="fas fa-save"></i> Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
<script>
const BASE_URL = '<?= BASE_URL ?>';

function llOpenEdit(id, platform, url) {
  document.getElementById('editLinkId').value = id;
  document.getElementById('editUrl').value    = url;
  document.getElementById('llEditModal').classList.add('ll-show');
  
  // Force input interactive
  setTimeout(function() {
    var input = document.getElementById('editUrl');
    input.style.pointerEvents = 'auto';
    input.style.position = 'static';
    input.style.zIndex = 'auto';
    input.focus();
  }, 50);
}

function llCloseEdit() {
  document.getElementById('llEditModal').classList.remove('ll-show');
}

// Close when clicking outside modal box
document.getElementById('llEditModal').addEventListener('click', function(e) {
  if (e.target === this) llCloseEdit();
});

// Force all inputs to be explicitly clickable on mount
window.addEventListener('load', function() {
  document.querySelectorAll('.ll-input').forEach(function(el) {
    el.style.pointerEvents = 'auto';
    el.style.position = 'static';
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
