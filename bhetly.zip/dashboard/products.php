<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$user = getCurrentUser();

if (!isPro()) {
    setFlash('danger', 'Products feature is available for Pro users only. Please upgrade your plan.');
    redirect(BASE_URL . '/dashboard/subscription');
}

$uid = $_SESSION['user_id'];

// ---- Handle POST Actions ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $id          = (int)($_POST['id'] ?? 0);
        $name        = sanitize($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price       = max(0, (float)($_POST['price'] ?? 0));
        $waNumber    = sanitize($_POST['whatsapp_number'] ?? '');
        $isActive    = isset($_POST['is_active']) ? 1 : 0;
        $imagePath   = null;

        if (empty($name)) {
            setFlash('danger', 'Product name is required.');
            redirect(BASE_URL . '/dashboard/products');
        }

        // Handle image upload
        if (!empty($_FILES['image']['name'])) {
            if (!is_dir(UPLOAD_PATH . 'products')) {
                mkdir(UPLOAD_PATH . 'products', 0755, true);
            }
            $upload = uploadFile($_FILES['image'], 'products');
            if (isset($upload['error'])) {
                setFlash('danger', $upload['error']);
                redirect(BASE_URL . '/dashboard/products');
            }
            $imagePath = $upload['filename'];
        }

        if ($action === 'add') {
            $stmt = $pdo->prepare(
                "INSERT INTO products (user_id, name, description, price, whatsapp_number, is_active, image_path)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$uid, $name, $description, $price, $waNumber, $isActive, $imagePath]);
            setFlash('success', 'Product added successfully!');
        } else {
            $check = $pdo->prepare("SELECT id, image_path FROM products WHERE id = ? AND user_id = ?");
            $check->execute([$id, $uid]);
            $existing = $check->fetch();
            if (!$existing) { redirect(BASE_URL . '/dashboard/products'); }

            if ($imagePath !== null && $existing['image_path']) {
                $oldPath = UPLOAD_PATH . 'products/' . $existing['image_path'];
                if (file_exists($oldPath)) unlink($oldPath);
            }
            if ($imagePath === null) {
                $imagePath = $existing['image_path'];
            }

            $stmt = $pdo->prepare(
                "UPDATE products SET name=?, description=?, price=?, whatsapp_number=?, is_active=?, image_path=?
                 WHERE id=? AND user_id=?"
            );
            $stmt->execute([$name, $description, $price, $waNumber, $isActive, $imagePath, $id, $uid]);
            setFlash('success', 'Product updated successfully!');
        }

    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $check = $pdo->prepare("SELECT image_path FROM products WHERE id = ? AND user_id = ?");
        $check->execute([$id, $uid]);
        $row = $check->fetch();
        if ($row) {
            if ($row['image_path']) {
                $path = UPLOAD_PATH . 'products/' . $row['image_path'];
                if (file_exists($path)) unlink($path);
            }
            $pdo->prepare("DELETE FROM products WHERE id = ? AND user_id = ?")->execute([$id, $uid]);
            setFlash('success', 'Product deleted.');
        }

    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("UPDATE products SET is_active = 1 - is_active WHERE id = ? AND user_id = ?")
            ->execute([$id, $uid]);
        setFlash('success', 'Product visibility updated.');
    }

    redirect(BASE_URL . '/dashboard/products');
}

// ---- Fetch Products ----
$stmt = $pdo->prepare("SELECT * FROM products WHERE user_id = ? ORDER BY sort_order ASC, created_at DESC");
$stmt->execute([$uid]);
$products = $stmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<!-- Products-specific CSS: uses pd-* classes to avoid ALL Bootstrap 5 conflicts -->
<style>
/* ===== PRODUCT MODALS — FULLY ISOLATED FROM BOOTSTRAP ===== */
.pd-modal-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.55);
  backdrop-filter: blur(4px);
  z-index: 9999;
  align-items: center;
  justify-content: center;
  padding: 1rem;
}
.pd-modal-overlay.pd-show {
  display: flex !important;
}
.pd-modal-box {
  background: #fff;
  border-radius: 16px;
  width: 100%;
  max-width: 560px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
  animation: pdSlideIn 0.25s ease;
}
@keyframes pdSlideIn {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
.pd-modal-head {
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid rgba(0,0,0,0.08);
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  background: #fff;
  z-index: 2;
  border-radius: 16px 16px 0 0;
}
.pd-modal-title {
  font-size: 1.05rem;
  font-weight: 700;
  color: #1d1d1f;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.pd-modal-close {
  background: none;
  border: none;
  font-size: 1.2rem;
  cursor: pointer;
  color: #86868b;
  line-height: 1;
  padding: 0.3rem;
  border-radius: 6px;
  pointer-events: auto !important;
  transition: color 0.2s;
}
.pd-modal-close:hover { color: #dc3545; }
.pd-modal-body {
  padding: 1.5rem;
}
.pd-modal-foot {
  padding: 1rem 1.5rem;
  border-top: 1px solid rgba(0,0,0,0.08);
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
  background: #fafafa;
  border-radius: 0 0 16px 16px;
}

/* ===== FORM INPUTS — ISOLATED ===== */
.pd-group {
  margin-bottom: 1.1rem;
}
.pd-label {
  display: block;
  font-size: 0.875rem;
  font-weight: 600;
  color: #1d1d1f;
  margin-bottom: 0.4rem;
}
.pd-input,
.pd-textarea {
  display: block !important;
  width: 100% !important;
  padding: 0.75rem 1rem !important;
  font-size: 0.95rem !important;
  font-family: inherit !important;
  color: #1d1d1f !important;
  background-color: #fff !important;
  border: 1.5px solid rgba(15,23,42,0.15) !important;
  border-radius: 10px !important;
  outline: none !important;
  box-shadow: none !important;
  transition: border-color 0.2s, box-shadow 0.2s !important;
  cursor: text !important;
  /* Critical for clickability */
  position: static !important;
  z-index: auto !important;
  pointer-events: auto !important;
  -webkit-appearance: none !important;
  appearance: none !important;
  box-sizing: border-box !important;
}
.pd-input:focus,
.pd-textarea:focus {
  border-color: var(--primary) !important;
  box-shadow: 0 0 0 3px rgba(15,76,129,0.12) !important;
}
.pd-input::placeholder,
.pd-textarea::placeholder {
  color: #9ca3af !important;
  opacity: 1 !important;
}
.pd-textarea {
  resize: vertical !important;
  min-height: 90px !important;
}
.pd-input[type="number"] {
  -moz-appearance: textfield !important;
}
.pd-grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}
@media (max-width: 480px) {
  .pd-grid-2 { grid-template-columns: 1fr; }
}
.pd-hint {
  display: block;
  font-size: 0.75rem;
  color: #86868b;
  margin-top: 0.3rem;
}
.pd-file {
  display: block !important;
  width: 100% !important;
  padding: 0.6rem 1rem !important;
  font-size: 0.875rem !important;
  font-family: inherit !important;
  color: #1d1d1f !important;
  background: #f9fafb !important;
  border: 1.5px solid rgba(15,23,42,0.15) !important;
  border-radius: 10px !important;
  cursor: pointer !important;
  pointer-events: auto !important;
  position: static !important;
  z-index: auto !important;
  box-sizing: border-box !important;
}
.pd-file::-webkit-file-upload-button {
  padding: 0.35rem 0.9rem;
  background: var(--primary);
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.82rem;
  margin-right: 0.75rem;
}
.pd-toggle-wrap {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  color: #1d1d1f;
  user-select: none;
}
.pd-existing-img {
  margin-bottom: 0.5rem;
}
.pd-existing-img img {
  max-width: 100%;
  max-height: 130px;
  border-radius: 10px;
  object-fit: cover;
  display: block;
}
.pd-existing-img small {
  display: block;
  margin-top: 0.25rem;
  font-size: 0.75rem;
  color: #86868b;
}
.pd-preview-img {
  max-width: 100%;
  max-height: 120px;
  margin-top: 0.5rem;
  border-radius: 10px;
  display: none;
}
/* Buttons */
.pd-btn-cancel {
  padding: 0.6rem 1.25rem;
  background: #f3f4f6;
  color: #374151;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  pointer-events: auto !important;
  transition: background 0.2s;
}
.pd-btn-cancel:hover { background: #e5e7eb; }
.pd-btn-save {
  padding: 0.6rem 1.5rem;
  background: linear-gradient(135deg, var(--primary), var(--primary-light));
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 0.875rem;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  pointer-events: auto !important;
  transition: transform 0.2s, box-shadow 0.2s;
}
.pd-btn-save:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 14px rgba(15,76,129,0.3);
}
</style>

<div class="page-content">
  <!-- Page Header -->
  <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
    <div>
      <h2 class="page-title">
        Products &amp; Services
      </h2>
      <p class="page-subtitle">Add products or services. Customers place orders directly from your profile fully managed in your dashboard.</p>
    </div>
    <div style="display:flex;gap:0.75rem;align-items:center;">
      <a href="<?= BASE_URL ?>/<?= htmlspecialchars($user['username']) ?>#products"
         target="_blank" class="btn btn-secondary btn-sm">
        <i class="fas fa-external-link-alt"></i> Preview
      </a>
      <button class="btn btn-primary" onclick="pdOpenAdd()">
        <i class="fas fa-plus"></i> Add Product
      </button>
    </div>
  </div>

  <!-- Info Banner -->
  <div class="card-box" style="background:linear-gradient(135deg,rgba(108,99,255,0.08),rgba(67,217,180,0.08));border-color:rgba(108,99,255,0.25);padding:1rem 1.25rem;margin-bottom:1.5rem;">
    <div style="display:flex;align-items:center;gap:0.75rem;">
      <div style="width:36px;height:36px;border-radius:10px;background:rgba(108,99,255,0.12);color:#6C63FF;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        <i class="fas fa-shopping-bag"></i>
      </div>
      <div style="flex:1;">
        <div style="font-weight:700;font-size:0.9rem;margin-bottom:0.15rem;">In-Platform Order Management</div>
        <div style="color:var(--text-secondary);font-size:0.82rem;">
          When a customer clicks "Order Now" on your profile, their order is captured here no WhatsApp or external chat needed.
        </div>
      </div>
      <a href="<?= BASE_URL ?>/dashboard/orders" class="btn btn-secondary btn-sm" style="white-space:nowrap;">
        <i class="fas fa-list-check"></i> View Orders
      </a>
    </div>
  </div>

  <!-- Products Grid or Empty State -->
  <?php if (empty($products)): ?>
  <div class="card-box" style="text-align:center;padding:4rem 2rem;">
    <div style="font-size:4rem;margin-bottom:1rem;">📦</div>
    <h3 style="font-size:1.3rem;font-weight:800;margin-bottom:0.5rem;">No Products Yet</h3>
    <p style="color:var(--text-secondary);margin-bottom:2rem;max-width:400px;margin-left:auto;margin-right:auto;">
      Add your first product or service. Customers will see a "Buy Now on WhatsApp" button on your public profile.
    </p>
    <button class="btn btn-primary" onclick="pdOpenAdd()">
      <i class="fas fa-plus"></i> Add First Product
    </button>
  </div>

  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:1.25rem;">
    <?php foreach ($products as $p): ?>
    <div class="card-box" style="padding:0;overflow:hidden;position:relative;border-radius:var(--radius);transition:all 0.3s ease;">
      <!-- Product Image -->
      <?php if ($p['image_path']): ?>
      <div style="position:relative;overflow:hidden;">
        <img src="<?= UPLOAD_URL ?>products/<?= htmlspecialchars($p['image_path']) ?>"
             alt="<?= htmlspecialchars($p['name']) ?>"
             style="width:100%;height:180px;object-fit:cover;display:block;transition:transform 0.3s;">
      </div>
      <?php else: ?>
      <div style="width:100%;height:180px;background:linear-gradient(135deg,rgba(15,76,129,0.08),rgba(67,217,180,0.12));display:flex;align-items:center;justify-content:center;flex-direction:column;gap:0.5rem;color:var(--text-muted);">
        <i class="fas fa-box-open" style="font-size:2.5rem;opacity:0.4;"></i>
        <span style="font-size:0.78rem;">No image</span>
      </div>
      <?php endif; ?>

      <!-- Status Badge -->
      <div style="position:absolute;top:0.75rem;left:0.75rem;">
        <span class="badge <?= $p['is_active'] ? 'badge-success' : 'badge-secondary' ?>"
              style="box-shadow:0 2px 8px rgba(0,0,0,0.15);">
          <i class="fas fa-<?= $p['is_active'] ? 'eye' : 'eye-slash' ?>"></i>
          <?= $p['is_active'] ? 'Visible' : 'Hidden' ?>
        </span>
      </div>

      <!-- Product Details -->
      <div style="padding:1.1rem;">
        <div style="font-weight:800;font-size:1rem;margin-bottom:0.3rem;line-height:1.3;">
          <?= htmlspecialchars($p['name']) ?>
        </div>
        <?php if ($p['description']): ?>
        <div style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.75rem;line-height:1.55;">
          <?= htmlspecialchars(mb_substr($p['description'], 0, 90)) ?><?= mb_strlen($p['description']) > 90 ? '…' : '' ?>
        </div>
        <?php endif; ?>

        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.85rem;">
          <div style="font-size:1.25rem;font-weight:900;color:var(--primary);">
            Rs. <?= number_format($p['price'], 0) ?>
          </div>
        </div>

        <!-- Action Buttons -->
        <div style="display:flex;gap:0.5rem;">
          <button class="btn btn-primary btn-sm" style="flex:1;"
                  onclick='pdOpenEdit(<?= htmlspecialchars(json_encode([
                      "id"              => $p['id'],
                      "name"            => $p['name'],
                      "description"     => $p['description'] ?? '',
                      "price"           => $p['price'],
                      "whatsapp_number" => $p['whatsapp_number'] ?? '',
                      "is_active"       => $p['is_active'],
                      "image_path"      => $p['image_path'] ?? '',
                  ]), ENT_QUOTES) ?>)'>
            <i class="fas fa-edit"></i> Edit
          </button>
          <form method="POST" style="flex:1;">
            <input type="hidden" name="action" value="toggle">
            <input type="hidden" name="id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-secondary btn-sm" style="width:100%;">
              <i class="fas fa-<?= $p['is_active'] ? 'eye-slash' : 'eye' ?>"></i>
              <?= $p['is_active'] ? 'Hide' : 'Show' ?>
            </button>
          </form>
          <form method="POST" onsubmit="return confirm('Delete this product permanently?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= $p['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>


<!-- ===== ADD PRODUCT MODAL — pd-* isolated classes ===== -->
<div class="pd-modal-overlay" id="pdAddModal">
  <div class="pd-modal-box" onclick="event.stopPropagation()">
    <div class="pd-modal-head">
      <span class="pd-modal-title"><i class="fas fa-plus" style="color:var(--primary);"></i> Add Product</span>
      <button class="pd-modal-close" type="button" onclick="pdCloseAdd()"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" enctype="multipart/form-data" action="<?= BASE_URL ?>/dashboard/products" id="pdAddForm">
      <input type="hidden" name="action" value="add">
      <div class="pd-modal-body">

        <div class="pd-group">
          <label class="pd-label" for="addName">Product Name <span style="color:#dc3545;">*</span></label>
          <input type="text" id="addName" name="name" class="pd-input"
                 placeholder="e.g. Logo Design, T-Shirt, Consultation..." required autocomplete="off">
        </div>

        <div class="pd-group">
          <label class="pd-label" for="addDescription">Description</label>
          <textarea id="addDescription" name="description" class="pd-textarea" rows="3"
                    placeholder="Describe your product or service..."></textarea>
        </div>

        <div class="pd-grid-2">
          <div class="pd-group" style="margin-bottom:0;">
            <label class="pd-label" for="addPrice">Price (Rs.) <span style="color:#dc3545;">*</span></label>
            <input type="number" id="addPrice" name="price" class="pd-input"
                   placeholder="0" min="0" step="0.01" required autocomplete="off">
          </div>
        </div>

        <div class="pd-group" style="margin-top:1rem;">
          <label class="pd-label" for="addImage">Product Image <span style="color:#86868b;font-weight:400;">(Max 5MB)</span></label>
          <input type="file" id="addImage" name="image" class="pd-file"
                 accept="image/jpeg,image/png,image/gif,image/webp">
          <img id="addImgPreview" src="" alt="" class="pd-preview-img">
        </div>

        <div class="pd-group">
          <label class="pd-toggle-wrap">
            <span class="toggle-switch">
              <input type="checkbox" name="is_active" id="addActive" checked>
              <span class="toggle-slider"></span>
            </span>
            Show on public profile
          </label>
        </div>

      </div>
      <div class="pd-modal-foot">
        <button type="button" class="pd-btn-cancel" onclick="pdCloseAdd()">Cancel</button>
        <button type="submit" class="pd-btn-save"><i class="fas fa-save"></i> Add Product</button>
      </div>
    </form>
  </div>
</div>


<!-- ===== EDIT PRODUCT MODAL — pd-* isolated classes ===== -->
<div class="pd-modal-overlay" id="pdEditModal">
  <div class="pd-modal-box" onclick="event.stopPropagation()">
    <div class="pd-modal-head">
      <span class="pd-modal-title"><i class="fas fa-edit" style="color:var(--primary);"></i> Edit Product</span>
      <button class="pd-modal-close" type="button" onclick="pdCloseEdit()"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" enctype="multipart/form-data" action="<?= BASE_URL ?>/dashboard/products" id="pdEditForm">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="pdEditId">
      <div class="pd-modal-body">

        <div class="pd-group">
          <label class="pd-label" for="editName">Product Name <span style="color:#dc3545;">*</span></label>
          <input type="text" id="editName" name="name" class="pd-input"
                 placeholder="e.g. Logo Design, T-Shirt, Consultation..." required autocomplete="off">
        </div>

        <div class="pd-group">
          <label class="pd-label" for="editDescription">Description</label>
          <textarea id="editDescription" name="description" class="pd-textarea" rows="3"
                    placeholder="Describe your product or service..."></textarea>
        </div>

        <div class="pd-grid-2">
          <div class="pd-group" style="margin-bottom:0;">
            <label class="pd-label" for="editPrice">Price (Rs.) <span style="color:#dc3545;">*</span></label>
            <input type="number" id="editPrice" name="price" class="pd-input"
                   placeholder="0" min="0" step="0.01" required autocomplete="off">
          </div>
        </div>

        <div class="pd-group" style="margin-top:1rem;">
          <label class="pd-label" for="editImage">Product Image <span style="color:#86868b;font-weight:400;">(Max 5MB)</span></label>
          <div class="pd-existing-img" id="editCurrentImg" style="display:none;">
            <img id="editExistingImg" src="" alt="">
            <small>Current image — upload a new one to replace it.</small>
          </div>
          <input type="file" id="editImage" name="image" class="pd-file"
                 accept="image/jpeg,image/png,image/gif,image/webp">
          <img id="editImgPreview" src="" alt="" class="pd-preview-img">
        </div>

        <div class="pd-group">
          <label class="pd-toggle-wrap">
            <span class="toggle-switch">
              <input type="checkbox" name="is_active" id="editActive">
              <span class="toggle-slider"></span>
            </span>
            Show on public profile
          </label>
        </div>

      </div>
      <div class="pd-modal-foot">
        <button type="button" class="pd-btn-cancel" onclick="pdCloseEdit()">Cancel</button>
        <button type="submit" class="pd-btn-save"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>


<script>
// ===== Product Modal Functions =====
function pdOpenAdd() {
  document.getElementById('pdAddForm').reset();
  document.getElementById('addImgPreview').style.display = 'none';
  document.getElementById('pdAddModal').classList.add('pd-show');
  setTimeout(function() {
    pdForceInteractive('pdAddModal');
    document.getElementById('addName').focus();
  }, 50);
}
function pdCloseAdd() {
  document.getElementById('pdAddModal').classList.remove('pd-show');
}

function pdOpenEdit(p) {
  document.getElementById('pdEditId').value          = p.id;
  document.getElementById('editName').value          = p.name        || '';
  document.getElementById('editDescription').value   = p.description || '';
  document.getElementById('editPrice').value         = p.price       || 0;
  document.getElementById('editActive').checked      = (p.is_active == 1);

  // Show existing image
  var currentImgBlock = document.getElementById('editCurrentImg');
  var existingImg     = document.getElementById('editExistingImg');
  if (p.image_path && currentImgBlock && existingImg) {
    existingImg.src = '<?= UPLOAD_URL ?>products/' + p.image_path;
    currentImgBlock.style.display = 'block';
  } else if (currentImgBlock) {
    currentImgBlock.style.display = 'none';
  }

  // Reset file & preview
  document.getElementById('editImage').value = '';
  var prev = document.getElementById('editImgPreview');
  prev.src = ''; prev.style.display = 'none';

  document.getElementById('pdEditModal').classList.add('pd-show');
  setTimeout(function() {
    pdForceInteractive('pdEditModal');
    document.getElementById('editName').focus();
  }, 50);
}
function pdCloseEdit() {
  document.getElementById('pdEditModal').classList.remove('pd-show');
}

// Close modal when clicking backdrop
document.getElementById('pdAddModal').addEventListener('click', function(e) {
  if (e.target === this) pdCloseAdd();
});
document.getElementById('pdEditModal').addEventListener('click', function(e) {
  if (e.target === this) pdCloseEdit();
});

// Force all inputs interactive inside a modal
function pdForceInteractive(modalId) {
  document.querySelectorAll('#' + modalId + ' input, #' + modalId + ' textarea, #' + modalId + ' select').forEach(function(el) {
    el.style.pointerEvents = 'auto';
    el.style.position      = 'static';
    el.style.zIndex        = 'auto';
  });
}

// Image preview — add form
document.getElementById('addImage').addEventListener('change', function() {
  var file = this.files[0];
  var prev = document.getElementById('addImgPreview');
  if (!file) { prev.style.display='none'; return; }
  if (file.size > 5 * 1024 * 1024) {
    alert('File size exceeds 5MB limit.');
    this.value = ''; prev.style.display='none'; return;
  }
  var reader = new FileReader();
  reader.onload = function(e) { prev.src = e.target.result; prev.style.display = 'block'; };
  reader.readAsDataURL(file);
});

// Image preview — edit form
document.getElementById('editImage').addEventListener('change', function() {
  var file = this.files[0];
  var prev = document.getElementById('editImgPreview');
  if (!file) { prev.style.display='none'; return; }
  if (file.size > 5 * 1024 * 1024) {
    alert('File size exceeds 5MB limit.');
    this.value = ''; prev.style.display='none'; return;
  }
  var reader = new FileReader();
  reader.onload = function(e) { prev.src = e.target.result; prev.style.display = 'block'; };
  reader.readAsDataURL(file);
});

// Safety: on load ensure all pd-inputs are interactive
window.addEventListener('load', function() {
  document.querySelectorAll('.pd-input, .pd-textarea, .pd-file').forEach(function(el) {
    el.style.pointerEvents = 'auto';
    el.style.position      = 'static';
    el.style.zIndex        = 'auto';
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
