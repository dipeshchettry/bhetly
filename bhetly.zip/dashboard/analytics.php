<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$userId = $_SESSION['user_id'];

// Check pro plan for analytics access
if (!isPro($userId)) {
    setFlash('error', 'Analytics is a Pro feature. Upgrade your plan to access detailed analytics.');
    redirect(BASE_URL . '/dashboard/subscription');
}

$stats = getAnalyticsSummary($userId);
$totalClicks = $pdo->prepare("SELECT SUM(click_count) as total FROM social_links WHERE user_id = ?");
$totalClicks->execute([$userId]);
$clicks = $totalClicks->fetch()['total'] ?? 0;

// 30-day chart
$chartData = $pdo->prepare("SELECT visit_date, SUM(visit_count) as cnt FROM analytics WHERE user_id = ? AND visit_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) GROUP BY visit_date ORDER BY visit_date ASC");
$chartData->execute([$userId]);
$rows = $chartData->fetchAll();

$labels = []; $values = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $labels[] = date('M d', strtotime($d));
    $found = array_filter($rows, fn($r) => $r['visit_date'] === $d);
    $values[] = !empty($found) ? (int)array_values($found)[0]['cnt'] : 0;
}

// Device breakdown
$devicesStmt = $pdo->prepare("SELECT device_type, SUM(visit_count) as cnt FROM analytics WHERE user_id = ? GROUP BY device_type");
$devicesStmt->execute([$userId]);
$devices = $devicesStmt->fetchAll();

// Top links by clicks
$topLinks = $pdo->prepare("SELECT platform, url, click_count FROM social_links WHERE user_id = ? ORDER BY click_count DESC LIMIT 5");
$topLinks->execute([$userId]);
$topLinks = $topLinks->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Analytics</h2>
    <p class="page-subtitle">Track your profile performance and engagement</p>
  </div>

  <div class="row g-3">
    <!-- 30-day chart -->
    <div class="col-lg-8">
      <div class="card-box">
        <div class="card-box-header">
          <span class="card-box-title">Profile Views - Last 30 Days</span>
        </div>
        <div class="chart-container">
          <canvas id="visitChart" data-labels='<?= json_encode($labels) ?>' data-values='<?= json_encode($values) ?>'></canvas>
        </div>
      </div>
    </div>

    <!-- Device breakdown -->
    <div class="col-lg-4">
      <div class="card-box">
        <div class="card-box-header"><span class="card-box-title">Device Breakdown</span></div>
        <?php
        $total = array_sum(array_column($devices, 'cnt')) ?: 1;
        $deviceColors = ['mobile' => '#6C63FF', 'desktop' => '#43D9B4', 'tablet' => '#FFB547'];
        foreach ($devices as $d):
          $pct = round(($d['cnt'] / $total) * 100);
          $clr = $deviceColors[$d['device_type']] ?? '#a0a0c0';
        ?>
        <div style="margin-bottom:1rem;">
          <div style="display:flex;justify-content:space-between;margin-bottom:0.4rem;font-size:0.85rem;">
            <span style="display:flex;align-items:center;gap:0.5rem;">
              <i class="fas fa-<?= $d['device_type'] === 'mobile' ? 'mobile-alt' : ($d['device_type'] === 'tablet' ? 'tablet-alt' : 'desktop') ?>" style="color:<?= $clr ?>;"></i>
              <?= ucfirst($d['device_type']) ?>
            </span>
            <span style="color:var(--text-muted);"><?= $d['cnt'] ?> (<?= $pct ?>%)</span>
          </div>
          <div style="height:6px;background:rgba(255,255,255,0.05);border-radius:6px;overflow:hidden;">
            <div style="width:<?= $pct ?>%;height:100%;background:<?= $clr ?>;border-radius:6px;transition:width 0.5s;"></div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($devices)): ?>
        <p style="color:var(--text-muted);font-size:0.85rem;text-align:center;">No data yet.</p>
        <?php endif; ?>
      </div>

      <!-- Top Links -->
      <div class="card-box">
        <div class="card-box-header"><span class="card-box-title">Top Links</span></div>
        <?php if (empty($topLinks)): ?>
        <p style="color:var(--text-muted);font-size:0.85rem;text-align:center;">No link clicks yet.</p>
        <?php else: ?>
        <?php foreach ($topLinks as $lnk): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem 0;border-bottom:1px solid rgba(255,255,255,0.04);">
          <div style="display:flex;align-items:center;gap:0.7rem;">
            <div style="width:34px;height:34px;border-radius:10px;background:<?= getSocialColor($lnk['platform']) ?>;display:flex;align-items:center;justify-content:center;color:white;font-size:0.9rem;">
              <i class="<?= getSocialIcon($lnk['platform']) ?>"></i>
            </div>
            <span style="font-size:0.85rem;font-weight:600;"><?= ucfirst($lnk['platform']) ?></span>
          </div>
          <span class="badge badge-info"><?= $lnk['click_count'] ?> clicks</span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
