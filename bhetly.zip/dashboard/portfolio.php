<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$userId = $_SESSION['user_id'];

if (!isPro($userId)) {
  setFlash('error', 'Portfolio is a Pro feature! Upgrade your plan to unlock.');
  redirect(BASE_URL . '/dashboard/subscription');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $itemId = intval($_POST['item_id'] ?? 0);

  if ($action === 'add' || $action === 'edit') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $videoUrl = trim($_POST['video_url'] ?? '');
    $type = 'image';
    $imgFile = $_FILES['portfolio_image'] ?? null;
    $imagePath = $_POST['existing_image'] ?? null;

    // Handle image upload
    if (!empty($_FILES['portfolio_image']['name'])) {
      $imgFile = $_FILES['portfolio_image'];
      if ($imgFile['error'] === UPLOAD_ERR_OK) {
        $result = uploadFile($imgFile, 'portfolio');
        if (isset($result['error'])) {
          setFlash('error', $result['error']);
          redirect(BASE_URL . '/dashboard/portfolio');
        }
        if ($imagePath && $action === 'edit') {
          $oldPath = UPLOAD_PATH . 'portfolio/' . $imagePath;
          if (file_exists($oldPath))
            @unlink($oldPath);
        }
        $imagePath = $result['filename'];
      } elseif ($imgFile['error'] !== UPLOAD_ERR_NO_FILE) {
        setFlash('error', 'File upload error. Please try again.');
        redirect(BASE_URL . '/dashboard/portfolio');
      }
    }

    // Determine item type
    if ($imagePath) {
      $type = (!empty($videoUrl)) ? 'both' : 'image';
    } elseif (!empty($videoUrl)) {
      $type = 'video';
    } else {
      $type = 'image';
    }

    if ($action === 'add') {
      if (empty($title)) {
        setFlash('error', 'Portfolio title is required.');
      } else {
        $title = sanitize($title);
        $description = sanitize($description);
        $pdo->prepare("INSERT INTO portfolio_items (user_id, title, description, image_path, video_url, item_type) VALUES (?,?,?,?,?,?)")
          ->execute([$userId, $title, $description, $imagePath, $videoUrl, $type]);
        setFlash('success', 'Portfolio item added successfully!');
      }
    } else if ($action === 'edit') {
      if (empty($title)) {
        setFlash('error', 'Portfolio title is required.');
      } else {
        $title = sanitize($title);
        $description = sanitize($description);
        $pdo->prepare("UPDATE portfolio_items SET title=?, description=?, image_path=?, video_url=?, item_type=? WHERE id=? AND user_id=?")
          ->execute([$title, $description, $imagePath, $videoUrl, $type, $itemId, $userId]);
        setFlash('success', 'Portfolio item updated successfully!');
      }
    }
  } elseif ($action === 'delete' && $itemId) {
    $stmt = $pdo->prepare("SELECT image_path FROM portfolio_items WHERE id=? AND user_id=?");
    $stmt->execute([$itemId, $userId]);
    $row = $stmt->fetch();
    if ($row && $row['image_path'])
      @unlink(UPLOAD_PATH . 'portfolio/' . $row['image_path']);
    $pdo->prepare("DELETE FROM portfolio_items WHERE id=? AND user_id=?")->execute([$itemId, $userId]);
    setFlash('success', 'Portfolio item deleted.');
  }
  redirect(BASE_URL . '/dashboard/portfolio');
}

$items = getPortfolioItems($userId);
include __DIR__ . '/../includes/header.php';
?>

<!-- Portfolio-specific CSS: uses pf-* classes to avoid ALL Bootstrap 5 conflicts -->
<style>
  /* ===== PORTFOLIO FORM — FULLY ISOLATED FROM BOOTSTRAP ===== */
  .pf-form-wrap {
    background: var(--dark-2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 1.5rem;
    margin-bottom: 1.5rem;
  }

  .pf-form-header {
    font-size: 1rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .pf-row {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
    margin-bottom: 1rem;
  }

  .pf-col {
    flex: 1;
    min-width: 200px;
  }

  .pf-label {
    display: block;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 0.4rem;
  }

  /* THE KEY: pf-input uses NO Bootstrap classes at all */
  .pf-input,
  .pf-textarea {
    display: block !important;
    width: 100% !important;
    padding: 0.75rem 1rem !important;
    font-size: 0.95rem !important;
    font-family: inherit !important;
    color: var(--text-primary) !important;
    background-color: #fff !important;
    border: 1.5px solid rgba(15, 23, 42, 0.15) !important;
    border-radius: 10px !important;
    outline: none !important;
    box-shadow: none !important;
    transition: border-color 0.2s, box-shadow 0.2s !important;
    cursor: text !important;
    /* These are critical to ensure clickability */
    position: static !important;
    z-index: auto !important;
    pointer-events: auto !important;
    -webkit-appearance: none !important;
    appearance: none !important;
    box-sizing: border-box !important;
  }

  .pf-input:focus,
  .pf-textarea:focus {
    border-color: var(--primary) !important;
    box-shadow: 0 0 0 3px rgba(15, 76, 129, 0.12) !important;
    outline: none !important;
  }

  .pf-input::placeholder,
  .pf-textarea::placeholder {
    color: #9ca3af !important;
    opacity: 1 !important;
  }

  .pf-textarea {
    resize: vertical !important;
    min-height: 80px !important;
  }

  .pf-hint {
    display: block;
    font-size: 0.75rem;
    color: var(--text-muted);
    margin-top: 0.3rem;
  }

  /* Video URL wrapper — uses pf- prefix, no Bootstrap input-group */
  .pf-url-wrap {
    position: relative !important;
    display: block !important;
  }

  .pf-url-icon {
    position: absolute !important;
    left: 0.85rem !important;
    top: 50% !important;
    transform: translateY(-50%) !important;
    color: #9ca3af !important;
    font-size: 0.9rem !important;
    pointer-events: none !important;
    z-index: 2 !important;
  }

  .pf-url-input {
    padding-left: 2.6rem !important;
  }

  /* File input */
  .pf-file {
    display: block !important;
    width: 100% !important;
    padding: 0.6rem 1rem !important;
    font-size: 0.9rem !important;
    font-family: inherit !important;
    color: var(--text-primary) !important;
    background: #fff !important;
    border: 1.5px solid rgba(15, 23, 42, 0.15) !important;
    border-radius: 10px !important;
    cursor: pointer !important;
    pointer-events: auto !important;
    position: static !important;
    z-index: auto !important;
    box-sizing: border-box !important;
  }

  .pf-file::-webkit-file-upload-button {
    padding: 0.4rem 1rem;
    background: var(--primary);
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 0.85rem;
    margin-right: 0.75rem;
  }

  .pf-actions {
    display: flex;
    gap: 1rem;
    align-items: flex-end;
    flex-wrap: wrap;
    margin-top: 1rem;
  }

  .pf-submit {
    padding: 0.65rem 2rem;
    background: linear-gradient(135deg, var(--primary), var(--primary-light));
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    transition: transform 0.2s, box-shadow 0.2s;
    pointer-events: auto !important;
  }

  .pf-submit:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(15, 76, 129, 0.35);
  }

  .pf-img-preview {
    margin-top: 0.5rem;
  }

  .pf-img-preview img {
    max-width: 100px;
    max-height: 100px;
    border-radius: 6px;
    border: 1px solid var(--border);
  }

  /* ===== EDIT MODAL — fully isolated ===== */
  .pf-modal-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.55);
    backdrop-filter: blur(4px);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 1rem;
  }

  .pf-modal-overlay.pf-show {
    display: flex !important;
  }

  .pf-modal-box {
    background: #fff;
    border-radius: 16px;
    width: 100%;
    max-width: 540px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
    animation: pfSlideIn 0.25s ease;
  }

  @keyframes pfSlideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }

    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .pf-modal-head {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid rgba(0, 0, 0, 0.08);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pf-modal-title {
    font-size: 1.05rem;
    font-weight: 700;
    color: #1d1d1f;
  }

  .pf-modal-close {
    background: none;
    border: none;
    font-size: 1.2rem;
    cursor: pointer;
    color: #86868b;
    line-height: 1;
    padding: 0.25rem;
    pointer-events: auto !important;
  }

  .pf-modal-close:hover {
    color: #dc3545;
  }

  .pf-modal-body {
    padding: 1.5rem;
  }

  .pf-modal-foot {
    padding: 1rem 1.5rem;
    border-top: 1px solid rgba(0, 0, 0, 0.08);
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
  }

  .pf-btn-cancel {
    padding: 0.6rem 1.25rem;
    background: #f3f4f6;
    color: #374151;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    pointer-events: auto !important;
  }

  .pf-btn-save {
    padding: 0.6rem 1.5rem;
    background: linear-gradient(135deg, var(--primary), var(--primary-light));
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    pointer-events: auto !important;
  }

  .pf-form-group {
    margin-bottom: 1.1rem;
  }
</style>

<div class="page-content">
  <div class="page-header"
    style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem;">
    <div>
      <h2 class="page-title">Portfolio</h2>
      <p class="page-subtitle">Showcase your work with images and videos</p>
    </div>
  </div>

  <!-- ADD FORM — fully isolated from Bootstrap -->
  <div class="pf-form-wrap">
    <div class="pf-form-header">
      <i class="fas fa-plus-circle" style="color:var(--primary);"></i>
      Add New Portfolio Item
    </div>
    <form method="POST" action="<?= BASE_URL ?>/dashboard/portfolio" enctype="multipart/form-data" id="pfAddForm">
      <input type="hidden" name="action" value="add">
      <div class="pf-row">
        <div class="pf-col">
          <label class="pf-label" for="addTitle">Project Title <span style="color:#dc3545;">*</span></label>
          <input type="text" id="addTitle" name="title" class="pf-input" placeholder="Enter project name"
            maxlength="200" required autocomplete="off">
          <span class="pf-hint">Required field</span>
        </div>
        <div class="pf-col">
          <label class="pf-label" for="addVideoUrl">Video URL <span
              style="color:#9ca3af;font-weight:400;">(optional)</span></label>
          <div class="pf-url-wrap">
            <i class="fas fa-video pf-url-icon"></i>
            <input type="url" id="addVideoUrl" name="video_url" class="pf-input pf-url-input"
              placeholder="https://youtube.com/watch?v=..." autocomplete="off">
          </div>
          <span class="pf-hint">YouTube video link</span>
        </div>
      </div>
      <div class="pf-form-group">
        <label class="pf-label" for="addDesc">Description <span
            style="color:#9ca3af;font-weight:400;">(optional)</span></label>
        <textarea id="addDesc" name="description" class="pf-textarea" rows="3"
          placeholder="Brief description of your project..." maxlength="500"></textarea>
      </div>
      <div class="pf-actions">
        <div style="flex:1;">
          <label class="pf-label" for="addImage">Upload Image <span
              style="color:#9ca3af;font-weight:400;">(optional)</span></label>
          <input type="file" id="addImage" name="portfolio_image" class="pf-file"
            accept="image/jpeg,image/png,image/gif,image/webp">
          <span class="pf-hint">Max 5MB · JPG, PNG, GIF, WEBP</span>
          <div class="pf-img-preview" id="addImgPreview"></div>
        </div>
        <button type="submit" class="pf-submit">
          <i class="fas fa-plus"></i> Create Item
        </button>
      </div>
    </form>
  </div>

  <!-- PORTFOLIO GRID -->
  <?php if (empty($items)): ?>
    <div class="pf-form-wrap" style="text-align:center;padding:3rem;">
      <i class="fas fa-briefcase" style="font-size:3rem;color:var(--text-muted);margin-bottom:1rem;display:block;"></i>
      <p style="color:var(--text-secondary);">No portfolio items yet. Add your first project above!</p>
    </div>
  <?php else: ?>
    <div class="portfolio-grid">
      <?php foreach ($items as $item): ?>
        <div class="portfolio-item">
          <?php if ($item['image_path']): ?>
            <img src="<?= UPLOAD_URL ?>portfolio/<?= htmlspecialchars($item['image_path']) ?>" class="portfolio-item-img"
              alt="<?= htmlspecialchars($item['title']) ?>">
          <?php elseif ($item['video_url']): ?>
            <div style="height:150px;background:var(--dark);display:flex;align-items:center;justify-content:center;">
              <i class="fab fa-youtube" style="font-size:2.5rem;color:#FF0000;"></i>
            </div>
          <?php else: ?>
            <div style="height:150px;background:var(--dark);display:flex;align-items:center;justify-content:center;">
              <i class="fas fa-image" style="font-size:2rem;color:var(--text-muted);"></i>
            </div>
          <?php endif; ?>
          <div class="portfolio-item-body">
            <div class="portfolio-item-title"><?= htmlspecialchars($item['title']) ?></div>
            <div class="portfolio-item-desc">
              <?= htmlspecialchars(mb_substr($item['description'] ?? '', 0, 80)) ?>    <?= strlen($item['description'] ?? '') > 80 ? '...' : '' ?>
            </div>
          </div>
          <div class="portfolio-item-actions">
            <button class="btn btn-secondary btn-icon"
              onclick="pfOpenEdit(<?= $item['id'] ?>, '<?= htmlspecialchars(addslashes($item['title'])) ?>', '<?= htmlspecialchars(addslashes($item['description'] ?? '')) ?>', '<?= htmlspecialchars(addslashes($item['video_url'] ?? '')) ?>', '<?= htmlspecialchars($item['image_path'] ?? '') ?>')">
              <i class="fas fa-edit"></i>
            </button>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this item?')">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
              <button type="submit" class="btn btn-danger btn-icon"><i class="fas fa-trash"></i></button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>


<!-- EDIT MODAL — uses pf-modal-* classes, NOT Bootstrap modal classes -->
<div class="pf-modal-overlay" id="pfEditModal">
  <div class="pf-modal-box" onclick="event.stopPropagation()">
    <div class="pf-modal-head">
      <span class="pf-modal-title"><i class="fas fa-edit" style="color:var(--primary);margin-right:0.5rem;"></i>Edit
        Portfolio Item</span>
      <button class="pf-modal-close" type="button" onclick="pfCloseEdit()"><i class="fas fa-times"></i></button>
    </div>
    <div class="pf-modal-body">
      <form method="POST" enctype="multipart/form-data" action="<?= BASE_URL ?>/dashboard/portfolio" id="pfEditForm">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="item_id" id="pfEditId">
        <input type="hidden" name="existing_image" id="pfEditImg">

        <div class="pf-form-group">
          <label class="pf-label" for="pfEditTitle">Project Title <span style="color:#dc3545;">*</span></label>
          <input type="text" id="pfEditTitle" name="title" class="pf-input" placeholder="Enter project name"
            maxlength="200" required autocomplete="off">
        </div>

        <div class="pf-form-group">
          <label class="pf-label" for="pfEditDesc">Description</label>
          <textarea id="pfEditDesc" name="description" class="pf-textarea" rows="3"
            placeholder="Brief description of your project..." maxlength="500"></textarea>
        </div>

        <div class="pf-form-group">
          <label class="pf-label" for="pfEditVideo">Video URL <span
              style="color:#9ca3af;font-weight:400;">(optional)</span></label>
          <div class="pf-url-wrap">
            <i class="fas fa-video pf-url-icon"></i>
            <input type="url" id="pfEditVideo" name="video_url" class="pf-input pf-url-input"
              placeholder="https://youtube.com/watch?v=..." autocomplete="off">
          </div>
        </div>

        <div class="pf-form-group">
          <label class="pf-label" for="pfEditImage">Replace Image <span
              style="color:#9ca3af;font-weight:400;">(optional)</span></label>
          <input type="file" id="pfEditImage" name="portfolio_image" class="pf-file"
            accept="image/jpeg,image/png,image/gif,image/webp">
          <span class="pf-hint">Leave empty to keep existing image · Max 5MB</span>
          <div class="pf-img-preview" id="editImgPreview"></div>
        </div>

        <div class="pf-modal-foot" style="padding:0;border:none;margin-top:1rem;">
          <button type="button" class="pf-btn-cancel" onclick="pfCloseEdit()">Cancel</button>
          <button type="submit" class="pf-btn-save"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  // === Portfolio Modal ===
  function pfOpenEdit(id, title, desc, video, img) {
    document.getElementById('pfEditId').value = id;
    document.getElementById('pfEditTitle').value = title;
    document.getElementById('pfEditDesc').value = desc;
    document.getElementById('pfEditVideo').value = video;
    document.getElementById('pfEditImg').value = img;
    document.getElementById('editImgPreview').innerHTML = '';
    document.getElementById('pfEditModal').classList.add('pf-show');
    // Force inputs interactive after modal opens
    setTimeout(function () {
      document.querySelectorAll('#pfEditModal input, #pfEditModal textarea').forEach(function (el) {
        el.style.pointerEvents = 'auto';
        el.style.position = 'static';
        el.style.zIndex = 'auto';
      });
      document.getElementById('pfEditTitle').focus();
    }, 50);
  }

  function pfCloseEdit() {
    document.getElementById('pfEditModal').classList.remove('pf-show');
  }

  // Close modal when clicking backdrop
  document.getElementById('pfEditModal').addEventListener('click', function (e) {
    if (e.target === this) pfCloseEdit();
  });

  // Image preview — add form
  document.getElementById('addImage').addEventListener('change', function () {
    var preview = document.getElementById('addImgPreview');
    preview.innerHTML = '';
    var file = this.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      preview.innerHTML = '<small style="color:#dc3545;">File exceeds 5MB limit</small>';
      this.value = '';
      return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
      preview.innerHTML = '<img src="' + e.target.result + '">';
    };
    reader.readAsDataURL(file);
  });

  // Image preview — edit form
  document.getElementById('pfEditImage').addEventListener('change', function () {
    var preview = document.getElementById('editImgPreview');
    preview.innerHTML = '';
    var file = this.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      preview.innerHTML = '<small style="color:#dc3545;">File exceeds 5MB limit</small>';
      this.value = '';
      return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
      preview.innerHTML = '<img src="' + e.target.result + '">';
    };
    reader.readAsDataURL(file);
  });

  // Safety: on page load, ensure all pf-inputs are interactive
  window.addEventListener('load', function () {
    document.querySelectorAll('.pf-input, .pf-textarea, .pf-file').forEach(function (el) {
      el.style.pointerEvents = 'auto';
      el.style.position = 'static';
      el.style.zIndex = 'auto';
    });
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>