<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'change_password') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();

    if (!$row || empty($row['password'])) {
      setFlash('error', 'Account not found. Please log in again.');
      redirect(BASE_URL . '/logout');
    }

    if (!password_verify($current, $row['password'])) {
      setFlash('error', 'Current password is incorrect.');
    } elseif (strlen($new) < 8) {
      setFlash('error', 'New password must be at least 8 characters.');
    } elseif ($new !== $confirm) {
      setFlash('error', 'Passwords do not match.');
    } else {
      $hashed = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
      $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hashed, $userId]);
      setFlash('success', 'Password changed successfully!');
    }
  }
  redirect(BASE_URL . '/dashboard/settings');
}

$user = getCurrentUser();
include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Settings</h2>
    <p class="page-subtitle">Manage your account security and preferences</p>
  </div>

  <div class="row g-3">
    <div class="col-lg-8">
      <!-- Account Info -->
      <div class="card-box mb-3">
        <div class="card-box-header"><span class="card-box-title"><i class="fas fa-user-shield"></i> Account
            Information</span></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;font-size:0.9rem;">
          <div>
            <div style="color:var(--text-muted);font-size:0.78rem;margin-bottom:0.25rem;">NAME</div>
            <div style="font-weight:600;"><?= htmlspecialchars($user['name']) ?></div>
          </div>
          <div>
            <div style="color:var(--text-muted);font-size:0.78rem;margin-bottom:0.25rem;">EMAIL</div>
            <div style="font-weight:600;"><?= htmlspecialchars($user['email']) ?></div>
          </div>
          <div>
            <div style="color:var(--text-muted);font-size:0.78rem;margin-bottom:0.25rem;">USERNAME</div>
            <div style="font-weight:600;">@<?= htmlspecialchars($user['username']) ?></div>
          </div>
          <div>
            <div style="color:var(--text-muted);font-size:0.78rem;margin-bottom:0.25rem;">PLAN</div>
            <div style="font-weight:600;"><?= ucfirst($user['plan']) ?>
              <?= $user['plan'] === 'pro' ? '<span style="color:#FFB547;"><i class="fas fa-crown"></i></span>' : '' ?>
            </div>
          </div>
          <div>
            <div style="color:var(--text-muted);font-size:0.78rem;margin-bottom:0.25rem;">MEMBER SINCE</div>
            <div style="font-weight:600;"><?= date('M d, Y', strtotime($user['created_at'])) ?></div>
          </div>
        </div>
      </div>

      <!-- Change Password -->
      <div class="card-box mb-3">
        <div class="card-box-header"><span class="card-box-title"><i class="fas fa-lock"></i> Change Password</span>
        </div>
        <form method="POST" data-loading="true">
          <input type="hidden" name="action" value="change_password">
          <div class="form-group">
            <label class="form-label">Current Password</label>
            <div class="input-group">
              <i class="fas fa-lock input-icon"></i>
              <input type="password" name="current_password" id="curPass" class="form-control"
                placeholder="Current password" required>
              <i class="fas fa-eye input-eye" data-target="curPass"></i>
            </div>
          </div>
          <div class="row g-2">
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">New Password</label>
                <div class="input-group">
                  <i class="fas fa-key input-icon"></i>
                  <input type="password" name="new_password" id="newPass" class="form-control"
                    placeholder="Min 8 characters" required minlength="8">
                  <i class="fas fa-eye input-eye" data-target="newPass"></i>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label class="form-label">Confirm New Password</label>
                <div class="input-group">
                  <i class="fas fa-key input-icon"></i>
                  <input type="password" name="confirm_password" id="conPass" class="form-control"
                    placeholder="Repeat password" required>
                  <i class="fas fa-eye input-eye" data-target="conPass"></i>
                </div>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Update Password</button>
        </form>
      </div>

      <!-- Danger Zone -->
      <div class="card-box" style="border-color:rgba(255,90,110,0.3);">
        <div class="card-box-header"><span class="card-box-title" style="color:var(--danger);"><i
              class="fas fa-triangle-exclamation"></i> Danger Zone</span></div>
        <p style="color:var(--text-secondary);font-size:0.9rem;margin-bottom:1rem;">Permanently delete your account and
          all associated data. This action cannot be undone.</p>
        <button class="btn btn-danger btn-sm" data-modal="deleteModal"><i class="fas fa-trash"></i> Delete
          Account</button>
      </div>
    </div>

    <!-- Quick Links sidebar -->
    <div class="col-lg-4">
      <div class="card-box">
        <div class="card-box-header"><span class="card-box-title">Quick Actions</span></div>
        <div style="display:flex;flex-direction:column;gap:0.75rem;">
          <a href="<?= BASE_URL ?>/<?= htmlspecialchars($user['username']) ?>" target="_blank"
            class="btn btn-secondary"><i class="fas fa-external-link-alt"></i> View Public Card</a>
          <a href="<?= BASE_URL ?>/api/generate_vcf" class="btn btn-secondary"><i class="fas fa-address-card"></i>
            Download vCard</a>
          <a href="<?= BASE_URL ?>/dashboard/subscription" class="btn btn-secondary"><i class="fas fa-crown"></i>
            Manage Subscription</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal-overlay" id="deleteModal">
  <div class="modal-dialog">
    <div class="modal-header" style="border-color:rgba(255,90,110,0.2);">
      <span class="modal-title" style="color:var(--danger);"><i class="fas fa-triangle-exclamation"></i> Delete
        Account</span>
      <button class="btn-close-modal" data-close-modal><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <p style="color:var(--text-secondary);margin-bottom:1.25rem;">This will permanently delete your account, profile,
        links, and all data. <strong style="color:var(--danger);">This cannot be undone.</strong></p>
      <div class="form-group">
        <label class="form-label">Confirm account deletion</label>
        <div class="alert alert-warning" style="margin-bottom:0;">
          Clicking <strong>Delete My Account</strong> will permanently remove your profile.
        </div>
      </div>
      <div class="modal-footer" style="padding:0;border:none;margin-top:1.5rem;">
        <button type="button" class="btn btn-secondary" data-close-modal>Cancel</button>
        <button type="button" class="btn btn-danger" style="position:relative;z-index:3003;pointer-events:auto;"
          onclick="window.location.href='<?= BASE_URL ?>/dashboard/delete_account?confirm=1'"><i
            class="fas fa-trash"></i> Delete My Account</button>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>