<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn())
  redirect(BASE_URL . '/dashboard/index');

$token = sanitize($_GET['token'] ?? '');
$error = $success = '';

// Validate token
$tokenRow = null;
if ($token) {
  $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ? AND used = 0 AND expires_at > NOW()");
  $stmt->execute([$token]);
  $tokenRow = $stmt->fetch();
}

if (!$token || !$tokenRow) {
  $error = 'This reset link is invalid or has expired. <a href="' . BASE_URL . '/auth/forgot_password">Request a new one</a>.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $tokenRow) {
  $password = $_POST['password'] ?? '';
  $confirm = $_POST['confirm_password'] ?? '';

  if (strlen($password) < 8) {
    $error = 'Password must be at least 8 characters.';
  } elseif ($password !== $confirm) {
    $error = 'Passwords do not match.';
  } else {
    $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $pdo->prepare("UPDATE users SET password = ? WHERE email = ?")->execute([$hashed, $tokenRow['email']]);
    $pdo->prepare("UPDATE password_resets SET used = 1 WHERE token = ?")->execute([$token]);
    setFlash('success', 'Password reset successfully! You can now login.');
    redirect(BASE_URL . '/auth/login');
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reset Password - <?= SITE_NAME ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>

<body>
  <div class="auth-layout">
    <div class="auth-card">
      <div class="auth-logo">
        <img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>" class="mb-3"
          style="height: 50px; width: 150px;">
        <div>
          <h1 class="auth-title">Reset Password</h1>
          <p class="auth-subtitle">Choose a strong new password</p>
        </div>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i> <?= $error ?></div>
      <?php elseif ($tokenRow): ?>
        <form method="POST" data-loading="true">
          <div class="form-group">
            <label class="form-label">New Password</label>
            <div class="input-group">
              <i class="fas fa-lock input-icon"></i>
              <input type="password" name="password" id="npass" class="form-control" placeholder="Min 8 characters"
                required minlength="8">
              <i class="fas fa-eye input-eye" data-target="npass"></i>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm New Password</label>
            <div class="input-group">
              <i class="fas fa-lock input-icon"></i>
              <input type="password" name="confirm_password" id="cpass" class="form-control" placeholder="Repeat password"
                required>
              <i class="fas fa-eye input-eye" data-target="cpass"></i>
            </div>
          </div>
          <button type="submit" class="btn-submit">Reset Password</button>
        </form>
      <?php endif; ?>

      <div class="auth-footer"><a href="<?= BASE_URL ?>/auth/login"><i class="fas fa-arrow-left"></i> Back to Login</a>
      </div>
    </div>
  </div>
  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>

</html>