<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn())
  redirect(BASE_URL . '/dashboard/index');

$flash = getFlash();
$error = '';
$googleLoginUrl = BASE_URL . '/auth/google.php';

if (!empty($_GET['redirect'])) {
  $googleLoginUrl .= '?redirect=' . urlencode($_GET['redirect']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = sanitize($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  if (!$email || !$password) {
    $error = 'Please enter your email and password.';
  } else {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
      if (!$user['is_active']) {
        $error = 'Your account has been suspended. Contact support.';
      } else {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['username'] = $user['username'];
        $redirect = $_GET['redirect'] ?? BASE_URL . '/dashboard/index';
        if ($user['role'] === 'admin')
          $redirect = BASE_URL . '/admin/index';
        redirect($redirect);
      }
    } else {
      $error = 'Invalid email or password.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - <?= SITE_NAME ?></title>
  <meta name="description" content="Sign in to your NFC Digital Business Card dashboard.">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/img/fav.png?v=<?= time() ?>">
</head>

<body>

  <div class="auth-layout">
    <div class="auth-card">
      <div class="auth-logo text-center mb-4">
        <a href="<?= BASE_URL ?>" class="d-inline-block">
          <img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>" class="mb-3"
            style="height: 50px; width: 150px;">
        </a>
        <div>
          <h1 class="auth-title">Welcome Back</h1>
          <p class="auth-subtitle">Sign in to access your dashboard</p>
        </div>
      </div>

      <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-auto-dismiss">
          <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'circle-exclamation' ?>"></i>
          <?= htmlspecialchars($flash['msg']) ?>
        </div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <style>
        .btn-google {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.75rem;
          width: 100%;
          padding: 0.75rem 1.5rem;
          background-color: #fff;
          color: #3c4043;
          border: 1px solid #dadce0;
          border-radius: 10px;
          font-size: 0.95rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          text-decoration: none;
          box-shadow: 0 1px 2px 0 rgba(60, 64, 67, 0.1);
        }

        .btn-google:hover {
          background-color: #f8f9fa;
          box-shadow: 0 4px 6px -1px rgba(60, 64, 67, 0.1), 0 2px 4px -1px rgba(60, 64, 67, 0.06);
          color: #3c4043;
          border-color: #d2e3fc;
        }

        .btn-google img {
          height: 20px;
          width: 20px;
        }

        .auth-divider {
          display: flex;
          align-items: center;
          text-align: center;
          margin: 1.5rem 0;
          color: #8c8c8c;
          font-size: 0.85rem;
        }

        .auth-divider::before,
        .auth-divider::after {
          content: '';
          flex: 1;
          border-bottom: 1px solid #e2e8f0;
        }

        .auth-divider:not(:empty)::before {
          margin-right: .75em;
        }

        .auth-divider:not(:empty)::after {
          margin-left: .75em;
        }
      </style>

      <a class="btn-google" href="<?= $googleLoginUrl ?? '#' ?>">
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/3840px-Google_%22G%22_logo.svg.png"
          alt="Google Logo">
        Continue with Google
      </a>

      <div class="auth-divider">or sign in with email</div>

      <form method="POST" data-loading="true">
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <div class="input-group">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" name="email" class="form-control" placeholder="ram@example.com"
              value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" style="display:flex;justify-content:space-between;">
            Password
            <a href="<?= BASE_URL ?>/forgot-password" style="font-size:0.82rem;color:var(--primary);">Forgot
              password?</a>
          </label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" name="password" id="password" class="form-control" placeholder="xxxxxxxxxx" required>
            <i class="fas fa-eye input-eye" data-target="password"></i>
          </div>
        </div>

        <button type="submit" class="btn-submit">Sign In <i class="fas fa-arrow-right"
            style="margin-left:0.5rem;"></i></button>
      </form>

      <div class="auth-footer mt-4">
        Don't have an account? <a href="<?= BASE_URL ?>/register">Create free account</a><br>
        <div class="mt-3" style="font-size: 0.8rem; opacity: 0.7;">
          <a href="<?= BASE_URL ?>/privacy" style="color: inherit;">Privacy Policy</a> &bull;
          <a href="<?= BASE_URL ?>/terms" style="color: inherit;">Terms of Service</a>
        </div>
      </div>
    </div>
  </div>

  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>

</body>

</html>