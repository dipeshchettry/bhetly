<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn())
  redirect(BASE_URL . '/dashboard/index');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = sanitize($_POST['name'] ?? '');
  $email = sanitize($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $confirm = $_POST['confirm_password'] ?? '';

  if (!$name || !$email || !$password) {
    $error = 'All fields are required.';
  } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Please enter a valid email address.';
  } elseif (strlen($password) < 8) {
    $error = 'Password must be at least 8 characters.';
  } elseif ($password !== $confirm) {
    $error = 'Passwords do not match.';
  } else {
    // Check existing
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
      $error = 'Email already exists.';
    } else {
      $firstName = explode(' ', trim($name))[0];
      $username = generateUniqueUsername($firstName);
      $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
      $pdo->prepare("INSERT INTO users (name, email, username, password, is_verified) VALUES (?, ?, ?, ?, 0)")
        ->execute([$name, $email, $username, $hashed]);
      $userId = $pdo->lastInsertId();
      // Create empty profile
      $pdo->prepare("INSERT INTO profiles (user_id) VALUES (?)")->execute([$userId]);

      // Do not block registration if email delivery fails.
      $mailSent = sendWelcomeEmail($name, $email, $username);

      if ($mailSent) {
        setFlash('success', 'Account created! Welcome email sent. Your profile will be visible after admin approval. Please log in.');
      } else {
        setFlash('success', 'Account created! Your profile will be visible after admin approval. Please log in. Welcome email could not be sent right now.');
      }
      redirect(BASE_URL . '/login');
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Create Account - <?= SITE_NAME ?></title>
  <meta name="description" content="Create your NFC Digital Business Card account for free.">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="icon" href="<?= BASE_URL ?>/assets/img/fav.png?v=<?= time() ?>" type="image/png">
</head>

<body>

  <div class="auth-layout">
    <div class="auth-card">
      <div class="auth-logo text-center mb-4">
        <a href="<?= BASE_URL ?>" class="d-inline-block">
          <img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>" class="mb-3"
            style="height: 50px; width: 150px;">
        </a>
        <div>
          <h1 class="auth-title">Create Account</h1>
          <p class="auth-subtitle">Start your digital business card journey</p>
        </div>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" data-loading="true">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <div class="input-group">
            <i class="fas fa-user input-icon"></i>
            <input type="text" name="name" class="form-control" placeholder="Ram Sharma"
              value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Email Address</label>
          <div class="input-group">
            <i class="fas fa-envelope input-icon"></i>
            <input type="email" name="email" class="form-control" placeholder="ram@example.com"
              value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          </div>
        </div>



        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" name="password" id="password" class="form-control" placeholder="Min 8 characters"
              required minlength="8">
            <i class="fas fa-eye input-eye" data-target="password"></i>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Confirm Password</label>
          <div class="input-group">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control"
              placeholder="Repeat password" required>
            <i class="fas fa-eye input-eye" data-target="confirm_password"></i>
          </div>
        </div>

        <button type="submit" class="btn-submit">Create Free Account</button>
      </form>

      <div class="auth-footer mt-4">
        Already have an account? <a href="<?= BASE_URL ?>/login">Sign In</a><br>
        <div class="mt-3" style="font-size: 0.8rem; opacity: 0.7;">
          By creating an account, you agree to our <a href="<?= BASE_URL ?>/terms"
            style="color: inherit; text-decoration: underline;">Terms</a> and <a href="<?= BASE_URL ?>/privacy"
            style="color: inherit; text-decoration: underline;">Privacy Policy</a>.
        </div>
      </div>
    </div>
  </div>

  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>

</body>

</html>