<?php
require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '/dashboard/index');
}

if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
    setFlash('danger', 'Google sign-in is not configured yet.');
    redirect(BASE_URL . '/login');
}

function googleCurlRequest($url, $method = 'GET', array $payload = [], array $headers = []) {
    if (!function_exists('curl_init')) {
        return [null, 0, 'cURL extension is not enabled.'];
    }

    $curl = curl_init($url);
    $defaultHeaders = ['Accept: application/json'];

    if ($method === 'POST') {
        $defaultHeaders[] = 'Content-Type: application/x-www-form-urlencoded';
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($payload));
    }

    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers),
        CURLOPT_TIMEOUT => 15,
    ]);

    $response = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);

    if ($response === false) {
        $error = curl_error($curl);
        curl_close($curl);
        return [null, $status, $error ?: 'Google request failed.'];
    }

    curl_close($curl);
    return [$response, $status, null];
}

$requestedRedirect = safeRedirectTarget($_GET['redirect'] ?? '', BASE_URL . '/dashboard/index');

if (!isset($_GET['code'])) {
    $state = bin2hex(random_bytes(16));
    $_SESSION['google_oauth_state'] = $state;
    $_SESSION['google_oauth_redirect'] = $requestedRedirect;

    $query = http_build_query([
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'response_type' => 'code',
        'scope' => 'openid email profile',
        'access_type' => 'online',
        'prompt' => 'select_account',
        'state' => $state,
        'include_granted_scopes' => 'true',
    ]);

    redirect('https://accounts.google.com/o/oauth2/v2/auth?' . $query);
}

if (isset($_GET['error'])) {
    setFlash('danger', 'Google sign-in was cancelled or failed.');
    redirect(BASE_URL . '/login');
}

if (empty($_GET['state']) || empty($_SESSION['google_oauth_state']) || !hash_equals($_SESSION['google_oauth_state'], $_GET['state'])) {
    unset($_SESSION['google_oauth_state'], $_SESSION['google_oauth_redirect']);
    setFlash('danger', 'Google sign-in could not be verified. Please try again.');
    redirect(BASE_URL . '/login');
}

unset($_SESSION['google_oauth_state']);

[$tokenBody, $tokenStatus] = googleCurlRequest(
    'https://oauth2.googleapis.com/token',
    'POST',
    [
        'code' => $_GET['code'],
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'redirect_uri' => GOOGLE_REDIRECT_URI,
        'grant_type' => 'authorization_code',
    ]
);

if ($tokenStatus !== 200 || !$tokenBody) {
    setFlash('danger', 'Google sign-in failed while exchanging the authorization code.');
    redirect(BASE_URL . '/login');
}

$tokenData = json_decode($tokenBody, true);
if (empty($tokenData['access_token'])) {
    setFlash('danger', 'Google sign-in did not return an access token.');
    redirect(BASE_URL . '/login');
}

[$userBody, $userStatus] = googleCurlRequest(
    'https://www.googleapis.com/oauth2/v2/userinfo',
    'GET',
    [],
    ['Authorization: Bearer ' . $tokenData['access_token']]
);

if ($userStatus !== 200 || !$userBody) {
    setFlash('danger', 'Google sign-in could not load your profile.');
    redirect(BASE_URL . '/login');
}

$googleUser = json_decode($userBody, true);
$email = sanitize($googleUser['email'] ?? '');
$name = sanitize($googleUser['name'] ?? '');

if (!$email || empty($googleUser['verified_email'])) {
    setFlash('danger', 'Google account email could not be verified.');
    redirect(BASE_URL . '/login');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && !$user['is_active']) {
    setFlash('danger', 'Your account has been suspended. Contact support.');
    redirect(BASE_URL . '/login');
}

if (!$user) {
    $username = generateUniqueUsername($name ?: explode('@', $email)[0]);
    $randomPassword = password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT, ['cost' => 12]);

    $pdo->prepare('INSERT INTO users (name, email, password, username, is_verified, is_active) VALUES (?, ?, ?, ?, 0, 1)')
        ->execute([$name ?: $email, $email, $randomPassword, $username]);

    $userId = (int) $pdo->lastInsertId();
    ensureUserProfile($userId);

    // Send welcome email immediately for newly created Google accounts.
    sendWelcomeEmail($name ?: $email, $email, $username);

    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
} else {
    ensureUserProfile($user['id']);
}

if (!$user) {
    setFlash('danger', 'Google sign-in could not create your account.');
    redirect(BASE_URL . '/login');
}

setUserSession($user);

$destination = $_SESSION['google_oauth_redirect'] ?? BASE_URL . '/dashboard/index';
unset($_SESSION['google_oauth_redirect']);

if ($user['role'] === 'admin') {
    $destination = BASE_URL . '/admin/index';
}

redirect($destination);