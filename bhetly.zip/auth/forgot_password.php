<?php
require_once __DIR__ . '/../includes/functions.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// --- Try to load PHPMailer (composer or manual) ---
$phpmailerLoaded = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
  require_once __DIR__ . '/../vendor/autoload.php';
  $phpmailerLoaded = class_exists('PHPMailer\PHPMailer\PHPMailer');
} elseif (file_exists(__DIR__ . '/../phpmailer/src/PHPMailer.php')) {
  require_once __DIR__ . '/../phpmailer/src/Exception.php';
  require_once __DIR__ . '/../phpmailer/src/PHPMailer.php';
  require_once __DIR__ . '/../phpmailer/src/SMTP.php';
  $phpmailerLoaded = true;
}

if (isLoggedIn())
  redirect(BASE_URL . '/dashboard/index');

$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = sanitize($_POST['email'] ?? '');

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $error = 'Please enter a valid email address.';
  } else {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
      // Delete old tokens
      $pdo->prepare("DELETE FROM password_resets WHERE email = ?")->execute([$email]);

      $token = bin2hex(random_bytes(32));

      $pdo->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))")
        ->execute([$email, $token]);

      $resetLink = BASE_URL . '/auth/reset_password?token=' . $token;

      if ($phpmailerLoaded && SMTP_USER !== 'your_email@gmail.com') {
        try {
          $mail = new PHPMailer(true);
          $mail->isSMTP();
          $mail->Host = SMTP_HOST;
          $mail->SMTPAuth = true;
          $mail->Username = SMTP_USER;
          $mail->Password = SMTP_PASS;
          $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
          $mail->Port = SMTP_PORT;
          $mail->setFrom(SMTP_USER, SMTP_FROM_NAME);
          $mail->addAddress($email, $user['name']);
          $mail->isHTML(true);
          $mail->Subject = 'Reset Your Password - ' . SITE_NAME;
          $mail->Body = "
                    <div style='font-family:Inter,sans-serif;max-width:500px;margin:auto;background:#13132a;color:#fff;border-radius:16px;overflow:hidden;'>
                      <div style='background:linear-gradient(135deg,#6C63FF,#43D9B4);padding:2rem;text-align:center;'>
                        <h2 style='margin:0;'>Reset Your Password</h2>
                      </div>
                      <div style='padding:2rem;'>
                        <p>Hi {$user['name']},</p>
                        <p>Click the button below to reset your password. This link expires in 1 hour.</p>
                        <a href='$resetLink' style='display:inline-block;background:linear-gradient(135deg,#6C63FF,#8b85ff);color:white;padding:0.9rem 2rem;border-radius:50px;font-weight:700;text-decoration:none;margin:1rem 0;'>Reset Password</a>
                        <p style='color:#a0a0c0;font-size:0.85rem;'>If the button doesn't work, <a href='$resetLink' style='color:#8b85ff;'>click this link</a> to reset your password.</p>
                        <p style='color:#a0a0c0;font-size:0.8rem;'>If you didn't request this, ignore this email.</p>
                      </div>
                    </div>";
          $mail->send();
          $success = 'Password reset link sent! Check your inbox.';
        } catch (Exception $e) {
          // Show link for development if email fails
          $success = 'Email Error! <strong>Dev Reset Link:</strong><br><a href="' . htmlspecialchars($resetLink) . '" style="color:#8b85ff;">Click Here to Reset</a><br><small style="color:#a0a0c0;">Check your SMTP info in config/db.php!</small>';
        }
      } else {
        // PHPMailer not installed or default SMTP credentials detected - show link for local dev
        $reason = !$phpmailerLoaded ? 'Install PHPMailer via Composer.' : 'You must configure your real Gmail + App Password in <code>config/db.php</code>!';
        $success = 'Email not sent! <strong>Dev Reset Link:</strong><br><a href="' . htmlspecialchars($resetLink) . '" style="color:#8b85ff;">Click Here to Reset</a><br><small style="color:#a0a0c0;margin-top:0.5rem;display:inline-block;">' . $reason . '</small>';
      }
    } else {
      // Don't reveal if email exists
      $success = 'If that email is registered, a reset link has been sent.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Forgot Password - <?= SITE_NAME ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="icon" href="<?= BASE_URL ?>/assets/img/fav.png?v=<?= time() ?>" type="image/png">
</head>

<body>
  <div class="auth-layout">
    <div class="auth-card">
      <div class="auth-logo">
        <img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>" class="mb-3"
          style="height: 50px; width: 150px;">
        <div>
          <h1 class="auth-title">Forgot Password?</h1>
          <p class="auth-subtitle">Enter your email and we'll send a reset link</p>
        </div>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
      <?php endif; ?>

      <?php if (!$success): ?>
        <form method="POST" data-loading="true">
          <div class="form-group">
            <label class="form-label">Email Address</label>
            <div class="input-group">
              <i class="fas fa-envelope input-icon"></i>
              <input type="email" name="email" class="form-control" placeholder="your@email.com" required autofocus>
            </div>
          </div>
          <button type="submit" class="btn-submit">Send Reset Link <i class="fas fa-paper-plane"
              style="margin-left:0.5rem;"></i></button>
        </form>
      <?php endif; ?>

      <div class="auth-footer"><a href="<?= BASE_URL ?>/auth/login"><i class="fas fa-arrow-left"></i> Back to Login</a>
      </div>
    </div>
  </div>
  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>

</html>