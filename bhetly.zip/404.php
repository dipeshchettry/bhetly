<?php
http_response_code(404);
$errorTitle = 'Page Not Found';
$errorMessage = 'The page you are looking for does not exist or may have been moved.';
$errorCode = 404;

require __DIR__ . '/includes/error_view.php';
