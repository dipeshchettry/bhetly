<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'About Us';
require_once __DIR__ . '/includes/landing_header.php';
?>

<section class="hero-section" style="min-height: 40vh; padding: 8rem 2rem 4rem;">
  <div class="container">
    <h1 class="hero-title">About <span class="grad-text">Bhetly</span></h1>
    <p class="hero-subtitle">The modern way to share your professional identity.</p>
  </div>
</section>

<section id="about-content" style="padding: 4rem 2rem; background: var(--dark-2);">
  <div class="container" style="max-width: 800px;">
    <h2>Our Story</h2>
    <p style="margin-top: 1rem; color: var(--text-secondary); line-height: 1.8;">
      Bhetly was born from the idea that sharing professional contact information should be seamless, elegant, and
      environmentally friendly. In a world where digital connections are everything, the traditional paper business card
      simply isn't enough. We set out to build a platform that empowers individuals and businesses to create stunning
      digital profiles that leave a lasting impression.
    </p>

    <h2 style="margin-top: 2.5rem;">Our Mission</h2>
    <p style="margin-top: 1rem; color: var(--text-secondary); line-height: 1.8;">
      Our mission is to replace billions of paper business cards with smart, dynamic digital profiles. By doing so, we
      aim to help professionals connect faster, build stronger relationships, and reduce their environmental footprint.
      Bhetly gives you complete control over your professional identity in the digital age.
    </p>

    <h2 style="margin-top: 2.5rem;">Why Choose Us?</h2>
    <div
      style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-top: 1.5rem;">
      <div style="background: var(--dark); padding: 1.5rem; border-radius: 12px; border: 1px solid var(--border);">
        <i class="fas fa-leaf" style="font-size: 2rem; color: #34D399; margin-bottom: 1rem;"></i>
        <h3 style="font-size: 1.1rem; margin-bottom: 0.5rem;">Eco-Friendly</h3>
        <p style="font-size: 0.9rem; color: var(--text-secondary);">Save trees by switching to a completely digital
          contact sharing solution.</p>
      </div>
      <div style="background: var(--dark); padding: 1.5rem; border-radius: 12px; border: 1px solid var(--border);">
        <i class="fas fa-bolt" style="font-size: 2rem; color: #FFB547; margin-bottom: 1rem;"></i>
        <h3 style="font-size: 1.1rem; margin-bottom: 0.5rem;">Instant Sharing</h3>
        <p style="font-size: 0.9rem; color: var(--text-secondary);">Share your details instantly via QR code or a simple
          link, anytime, anywhere.</p>
      </div>
      <div style="background: var(--dark); padding: 1.5rem; border-radius: 12px; border: 1px solid var(--border);">
        <i class="fas fa-paint-brush" style="font-size: 2rem; color: #6C63FF; margin-bottom: 1rem;"></i>
        <h3 style="font-size: 1.1rem; margin-bottom: 0.5rem;">Customizable</h3>
        <p style="font-size: 0.9rem; color: var(--text-secondary);">Your profile, your brand. Customize colors, layouts,
          and content to fit your style.</p>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/landing_footer.php'; ?>