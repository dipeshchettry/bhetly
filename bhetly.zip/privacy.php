<?php
require_once __DIR__ . '/includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        .legal-page { padding: 60px 0; min-height: 80vh; }
        .legal-card { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        h1 { margin-bottom: 30px; font-weight: 700; color: var(--primary); }
        h2 { margin-top: 30px; font-size: 1.5rem; font-weight: 600; }
        p, li { color: #555; line-height: 1.6; }
    </style>
</head>
<body class="bg-light">
    <div class="container legal-page">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="legal-card">
                    <h1>Privacy Policy</h1>
                    <p>Last updated: April 14, 2026</p>
                    
                    <p>Welcome to <?= SITE_NAME ?>. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you about how we look after your personal data when you visit our website and tell you about your privacy rights.</p>

                    <h2>1. Information We Collect</h2>
                    <p>We may collect, use, store and transfer different kinds of personal data about you which we have grouped together as follows:</p>
                    <ul>
                        <li><strong>Identity Data:</strong> includes name, username, and profile photo.</li>
                        <li><strong>Contact Data:</strong> includes email address and social media links.</li>
                        <li><strong>Technical Data:</strong> includes IP address, browser type and version, and operating system.</li>
                        <li><strong>Profile Data:</strong> includes your interests, preferences, feedback and survey responses.</li>
                    </ul>

                    <h2>2. How We Use Your Information</h2>
                    <p>We use your data to provide the NFC Digital Business Card service, manage your account, and improve our services.</p>

                    <h2>3. Data Security</h2>
                    <p>We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way.</p>

                    <h2>4. Your Legal Rights</h2>
                    <p>Under certain circumstances, you have rights under data protection laws in relation to your personal data, including the right to request access, correction, erasure or restriction of processing.</p>

                    <div class="mt-5">
                        <a href="<?= BASE_URL ?>" class="btn btn-primary">Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
