<?php
/**
 * Track Link Click & Redirect
 * URL: /api/track_click.php?id=LINK_ID&u=DESTINATION_URL
 */
require_once __DIR__ . '/../includes/functions.php';

$linkId = intval($_GET['id'] ?? 0);
$url    = filter_var($_GET['u'] ?? '', FILTER_VALIDATE_URL);

if ($linkId && $url) {
    $pdo->prepare("UPDATE social_links SET click_count = click_count + 1 WHERE id = ?")->execute([$linkId]);
    $pdo->prepare("INSERT INTO link_clicks (link_id) VALUES (?)")->execute([$linkId]);
    redirect($url);
} else {
    redirect(BASE_URL . '/');
}
