<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$user = getCurrentUser();
$username = $user['username'];
$profileUrl = BASE_URL . '/' . $username;

// Generate QR code URL
$qrUrl = generateQR($profileUrl, 500);

// Download the QR code from the external API
$qrContent = @file_get_contents($qrUrl);

if ($qrContent === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate QR code']);
    exit;
}

// Set headers for download
header('Content-Type: image/png');
header('Content-Disposition: attachment; filename="' . $username . '_qr_code.png"');
header('Content-Length: ' . strlen($qrContent));
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');

// Output the image
echo $qrContent;
exit;
