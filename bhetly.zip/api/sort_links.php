<?php
/**
 * Sort Links Order (AJAX)
 */
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$order = $data['order'] ?? [];

if (empty($order)) { echo json_encode(['error' => 'No order data']); exit; }

foreach ($order as $i => $linkId) {
    $pdo->prepare("UPDATE social_links SET sort_order = ? WHERE id = ? AND user_id = ?")
        ->execute([$i, intval($linkId), $_SESSION['user_id']]);
}

echo json_encode(['success' => true]);
