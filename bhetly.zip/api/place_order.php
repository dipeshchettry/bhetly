<?php
/**
 * api/place_order.php
 * Public endpoint — receives order form submission from a user's public profile.
 * No authentication required (buyers are not platform users).
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

// ── Input sanitisation ─────────────────────────────────────────────────────
$productId = (int) ($_POST['product_id'] ?? 0);
$buyerName = trim($_POST['buyer_name'] ?? '');
$buyerPhone = trim($_POST['buyer_phone'] ?? '');
$buyerEmail = trim($_POST['buyer_email'] ?? '');
$quantity = max(1, (int) ($_POST['quantity'] ?? 1));
$note = trim($_POST['note'] ?? '');

// ── Validation ─────────────────────────────────────────────────────────────
if ($productId <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid product.']);
    exit;
}

if ($buyerName === '') {
    echo json_encode(['success' => false, 'error' => 'Your name is required.']);
    exit;
}

if ($buyerEmail !== '' && !filter_var($buyerEmail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Invalid email address.']);
    exit;
}

// ── Fetch product ───────────────────────────────────────────────────────────
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND is_active = 1 LIMIT 1");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    echo json_encode(['success' => false, 'error' => 'Product not found or no longer available.']);
    exit;
}

// ── Insert order ───────────────────────────────────────────────────────────
$unitPrice = (float) $product['price'];
$totalPrice = $unitPrice * $quantity;
$sellerId = (int) $product['user_id'];

$insert = $pdo->prepare("
    INSERT INTO product_orders
        (product_id, seller_user_id, buyer_name, buyer_email, buyer_phone, quantity, unit_price, total_price, note)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$insert->execute([
    $productId,
    $sellerId,
    $buyerName,
    $buyerEmail ?: null,
    $buyerPhone ?: null,
    $quantity,
    $unitPrice,
    $totalPrice,
    $note ?: null,
]);

echo json_encode(['success' => true, 'order_id' => $pdo->lastInsertId()]);
