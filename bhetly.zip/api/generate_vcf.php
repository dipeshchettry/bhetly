<?php
/**
 * Generate vCard (.vcf) download
 * URL: /api/generate_vcf.php?u=username (public)
 *   or /api/generate_vcf.php (logged-in user)
 */
require_once __DIR__ . '/../includes/functions.php';

$username = sanitize($_GET['u'] ?? '');

if ($username) {
    $profile = getProfileByUsername($username);
} elseif (isLoggedIn()) {
    $profile = getCurrentUser();
} else {
    http_response_code(404);
    exit('Not found');
}

if (!$profile) {
    http_response_code(404);
    exit('User not found');
}

$name    = $profile['name'] ?? '';
$email   = ($profile['show_email'] ?? 1) ? ($profile['email'] ?? '') : '';
$phone   = ($profile['show_phone'] ?? 1) ? ($profile['phone'] ?? '') : '';
$bio     = $profile['bio'] ?? '';
$address = $profile['address'] ?? '';
$website = $profile['website'] ?? '';
$cardUrl = BASE_URL . '/' . ($profile['username'] ?? '');

// Build vCard
$vcf  = "BEGIN:VCARD\r\n";
$vcf .= "VERSION:3.0\r\n";
$vcf .= "FN:" . $name . "\r\n";
$vcf .= "N:" . $name . ";;;\r\n";
if ($email)   $vcf .= "EMAIL;TYPE=WORK,INTERNET:" . $email . "\r\n";
if ($phone)   $vcf .= "TEL;TYPE=WORK,VOICE:" . $phone . "\r\n";
if ($address) $vcf .= "ADR;TYPE=WORK:;;" . $address . ";;;;\r\n";
if ($website) $vcf .= "URL:" . $website . "\r\n";
if ($bio)     $vcf .= "NOTE:" . str_replace(["\r\n","\n","\r"], " ", $bio) . "\r\n";
$vcf .= "URL;TYPE=PROFILE:" . $cardUrl . "\r\n";
$vcf .= "END:VCARD\r\n";

$filename = preg_replace('/[^a-zA-Z0-9-_]/', '_', $name) . '.vcf';

header('Content-Type: text/vcard; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($vcf));
echo $vcf;
