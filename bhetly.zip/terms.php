<?php
require_once __DIR__ . '/includes/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        .legal-page { padding: 60px 0; min-height: 80vh; }
        .legal-card { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        h1 { margin-bottom: 30px; font-weight: 700; color: var(--primary); }
        h2 { margin-top: 30px; font-size: 1.5rem; font-weight: 600; }
        p, li { color: #555; line-height: 1.6; }
    </style>
</head>
<body class="bg-light">
    <div class="container legal-page">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="legal-card">
                    <h1>Terms of Service</h1>
                    <p>Last updated: April 14, 2026</p>
                    
                    <h2>1. Terms</h2>
                    <p>By accessing <?= SITE_NAME ?>, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.</p>

                    <h2>2. Use License</h2>
                    <p>Permission is granted to temporarily use the service for personal or business networking. This is the grant of a license, not a transfer of title.</p>

                    <h2>3. Disclaimer</h2>
                    <p>The materials on <?= SITE_NAME ?> are provided on an 'as is' basis. <?= SITE_NAME ?> makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>

                    <h2>4. Limitations</h2>
                    <p>In no event shall <?= SITE_NAME ?> or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the service.</p>

                    <h2>5. Governing Law</h2>
                    <p>These terms and conditions are governed by and construed in accordance with the laws of Nepal and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>

                    <div class="mt-5">
                        <a href="<?= BASE_URL ?>" class="btn btn-primary">Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
