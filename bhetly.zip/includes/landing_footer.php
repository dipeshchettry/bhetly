<!-- Footer -->
<footer class="landing-footer">
  <div class="container">
    <div style="margin-bottom: 1.5rem; display: flex; justify-content: center;">
      <img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>"
        style="height: 35px; width: 100px;">
    </div>
    <p style="margin-bottom: 1rem;">The smart way to share your professional identity.</p>
    <div class="footer-links" style="font-size:0.85rem;">
      <a href="<?= BASE_URL ?>/about">About Us</a>
      <a href="<?= BASE_URL ?>/contact">Contact Us</a>
      <a href="<?= BASE_URL ?>/Policy.pdf">Privacy Policy</a>
      <a href="<?= BASE_URL ?>/terms">Terms of Service</a>
    </div>
    <p style="font-size: 0.85rem;">&copy; <?= date('Y') ?> <strong><?= SITE_NAME ?></strong>. All rights reserved.</p>
  </div>
</footer>

<script>
  // Mobile Menu Toggle
  function toggleMenu(event) {
    if (event) {
      event.stopPropagation();
    }

    const menu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('menuOverlay');

    menu.classList.toggle('show');
    overlay.classList.toggle('show');

    if (menu.classList.contains('show')) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
  }

  // Close menu on escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const menu = document.getElementById('mobileMenu');
      const overlay = document.getElementById('menuOverlay');
      if (menu.classList.contains('show')) {
        menu.classList.remove('show');
        overlay.classList.remove('show');
        document.body.style.overflow = 'auto';
      }
    }
  });

  // Close menu when clicking on body (except on nav and menu)
  document.addEventListener('click', (e) => {
    const menu = document.getElementById('mobileMenu');
    const navRight = document.querySelector('.nav-right');
    const btn = document.getElementById('menuBtn');

    if (menu.classList.contains('show') && !navRight.contains(e.target) && !btn.contains(e.target)) {
      menu.classList.remove('show');
      document.getElementById('menuOverlay').classList.remove('show');
      document.body.style.overflow = 'auto';
    }
  });

  // Handle menu item clicks - close menu and navigate
  document.querySelectorAll('.mobile-menu-item').forEach(item => {
    item.addEventListener('click', (e) => {
      const menu = document.getElementById('mobileMenu');
      const overlay = document.getElementById('menuOverlay');

      if (menu.classList.contains('show')) {
        menu.classList.remove('show');
        overlay.classList.remove('show');
        document.body.style.overflow = 'auto';
      }
    });
  });

  // Navbar scroll effect
  window.addEventListener('scroll', () => {
    const nav = document.querySelector('.landing-nav');
    nav.style.boxShadow = window.scrollY > 50 ? '0 4px 30px rgba(0,0,0,0.1)' : 'none';
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', (e) => {
      const href = a.getAttribute('href');
      if (href !== '#' && document.querySelector(href)) {
        e.preventDefault();
        // Close menu if open
        const menu = document.getElementById('mobileMenu');
        if (menu && menu.classList.contains('show')) {
          menu.classList.remove('show');
          document.getElementById('menuOverlay').classList.remove('show');
          document.body.style.overflow = 'auto';
        }
        document.querySelector(href).scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Show login link on desktop
  const loginLink = document.querySelector('.nav-login');
  const updateLoginLinkVisibility = () => {
    if (window.innerWidth >= 768) {
      loginLink.style.display = 'inline';
    } else {
      loginLink.style.display = 'none';
    }
  };
  window.addEventListener('resize', updateLoginLinkVisibility);
  updateLoginLinkVisibility();
</script>
</body>

</html>