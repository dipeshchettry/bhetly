<?php require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$user = getCurrentUser();
$flash = getFlash(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= SITE_NAME ?> - Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/dashboard.css">
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/img/fav.png?v=<?= time() ?>">
  <script>window.BASE_URL = '<?= BASE_URL ?>';</script>
</head>

<body>
  <!-- Sidebar -->
  <nav class="sidebar" id="sidebar">
    <div class="sidebar-brand"><img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>" alt="<?= SITE_NAME ?>"
        style="height:32px;">
    </div>
    <ul class="sidebar-nav">
      <li><a href="<?= BASE_URL ?>/dashboard/index"
          class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>"><i
            class="fas fa-chart-pie"></i><span>Dashboard</span></a></li>
      <li><a href="<?= BASE_URL ?>/dashboard/profile"
          class="<?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>"><i
            class="fas fa-user-circle"></i><span>Profile</span></a></li>
      <li><a href="<?= BASE_URL ?>/dashboard/links"
          class="<?= basename($_SERVER['PHP_SELF']) == 'links.php' ? 'active' : '' ?>"><i
            class="fas fa-link"></i><span>Social
            Links</span></a></li>
      <li><a href="<?= BASE_URL ?>/dashboard/portfolio"
          class="<?= basename($_SERVER['PHP_SELF']) == 'portfolio.php' ? 'active' : '' ?>"><i
            class="fas fa-briefcase"></i><span>Portfolio</span></a></li>
      <?php if (isPro()): ?>
        <li><a href="<?= BASE_URL ?>/dashboard/products"
            class="<?= basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : '' ?>"><i
              class="fas fa-box-open"></i><span>Products</span></a></li>
      <?php endif; ?>
      <li><a href="<?= BASE_URL ?>/dashboard/analytics"
          class="<?= basename($_SERVER['PHP_SELF']) == 'analytics.php' ? 'active' : '' ?>"><i
            class="fas fa-chart-bar"></i><span>Analytics</span></a></li>
      <li><a href="<?= BASE_URL ?>/dashboard/subscription"
          class="<?= basename($_SERVER['PHP_SELF']) == 'subscription.php' ? 'active' : '' ?>"><i
            class="fas fa-crown"></i><span>Subscription</span></a></li>
      <?php if (isPro()): ?>
        <li><a href="<?= BASE_URL ?>/dashboard/orders"
            class="<?= basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : '' ?>"><i
              class="fas fa-shopping-bag"></i><span>Orders</span></a></li>
      <?php endif; ?>
      <li><a href="<?= BASE_URL ?>/dashboard/settings"
          class="<?= basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : '' ?>"><i
            class="fas fa-cog"></i><span>Settings</span></a></li>
      <?php if (isAdmin()): ?>
        <li class="nav-divider"><span>Admin</span></li>
        <li><a href="<?= BASE_URL ?>/admin/index"><i class="fas fa-shield-halved"></i><span>Admin Panel</span></a></li>
        <li><a href="<?= BASE_URL ?>/admin/messages"><i class="fas fa-envelope"></i><span>Messages</span></a></li>
        <li><a href="<?= BASE_URL ?>/admin/subscriptions"><i class="fas fa-receipt"></i><span>Subscriptions</span></a>
        </li>
        <li><a href="<?= BASE_URL ?>/admin/settings"><i class="fas fa-cogs"></i><span>Settings</span></a></li>
      <?php endif; ?>
    </ul>
    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>/<?= htmlspecialchars($user['username']) ?>" target="_blank"><i
          class="fas fa-external-link-alt"></i><span>View Card</span></a>
      <a href="<?= BASE_URL ?>/auth/logout"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="main-content" id="mainContent">
    <!-- Top Bar -->
    <header class="topbar">
      <button class="btn-sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="topbar-right">
        <?php if (!isPro()): ?>
          <a href="<?= BASE_URL ?>/dashboard/subscription" class="btn-upgrade"><i class="fas fa-crown"></i> Upgrade
            Pro</a>
        <?php else: ?>
          <span class="badge-pro"><i class="fas fa-crown"></i> Pro</span>
        <?php endif; ?>
        <div class="user-avatar" data-bs-toggle="dropdown">
          <?php if ($user['profile_picture']): ?>
            <img src="<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($user['profile_picture']) ?>" alt="Avatar">
          <?php else: ?>
            <div class="avatar-placeholder"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
          <?php endif; ?>
        </div>
      </div>
    </header>

    <!-- Flash Message -->
    <?php if ($flash): ?>
      <div
        class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mx-4 mt-3"
        role="alert">
        <?= htmlspecialchars($flash['msg']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>