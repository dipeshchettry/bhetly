<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bhetly - Build, Share & Impress Your Identity</title>
  <meta name="description"
    content="Bhetly is an all-in-one portfolio and digital business platform that helps creators, freelancers, and businesses build their online presence with custom portfolios, product selling, and real-time communication tools.">
  <meta name="keywords"
    content="digital business profile, QR code, vCard, contact sharing, professional profile, business networking, digital identity">
  <meta name="author" content="Bhetly">
  <meta name="robots" content="index, follow">
  <link rel="canonical" href="<?= BASE_URL ?>/">
  <meta property="og:title" content="Bhetly - Build, Share & Impress with Your Identity in Seconds">
  <meta property="og:description" content="Create your digital profile and share it via QR code, or link.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://bhetly.me">
  <meta property="og:image" content="https://bhetly.me/assets/img/logo.png?v=<?= time() ?>">
  <meta property="og:site_name" content="Bhetly">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Bhetly - Build, Share & Impress with Your Identity in Seconds">
  <meta name="twitter:description" content="Create your digital profile and share it via QR code, or link.">
  <meta name="twitter:image" content="https://bhetly.me/assets/img/logo.png?v=<?= time() ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/img/fav.png?v=<?= time() ?>">
  <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "Bhetly",
  "url": "https://bhetly.me",
  "description": "Bhetly is a modern digital identity platform where users can share social links, portfolios, products, and contact details in one professional profile.",
  "publisher": {
    "@type": "Organization",
    "name": "Bhetly",
    "logo": {
      "@type": "ImageObject",
      "url": "https://bhetly.me/assets/img/fav.png"
    }
  },
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://bhetly.me/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  },
  "sameAs": [
    "https://instagram.com/bhetly.me",
    "https://facebook.com/bhetlyme",
    "https://youtube.com/@bhetly",
    "https://tiktok.com/@bhetly"
  ]
}
</script>

  <style>
    /* Container */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
    }

    /* Navbar Desktop/Mobile */
    .landing-nav {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      padding: 1rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      backdrop-filter: blur(20px);
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid var(--border);
    }

    .nav-brand {
      font-size: 1.2rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .nav-brand img {
      height: 32px;
    }

    .nav-links {
      display: flex;
      gap: 2rem;
      align-items: center;
    }

    .nav-links a,
    .nav-login {
      color: var(--text-secondary);
      font-weight: 500;
      text-decoration: none;
    }

    .nav-links a:hover,
    .nav-login:hover {
      color: var(--primary);
    }

    .nav-right {
      display: flex;
      gap: 1rem;
      align-items: center;
      position: relative;
    }

    .btn-primary-grad {
      background: linear-gradient(135deg, var(--primary), var(--primary-light));
      color: white;
      padding: 0.7rem 1.5rem;
      border-radius: 50px;
      font-weight: 600;
      border: none;
      cursor: pointer;
      font-size: 0.95rem;
      text-decoration: none;
      display: inline-block;
    }

    .btn-primary-grad:hover {
      transform: translateY(-2px);
    }

    .menu-btn {
      background: none;
      border: none;
      color: var(--text-primary);
      cursor: pointer;
      font-size: 1.5rem;
      display: none;
      padding: 0.5rem;
    }

    .menu-btn:hover {
      color: var(--primary);
    }

    /* Mobile Menu Dropdown */
    .mobile-menu-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      z-index: 900;
      display: none;
      backdrop-filter: blur(4px);
    }

    .mobile-menu-overlay.show {
      display: block;
    }

    .mobile-menu {
      position: absolute;
      top: calc(100% + 10px);
      right: 0;
      background: var(--dark-2);
      border: 1px solid var(--border);
      border-radius: 8px;
      z-index: 1001;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
      min-width: 200px;
    }

    .mobile-menu.show {
      max-height: 500px;
    }

    .mobile-menu-item {
      display: block;
      padding: 0.75rem 1.5rem;
      color: var(--text-secondary);
      font-weight: 500;
      border-bottom: 1px solid var(--border);
      text-decoration: none;
      transition: all 0.2s ease;
      font-size: 0.9rem;
    }

    .mobile-menu-item:hover {
      background: var(--dark-3);
      color: var(--primary);
      padding-left: 2rem;
    }

    .mobile-menu-item:last-child {
      border-bottom: none;
    }

    /* Main Content */
    body {
      padding-top: 60px;
    }

    /* Hero Section */
    .hero-section {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      padding: 4rem 2rem;
      background: var(--dark);
      position: relative;
      overflow: hidden;
    }

    .hero-section::before {
      content: '';
      position: absolute;
      inset: 0;
      background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%236C63FF' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      pointer-events: none;
    }

    .hero-section .container {
      position: relative;
      z-index: 1;
    }

    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(108, 99, 255, 0.15);
      border: 1px solid rgba(108, 99, 255, 0.3);
      color: var(--primary-light);
      padding: 0.5rem 1.2rem;
      border-radius: 50px;
      font-size: 0.9rem;
      font-weight: 600;
      margin-bottom: 2rem;
    }

    .hero-title {
      font-size: clamp(2.5rem, 6vw, 5rem);
      font-weight: 900;
      line-height: 1.1;
      margin-bottom: 1.5rem;
    }

    .hero-title .grad-text {
      background: linear-gradient(135deg, var(--primary), var(--accent));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .hero-subtitle {
      font-size: 1.2rem;
      color: var(--text-secondary);
      max-width: 600px;
      margin: 0 auto 3rem;
    }

    .hero-btns {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }

    .btn-lg {
      padding: 0.9rem 2.5rem;
      font-size: 1.05rem;
      border-radius: 50px;
      border: none;
      cursor: pointer;
      font-weight: 600;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
    }

    .btn-primary {
      background: linear-gradient(135deg, var(--primary), var(--primary-light));
      color: white;
      box-shadow: 0 4px 15px rgba(108, 99, 255, 0.4);
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(108, 99, 255, 0.5);
    }

    .btn-secondary {
      background: transparent;
      color: var(--primary);
      border: 2px solid var(--primary);
    }

    .btn-secondary:hover {
      background: var(--primary);
      color: white;
    }

    .users-badge {
      margin: 2rem 0;
      color: var(--text-muted);
      font-size: 0.9rem;
    }

    /* Hero Visual */
    .hero-visual {
      margin-top: 4rem;
      display: flex;
      justify-content: center;
      animation: float 4s ease-in-out infinite;
      position: relative;
      z-index: 1;
    }

    .phone-mockup {
      width: 240px;
      height: 480px;
      background: var(--dark-2);
      border-radius: 36px;
      border: 2px solid var(--border);
      box-shadow: 0 0 40px rgba(15, 76, 129, 0.15), 0 4px 24px rgba(0, 0, 0, 0.06);
      overflow: hidden;
      position: relative;
    }

    .phone-mockup-screen {
      width: 100%;
      height: 100%;
      background: linear-gradient(160deg, var(--dark-3), var(--dark-2));
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2rem 1rem;
    }

    .pm-avatar {
      width: 70px;
      height: 70px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--primary), var(--accent));
      margin-top: 2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.8rem;
      color: white;
      box-shadow: 0 0 20px rgba(108, 99, 255, 0.5);
    }

    .pm-name {
      font-weight: 700;
      font-size: 1.1rem;
      margin-top: 0.75rem;
    }

    .pm-title {
      color: var(--text-secondary);
      font-size: 0.8rem;
      margin-bottom: 1.5rem;
    }

    .pm-btn {
      background: var(--primary);
      color: white;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      font-size: 0.8rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      width: 80%;
      text-align: center;
    }

    .pm-btn.green {
      background: #25D366;
    }

    .pm-btn.outline {
      background: transparent;
      border: 1px solid var(--border);
      color: var(--text-secondary);
    }

    @keyframes float {

      0%,
      100% {
        transform: translateY(0);
      }

      50% {
        transform: translateY(-12px);
      }
    }

    /* Sections */
    section {
      scroll-margin-top: 60px;
    }

    .section-tag {
      color: var(--primary);
      font-weight: 600;
      font-size: 0.9rem;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 1rem;
      display: block;
    }

    .section-title {
      font-size: clamp(1.8rem, 4vw, 3rem);
      font-weight: 800;
      margin-bottom: 1rem;
    }

    .section-subtitle {
      color: var(--text-secondary);
      font-size: 1.05rem;
      max-width: 600px;
      margin: 0 auto 3rem;
    }

    .text-center {
      text-align: center;
    }

    /* How It Works */
    #how-it-works {
      padding: 6rem 2rem;
      background: var(--dark-2);
    }

    .steps-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }

    .step-card {
      text-align: center;
      padding: 2rem;
    }

    .step-icon {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1.25rem;
      font-size: 1.4rem;
    }

    .step-number {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      color: white;
      font-size: 0.78rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1rem;
    }

    .step-title {
      font-size: 1.1rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
    }

    .step-desc {
      color: var(--text-secondary);
      font-size: 0.9rem;
    }

    /* Features */
    #features {
      padding: 6rem 2rem;
      background: var(--dark);
    }

    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-top: 2rem;
    }

    .feature-item {
      background: var(--glass);
      border: 1px solid var(--glass-border);
      border-radius: 16px;
      padding: 2rem;
      transition: all 0.3s ease;
      height: 100%;
    }

    .feature-item:hover {
      transform: translateY(-6px);
      border-color: rgba(108, 99, 255, 0.3);
      box-shadow: 0 0 40px rgba(15, 76, 129, 0.15);
    }

    .feature-icon {
      font-size: 2.8rem;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 56px;
      height: 56px;
      border-radius: 16px;
    }

    .feature-title {
      font-size: 1.1rem;
      font-weight: 700;
      margin-bottom: 0.5rem;
    }

    .feature-desc {
      color: var(--text-secondary);
      font-size: 0.9rem;
    }

    /* Pricing */
    #pricing {
      padding: 6rem 2rem;
      background: var(--dark);
    }

    .pricing-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 2rem;
      max-width: 900px;
      margin: 3rem auto 0;
    }

    .pricing-card {
      background: var(--dark-2);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 2.5rem;
      text-align: center;
      position: relative;
      transition: all 0.3s ease;
    }

    .pricing-card.featured {
      border-color: var(--primary);
      background: linear-gradient(135deg, rgba(108, 99, 255, 0.1), var(--dark-2));
      box-shadow: 0 0 40px rgba(15, 76, 129, 0.15);
    }

    .pricing-card:hover {
      transform: translateY(-4px);
    }

    .pricing-label {
      font-size: 1rem;
      font-weight: 700;
      margin-bottom: 0.75rem;
    }

    .pricing-amount {
      font-size: 3rem;
      font-weight: 900;
      margin-bottom: 1rem;
    }

    .pricing-amount span {
      font-size: 1rem;
      font-weight: 400;
      color: var(--text-secondary);
    }

    .pricing-features {
      list-style: none;
      margin: 2rem 0;
      text-align: left;
    }

    .pricing-features li {
      padding: 0.6rem 0;
      color: var(--text-secondary);
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .pricing-features li i {
      color: var(--accent);
      width: 20px;
    }

    .pricing-btn {
      width: 100%;
      margin-top: 1.5rem;
    }

    .badge-popular {
      position: absolute;
      top: -14px;
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(135deg, #FFB547, #FF8C00);
      color: white;
      padding: 0.4rem 1.2rem;
      border-radius: 50px;
      font-size: 0.78rem;
      font-weight: 800;
    }

    /* CTA */
    .cta-section {
      padding: 6rem 2rem;
      text-align: center;
      background: var(--dark-2);
    }

    .cta-title {
      font-size: clamp(1.8rem, 4vw, 3rem);
      font-weight: 900;
      margin-bottom: 1rem;
    }

    .cta-desc {
      color: var(--text-secondary);
      margin-bottom: 2rem;
      font-size: 1.05rem;
    }

    /* Footer */
    .landing-footer {
      background: var(--dark-2);
      border-top: 1px solid var(--border);
      padding: 3rem 2rem;
      text-align: center;
      color: var(--text-muted);
    }

    .footer-links {
      display: flex;
      gap: 2rem;
      justify-content: center;
      flex-wrap: wrap;
      margin: 1.5rem 0;
      font-size: 0.9rem;
    }

    .footer-links a {
      color: var(--text-muted);
      text-decoration: none;
    }

    .footer-links a:hover {
      color: var(--primary);
    }

    /* Responsive */
    @media (max-width: 768px) {
      .landing-nav {
        padding: 0.8rem 1rem;
      }

      .menu-btn {
        display: flex;
      }

      .nav-links {
        display: none;
      }

      .nav-login {
        display: none;
      }

      .hero-section {
        padding: 3rem 1rem;
        min-height: auto;
      }

      .hero-visual {
        display: none;
      }

      .btn-lg {
        padding: 0.8rem 1.2rem;
        font-size: 0.9rem;
      }

      .hero-btns {
        flex-direction: column;
      }

      .pricing-grid {
        grid-template-columns: 1fr;
      }

      .steps-grid {
        grid-template-columns: 1fr;
      }

      .features-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
      }

      .feature-item {
        padding: 1.25rem;
      }

      section {
        padding: 3rem 1rem !important;
      }

      .section-title {
        font-size: 1.6rem;
      }

      .mobile-menu-overlay {
        display: none !important;
      }
    }

    @media (max-width: 576px) {
      .landing-nav {
        padding: 0.6rem 0.8rem;
      }

      .nav-brand {
        font-size: 0.95rem;
      }

      .nav-brand img {
        height: 24px;
      }

      .hero-section {
        padding: 2.5rem 1rem;
      }

      .hero-title {
        font-size: 1.6rem;
      }

      .hero-subtitle {
        font-size: 0.95rem;
      }

      .btn-lg {
        padding: 0.7rem 1rem;
        font-size: 0.85rem;
      }

      .features-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 0.8rem;
      }

      .feature-item {
        padding: 1rem;
      }

      .feature-icon {
        font-size: 2rem;
        width: 48px;
        height: 48px;
      }

      .feature-title {
        font-size: 0.9rem;
      }

      .feature-desc {
        font-size: 0.8rem;
      }

      .pricing-card {
        padding: 1.5rem;
      }

      .pricing-amount {
        font-size: 2.2rem;
      }

      .pricing-features li {
        font-size: 0.85rem;
      }

      .step-card {
        padding: 1.5rem;
      }

      .step-icon {
        width: 50px;
        height: 50px;
        font-size: 1.2rem;
      }

      .cta-title {
        font-size: 1.4rem;
      }

      .cta-desc {
        font-size: 0.95rem;
      }

      section {
        padding: 2.5rem 1rem !important;
      }

      .section-title {
        font-size: 1.3rem;
      }

      body {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      input,
      select,
      textarea {
        font-size: 16px !important;
      }

      .mobile-menu-overlay {
        display: none !important;
      }
    }
  </style>
</head>

<body>

  <!-- Navigation -->
  <nav class="landing-nav">
    <div class="nav-brand">
      <a href="<?= BASE_URL ?>"><img src="<?= BASE_URL ?>/assets/img/logo.png?v=<?= time() ?>"
          alt="<?= SITE_NAME ?>"></a>
    </div>
    <div class="nav-links">
      <a href="<?= BASE_URL ?>/#features">Features</a>
      <a href="<?= BASE_URL ?>/#pricing">Pricing</a>
      <a href="<?= BASE_URL ?>/#how-it-works">How it Works</a>
    </div>
    <div class="nav-right">
      <a href="<?= BASE_URL ?>/login" class="nav-login" style="display:none;">Login</a>
      <a href="<?= BASE_URL ?>/register" class="btn-primary-grad">Get Started</a>
      <button class="menu-btn" id="menuBtn" onclick="toggleMenu(event)">
        <i class="fas fa-bars"></i>
      </button>

      <!-- Mobile Menu Dropdown -->
      <div class="mobile-menu" id="mobileMenu">
        <a href="<?= BASE_URL ?>/#features" class="mobile-menu-item" onclick="toggleMenu(event)">Features</a>
        <a href="<?= BASE_URL ?>/#pricing" class="mobile-menu-item" onclick="toggleMenu(event)">Pricing</a>
        <a href="<?= BASE_URL ?>/#how-it-works" class="mobile-menu-item" onclick="toggleMenu(event)">How it Works</a>
        <a href="<?= BASE_URL ?>/login" class="mobile-menu-item" onclick="toggleMenu(event)">Login</a>
      </div>
    </div>
  </nav>

  <!-- Mobile Menu Overlay -->
  <div class="mobile-menu-overlay" id="menuOverlay" onclick="toggleMenu(event)"></div>