<?php
// Expected variables:
// $errorTitle (string)
// $errorMessage (string)
// $errorCode (int)

$errorTitle = isset($errorTitle) && $errorTitle !== '' ? $errorTitle : 'Application Error';
$errorMessage = isset($errorMessage) && $errorMessage !== '' ? $errorMessage : 'An unexpected error occurred. Please try again later.';
$errorCode = isset($errorCode) ? (int) $errorCode : 500;
$safeSiteName = defined('SITE_NAME') ? SITE_NAME : 'DipsCard';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($safeSiteName) ?> - Error</title>
  <link rel="icon" href="<?= defined('BASE_URL') ? htmlspecialchars(BASE_URL) : '/' ?>/assets/img/fav.png?v=<?= time() ?>"
    type="image/png">
  <style>
    :root {
      --bg: #f5f7fb;
      --card: #ffffff;
      --border: #e6e8ee;
      --text: #1f2937;
      --muted: #6b7280;
      --danger: #dc3545;
      --primary: #0f4c81;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }

    .error-card {
      width: 100%;
      max-width: 640px;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 1.5rem;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.07);
    }

    .code {
      display: inline-block;
      padding: 0.25rem 0.6rem;
      border-radius: 999px;
      background: rgba(220, 53, 69, 0.12);
      color: var(--danger);
      font-size: 0.82rem;
      font-weight: 700;
      margin-bottom: 0.9rem;
    }

    h1 {
      margin: 0 0 0.5rem;
      font-size: 1.35rem;
      line-height: 1.3;
    }

    p {
      margin: 0;
      color: var(--muted);
      line-height: 1.6;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .actions {
      margin-top: 1.2rem;
      display: flex;
      gap: 0.6rem;
      flex-wrap: wrap;
    }

    .btn {
      display: inline-block;
      padding: 0.65rem 1rem;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 600;
      border: 1px solid transparent;
    }

    .btn-primary {
      background: var(--primary);
      color: #fff;
    }

    .btn-secondary {
      background: #fff;
      color: var(--text);
      border-color: var(--border);
    }
  </style>
</head>

<body>
  <div class="error-card">
    <span class="code">Error <?= htmlspecialchars((string) $errorCode) ?></span>
    <h1><?= htmlspecialchars($errorTitle) ?></h1>
    <p><?= htmlspecialchars($errorMessage) ?></p>
    <div class="actions">
      <a class="btn btn-primary" href="<?= defined('BASE_URL') ? htmlspecialchars(BASE_URL) : '/' ?>">Go to Home</a>
      <a class="btn btn-secondary" href="javascript:history.back()">Go Back</a>
    </div>
  </div>
</body>

</html>