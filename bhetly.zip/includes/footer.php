</div><!-- end main-content -->

<!-- Custom Confirmation Modal -->
<div class="custom-confirm-overlay" id="customConfirmModal">
  <div class="custom-confirm-box">
    <div class="custom-confirm-header">
      <div class="custom-confirm-icon"><i class="fas fa-exclamation-triangle"></i></div>
    </div>
    <div class="custom-confirm-body">
      <h3 class="custom-confirm-title">Are you sure?</h3>
      <p class="custom-confirm-message" id="customConfirmMessage">This action cannot be undone.</p>
    </div>
    <div class="custom-confirm-actions">
      <button class="custom-confirm-btn custom-confirm-cancel" onclick="closeCustomConfirm()">Cancel</button>
      <button class="custom-confirm-btn custom-confirm-danger" id="customConfirmOkBtn">Yes, do it</button>
    </div>
  </div>
</div>

<style>
.custom-confirm-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  z-index: 99999;
  align-items: center;
  justify-content: center;
  padding: 1rem;
}
.custom-confirm-box {
  background: #fff;
  border-radius: 16px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.15);
  animation: confirmPop 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  overflow: hidden;
  text-align: center;
}
@keyframes confirmPop {
  0% { transform: scale(0.9); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}
.custom-confirm-header {
  padding: 1.5rem 1.5rem 0.5rem;
}
.custom-confirm-icon {
  width: 60px;
  height: 60px;
  background: rgba(255, 90, 110, 0.1);
  color: #ff5a6e;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.8rem;
  margin: 0 auto;
}
.custom-confirm-body {
  padding: 0 1.5rem 1.5rem;
}
.custom-confirm-title {
  font-size: 1.25rem;
  font-weight: 800;
  color: #1d1d1f;
  margin: 0.5rem 0;
}
.custom-confirm-message {
  font-size: 0.95rem;
  color: #86868b;
  margin: 0;
  line-height: 1.5;
}
.custom-confirm-actions {
  display: flex;
  padding: 1rem;
  background: #fafafa;
  gap: 0.75rem;
  border-top: 1px solid rgba(0,0,0,0.05);
}
.custom-confirm-btn {
  flex: 1;
  padding: 0.75rem;
  border-radius: 10px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  border: none;
  transition: all 0.2s ease;
}
.custom-confirm-cancel {
  background: #fff;
  color: #374151;
  border: 1px solid #d1d5db;
}
.custom-confirm-cancel:hover {
  background: #f3f4f6;
}
.custom-confirm-danger {
  background: #ff5a6e;
  color: #fff;
  box-shadow: 0 4px 10px rgba(255, 90, 110, 0.3);
}
.custom-confirm-danger:hover {
  background: #f14459;
  transform: translateY(-1px);
}
</style>

<script>
// Intercept native confirms globally
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('form').forEach(form => {
    const onsubmitStr = form.getAttribute('onsubmit');
    if (onsubmitStr && onsubmitStr.includes('confirm(')) {
      // Extract the message
      const match = onsubmitStr.match(/confirm\(['"](.*?)['"]\)/);
      const message = match ? match[1] : 'Are you sure you want to proceed?';
      
      form.removeAttribute('onsubmit');
      
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const modal = document.getElementById('customConfirmModal');
        document.getElementById('customConfirmMessage').innerText = message;
        modal.style.display = 'flex';
        
        const okBtn = document.getElementById('customConfirmOkBtn');
        const newOkBtn = okBtn.cloneNode(true); // Remove old listeners
        okBtn.parentNode.replaceChild(newOkBtn, okBtn);
        
        newOkBtn.addEventListener('click', function() {
          modal.style.display = 'none';
          form.submit();
        });
      });
    }
  });

  // Handle a tags with onclick="return confirm('...')"
  document.querySelectorAll('a').forEach(a => {
    const onclickStr = a.getAttribute('onclick');
    if (onclickStr && onclickStr.includes('confirm(') && !onclickStr.includes('event.preventDefault()')) {
        const match = onclickStr.match(/confirm\(['"](.*?)['"]\)/);
        const message = match ? match[1] : 'Are you sure you want to proceed?';

        a.removeAttribute('onclick');

        a.addEventListener('click', function(e) {
          e.preventDefault();
          const targetUrl = a.getAttribute('href');

          const modal = document.getElementById('customConfirmModal');
          document.getElementById('customConfirmMessage').innerText = message;
          modal.style.display = 'flex';

          const okBtn = document.getElementById('customConfirmOkBtn');
          const newOkBtn = okBtn.cloneNode(true);
          okBtn.parentNode.replaceChild(newOkBtn, okBtn);

          newOkBtn.addEventListener('click', function() {
            modal.style.display = 'none';
            if (targetUrl && targetUrl !== '#') window.location.href = targetUrl;
          });
        });
    }
  });
});

function closeCustomConfirm() {
  document.getElementById('customConfirmModal').style.display = 'none';
}
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
