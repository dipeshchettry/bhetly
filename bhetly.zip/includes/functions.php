<?php
// ============================================================
// Helper Functions
// ============================================================
require_once __DIR__ . '/../config/db.php';

// Secure Session Settings
$isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
session_set_cookie_params([
    'secure' => $isSecure,
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

/**
 * Load PHPMailer classes if available.
 */
function loadMailerSupport() {
    static $checked = false;
    static $loaded = false;

    if ($checked) {
        return $loaded;
    }

    $checked = true;

    if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
        $loaded = true;
        return true;
    }

    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }

    $loaded = class_exists('PHPMailer\\PHPMailer\\PHPMailer');
    return $loaded;
}

/**
 * Send an application email through configured SMTP settings.
 */
function sendAppEmail($toEmail, $toName, $subject, $htmlBody, $plainBody = '') {
    if (defined('ENABLE_ACCOUNT_EMAILS') && ENABLE_ACCOUNT_EMAILS === false) {
        return false;
    }

    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    if (!loadMailerSupport()) {
        return false;
    }

    if (!defined('SMTP_HOST') || !defined('SMTP_USER') || !defined('SMTP_PASS') || !defined('SMTP_PORT')) {
        return false;
    }

    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USER;
        $mail->Password = SMTP_PASS;
        $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = SMTP_PORT;
        $mail->setFrom(SMTP_USER, defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : SITE_NAME);
        $mail->addAddress($toEmail, (string) $toName);
        $mail->isHTML(true);
        $mail->Subject = (string) $subject;
        $mail->Body = (string) $htmlBody;
        $mail->AltBody = $plainBody !== '' ? (string) $plainBody : strip_tags((string) $htmlBody);
        $mail->send();
        return true;
    } catch (Throwable $e) {
        error_log('Mail send failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Send a welcome email after successful account creation.
 */
function sendWelcomeEmail($name, $email, $username) {
    $emailName = '';
    if (is_string($email) && strpos($email, '@') !== false) {
        $emailName = strstr($email, '@', true);
    }
    $displayName = $emailName !== '' ? $emailName : (string) $name;
    $safeName = htmlspecialchars($displayName);
    $safeUsername = htmlspecialchars((string) $username);
    $cardUrl = BASE_URL . '/' . rawurlencode((string) $username);

    $subject = 'Welcome to ' . SITE_NAME;
    $html = "
        <div style='font-family:Segoe UI,Arial,sans-serif;max-width:620px;margin:0 auto;background:#ffffff;border:1px solid #e7e9ef;border-radius:12px;overflow:hidden;'>
        <div style='padding:20px 24px;background:#0f4c81;color:#ffffff;'>
        <h2 style='margin:0;font-size:22px;'>Welcome to " . SITE_NAME . "</h2>
          </div>
          <div style='padding:24px;color:#1f2937;'>
            <p style='margin-top:0;'>Hi {$safeName},</p>
            <p>Thank you for joining <strong>" . SITE_NAME . "</strong>! We're thrilled to have you on board.</p>
            <p>Your username: <strong>@{$safeUsername}</strong></p>
            <p>Your public card is ready: <a href='{$cardUrl}'>{$cardUrl}</a></p>
            <p style='font-size:12px; color:#6b7280; margin-top:4px;'>⚠️Note: Provided card link may not work please update your username first. </p>
            <p>We can't wait to see you create and share your digital identity effortlessly. Have fun exploring all the features!</p>
            <p style='margin-bottom:0;'><strong>Cheers,</strong><br>The " . SITE_NAME . " Team</p>
          </div>
        </div>";

    $plain = "Hi {$displayName},\n\nWelcome to " . SITE_NAME . ".\nYour username: @{$username}\nYour public card: {$cardUrl}\n\nThe " . SITE_NAME . " Team";

    $sent = sendAppEmail($email, $name, $subject, $html, $plain);
    if ($sent) {
        return true;
    }

    // One immediate retry for temporary SMTP/network hiccups.
    return sendAppEmail($email, $name, $subject, $html, $plain);
}

/**
 * Send a confirmation email after account deletion.
 */
function sendAccountDeletedEmail($name, $email) {
    $safeName = htmlspecialchars((string) $name);
    $subject = 'Your ' . SITE_NAME . ' account has been deleted';
    $html = "
        <div style='font-family:Segoe UI,Arial,sans-serif;max-width:620px;margin:0 auto;background:#ffffff;border:1px solid #e7e9ef;border-radius:12px;overflow:hidden;'>
          <div style='padding:20px 24px;background:#dc3545;color:#ffffff;'>
            <h2 style='margin:0;font-size:22px;'>Account Deleted</h2>
          </div>
          <div style='padding:24px;color:#1f2937;'>
            <p style='margin-top:0;'>Hi {$safeName},</p>
            <p>This email confirms that your " . SITE_NAME . " account has been permanently deleted.</p>
            <p>If you did not request this action, please contact support immediately.</p>
            <p style='margin-bottom:0;'>Regards,<br>The " . SITE_NAME . " Team</p>
          </div>
        </div>";

    $plain = "Hi {$name},\n\nYour " . SITE_NAME . " account has been permanently deleted.\nIf this was not you, please contact support immediately.\n\nThe " . SITE_NAME . " Team";

    return sendAppEmail($email, $name, $subject, $html, $plain);
}

/**
 * Render a friendly application error page.
 */
function showErrorPage($title, $message, $code = 500) {
    $errorTitle = (string) $title;
    $errorMessage = (string) $message;
    $errorCode = (int) $code;

    if ($errorCode < 100 || $errorCode > 599) {
        $errorCode = 500;
    }

    if (!headers_sent()) {
        http_response_code($errorCode);
    }

    require __DIR__ . '/error_view.php';
    exit;
}

if (PHP_SAPI !== 'cli') {
    set_exception_handler(function ($ex) {
        showErrorPage('Application Error', $ex->getMessage(), 500);
    });

    register_shutdown_function(function () {
        $fatal = error_get_last();
        if (!$fatal) {
            return;
        }

        $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
        if (in_array($fatal['type'], $fatalTypes, true)) {
            showErrorPage('Fatal Error', $fatal['message'] ?? 'A fatal error occurred.', 500);
        }
    });
}

/**
 * Redirect to a URL
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Store the authenticated user in the session.
 */
function setUserSession(array $user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['username'] = $user['username'];
}

/**
 * Convert a target into a safe internal redirect URL.
 */
function safeRedirectTarget($target, $defaultUrl) {
    $target = trim((string) $target);

    if ($target === '') {
        return $defaultUrl;
    }

    if (strpos($target, '://') !== false || strpos($target, '//') === 0) {
        return $defaultUrl;
    }

    if (strpos($target, BASE_URL) === 0) {
        return $target;
    }

    if ($target[0] !== '/') {
        $target = '/' . ltrim($target, '/');
    }

    return BASE_URL . $target;
}

/**
 * Generate a unique username from a name or email seed.
 */
function generateUniqueUsername($seed) {
    global $pdo;

    $base = strtolower((string) $seed);
    $base = preg_replace('/[^a-z0-9]+/i', '-', $base);
    $base = trim($base, '-');

    if ($base === '') {
        $base = 'user';
    }

    $base = substr($base, 0, 24);
    $username = $base;
    $suffix = 1;

    while (true) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);

        if (!$stmt->fetch()) {
            return $username;
        }

        $suffixText = '-' . $suffix;
        $username = substr($base, 0, max(1, 30 - strlen($suffixText))) . $suffixText;
        $suffix++;
    }
}

/**
 * Ensure the default profile row exists for a user.
 */
function ensureUserProfile($userId) {
    global $pdo;

    $stmt = $pdo->prepare('INSERT INTO profiles (user_id) VALUES (?) ON DUPLICATE KEY UPDATE user_id = user_id');
    $stmt->execute([$userId]);
}

/**
 * Require login - redirect to login page if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        redirect(BASE_URL . '/login?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    }
}

/**
 * Require admin access
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        redirect(BASE_URL . '/dashboard/index');
    }
}

/**
 * Sanitize input
 */
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Get current user data
 */
function getCurrentUser() {
    global $pdo;
    if (!isLoggedIn()) return null;
    $stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

/**
 * Get user profile by username
 */
function getProfileByUsername($username) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT u.*, p.* FROM users u LEFT JOIN profiles p ON u.id = p.user_id WHERE u.username = ? AND u.is_active = 1 AND u.is_verified = 1");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

/**
 * Get social links for a user
 */
function getSocialLinks($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM social_links WHERE user_id = ? AND is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Get portfolio items for a user
 */
function getPortfolioItems($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM portfolio_items WHERE user_id = ? AND is_active = 1 ORDER BY sort_order ASC");
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

/**
 * Track profile visit
 */
function trackVisit($userId) {
    global $pdo;
    $today = date('Y-m-d');
    $device = getDeviceType();
    $source = isset($_SERVER['HTTP_REFERER']) ? 'referral' : 'direct';
    if (isset($_GET['src'])) $source = sanitize($_GET['src']);

    $stmt = $pdo->prepare("SELECT id FROM analytics WHERE user_id = ? AND visit_date = ? AND device_type = ?");
    $stmt->execute([$userId, $today, $device]);
    $row = $stmt->fetch();

    if ($row) {
        $pdo->prepare("UPDATE analytics SET visit_count = visit_count + 1 WHERE id = ?")->execute([$row['id']]);
    } else {
        $pdo->prepare("INSERT INTO analytics (user_id, visit_date, device_type, source) VALUES (?, ?, ?, ?)")->execute([$userId, $today, $device, $source]);
    }
}

/**
 * Detect device type
 */
function getDeviceType() {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/Mobile|Android|iPhone|iPad/i', $ua)) return 'mobile';
    if (preg_match('/Tablet|iPad/i', $ua)) return 'tablet';
    return 'desktop';
}

/**
 * Get analytics summary for a user
 */
function getAnalyticsSummary($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT SUM(visit_count) as total, SUM(CASE WHEN visit_date = CURDATE() THEN visit_count ELSE 0 END) as today, SUM(CASE WHEN visit_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN visit_count ELSE 0 END) as week FROM analytics WHERE user_id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

/**
 * Generate QR Code URL using Google Charts API
 */
function generateQR($text, $size = 200) {
    return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data=" . urlencode($text);
}

/**
 * Upload file securely
 */
function uploadFile($file, $folder = 'profiles') {
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowed)) return ['error' => 'Invalid file type. Only JPG, PNG, GIF, WEBP allowed.'];
    if ($file['size'] > 5 * 1024 * 1024) return ['error' => 'File too large. Max 5MB.'];

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('', true) . '.' . strtolower($ext);
    
    $folderPath = rtrim(UPLOAD_PATH, '/') . '/' . ltrim($folder, '/');
    if (!is_dir($folderPath)) {
        @mkdir($folderPath, 0755, true);
    }
    
    $dest = $folderPath . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) return ['error' => 'Upload failed.'];
    return ['success' => true, 'filename' => $filename, 'path' => rtrim(UPLOAD_URL, '/') . '/' . ltrim($folder, '/') . '/' . $filename];
}

/**
 * Get social icon class (Font Awesome)
 */
function getSocialIcon($platform) {
    $icons = [
        'facebook'  => 'fab fa-facebook-f',
        'instagram' => 'fab fa-instagram',
        'linkedin'  => 'fab fa-linkedin-in',
        'tiktok'    => 'fab fa-tiktok',
        'youtube'   => 'fab fa-youtube',
        'twitter'   => 'fab fa-twitter',
        'snapchat'  => 'fab fa-snapchat-ghost',
        'github'    => 'fab fa-github',
        'website'   => 'fas fa-globe',
        'custom'    => 'fas fa-link',
        'whatsapp'  => 'fab fa-whatsapp',
        'telegram'  => 'fab fa-telegram-plane',
    ];
    return $icons[strtolower($platform)] ?? 'fas fa-link';
}

/**
 * Get social brand color
 */
function getSocialColor($platform) {
    $colors = [
        'facebook'  => '#1877F2',
        'instagram' => '#E1306C',
        'linkedin'  => '#0A66C2',
        'tiktok'    => '#010101',
        'youtube'   => '#FF0000',
        'twitter'   => '#1DA1F2',
        'snapchat'  => '#FFFC00',
        'github'    => '#333',
        'whatsapp'  => '#25D366',
        'telegram'  => '#2CA5E0',
        'website'   => '#6C63FF',
        'custom'    => '#6C63FF',
    ];
    return $colors[strtolower($platform)] ?? '#6C63FF';
}

/**
 * Flash message system
 */
function setFlash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Check if user has pro plan
 */
function isPro($userId = null) {
    global $pdo;
    $uid = $userId ?? ($_SESSION['user_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT plan FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    return $row && $row['plan'] === 'pro';
}
