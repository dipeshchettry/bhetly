<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $firstName = sanitize($_POST['first_name'] ?? '');
    $lastName  = sanitize($_POST['last_name'] ?? '');
    $email     = sanitize($_POST['email'] ?? '');
    $message   = sanitize($_POST['message'] ?? '');

    if (empty($firstName) || empty($lastName) || empty($email) || empty($message)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO contact_messages (first_name, last_name, email, message) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$firstName, $lastName, $email, $message])) {
            $success = "Your message has been sent successfully. We will get back to you soon!";
        } else {
            $error = "An error occurred while sending your message. Please try again.";
        }
    }
}

$pageTitle = 'Contact Us';
require_once __DIR__ . '/includes/landing_header.php';
?>

<section class="hero-section" style="min-height: 40vh; padding: 8rem 2rem 4rem;">
  <div class="container">
    <h1 class="hero-title">Contact <span class="grad-text">Us</span></h1>
    <p class="hero-subtitle">We'd love to hear from you. Get in touch with our team.</p>
  </div>
</section>

<section id="contact-content" style="padding: 4rem 2rem; background: var(--dark-2);">
  <div class="container" style="max-width: 900px;">
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 4rem;">
      <div class="contact-card" style="padding: 2.5rem 2rem; background: var(--dark); border-radius: 16px; text-align: center; border: 1px solid var(--border);">
        <div style="width: 64px; height: 64px; border-radius: 50%; background: rgba(108, 99, 255, 0.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
          <i class="fas fa-envelope" style="font-size: 1.5rem; color: #6C63FF;"></i>
        </div>
        <h3 style="margin-bottom: 0.5rem;">Email Us</h3>
        <p style="color: var(--text-secondary); margin-bottom: 1rem;">For general inquiries</p>
        <a href="mailto:support@bhetly.com" style="color: #6C63FF; font-weight: 600;">info.kharayoo@gmail.com</a>
      </div>
      
      <div class="contact-card" style="padding: 2.5rem 2rem; background: var(--dark); border-radius: 16px; text-align: center; border: 1px solid var(--border);">
        <div style="width: 64px; height: 64px; border-radius: 50%; background: rgba(67, 217, 180, 0.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
          <i class="fas fa-phone" style="font-size: 1.5rem; color: #43D9B4;"></i>
        </div>
        <h3 style="margin-bottom: 0.5rem;">Call Us</h3>
        <p style="color: var(--text-secondary); margin-bottom: 1rem;">Available Mon-Fri</p>
        <a href="tel:+9771234567890" style="color: #43D9B4; font-weight: 600;">+977 9766459738</a>
      </div>
      
      <div class="contact-card" style="padding: 2.5rem 2rem; background: var(--dark); border-radius: 16px; text-align: center; border: 1px solid var(--border);">
        <div style="width: 64px; height: 64px; border-radius: 50%; background: rgba(255, 101, 132, 0.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
          <i class="fas fa-map-marker-alt" style="font-size: 1.5rem; color: #FF6584;"></i>
        </div>
        <h3 style="margin-bottom: 0.5rem;">Visit Us</h3>
        <p style="color: var(--text-secondary); margin-bottom: 1rem;">Our Office</p>
        <span style="color: #FF6584; font-weight: 600;">Kathmandu, Nepal</span>
      </div>
    </div>

    <div style="background: var(--dark); border-radius: 16px; padding: 3rem; border: 1px solid var(--border);">
      <div style="text-align: center; margin-bottom: 2rem;">
        <h2 style="font-size: 2rem; margin-bottom: 0.5rem;">Send us a message</h2>
        <p style="color: var(--text-secondary);">Fill out the form below and we'll get back to you shortly.</p>
      </div>
      
      <form method="POST" style="display: grid; gap: 1.5rem;">
        <?php if ($error): ?>
            <div style="padding: 1rem; background: rgba(255, 90, 110, 0.1); border: 1px solid rgba(255, 90, 110, 0.3); color: var(--danger); border-radius: 8px;">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div style="padding: 1rem; background: rgba(67, 217, 180, 0.1); border: 1px solid rgba(67, 217, 180, 0.3); color: var(--accent); border-radius: 8px;">
                <i class="fas fa-check-circle"></i> <?= $success ?>
            </div>
        <?php endif; ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">First Name</label>
            <input type="text" name="first_name" placeholder="John" required style="width: 100%; padding: 0.8rem 1rem; border-radius: 8px; border: 1px solid var(--border); background: var(--dark-2); color: var(--text-primary); outline: none;">
          </div>
          <div>
            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Last Name</label>
            <input type="text" name="last_name" placeholder="Doe" required style="width: 100%; padding: 0.8rem 1rem; border-radius: 8px; border: 1px solid var(--border); background: var(--dark-2); color: var(--text-primary); outline: none;">
          </div>
        </div>
        <div>
          <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Email Address</label>
          <input type="email" name="email" placeholder="john@example.com" required style="width: 100%; padding: 0.8rem 1rem; border-radius: 8px; border: 1px solid var(--border); background: var(--dark-2); color: var(--text-primary); outline: none;">
        </div>
        <div>
          <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Message</label>
          <textarea name="message" rows="5" placeholder="How can we help you?" required style="width: 100%; padding: 0.8rem 1rem; border-radius: 8px; border: 1px solid var(--border); background: var(--dark-2); color: var(--text-primary); outline: none; resize: vertical;"></textarea>
        </div>
        <button type="submit" name="submit_contact" class="btn-primary-grad" style="padding: 1rem; text-align: center; font-size: 1.1rem; border-radius: 8px; margin-top: 0.5rem; border: none; cursor: pointer; color: white;">Send Message</button>
      </form>
    </div>

  </div>
</section>

<?php require_once __DIR__ . '/includes/landing_footer.php'; ?>
