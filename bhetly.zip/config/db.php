<?php
define('DB_HOST', 'sql107.byetcluster.com');
define('DB_USER', 'depc_41938300');
define('DB_PASS', 'afad3503a77f6e3');
define('DB_NAME', 'depc_41938300_profile');

// Robust BASE_URL detection
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$isLocal = ($host === 'localhost' || strpos($host, '127.0.0.1') !== false);

// Check for standard HTTPS or X-Forwarded-Proto (Cloudflare/Proxies)
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

$protocol = ($isHttps && !$isLocal) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

// On localhost, the app lives at /nfc — on production, it's at the root
$subfolder = ($host === 'localhost' || strpos($host, '127.0.0.1') !== false) ? '/nfc' : '';

define('BASE_URL', $protocol . $host . $subfolder);
define('SITE_NAME', 'Bhetly');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . '/uploads/');

// Google Sign-In Configuration
define('GOOGLE_CLIENT_ID', '989374134656-9gsekp3oa18ji83t557uj44c86knqkbn.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', BASE_URL . '/auth/google.php');

// PHPMailer SMTP Configuration (for password reset emails)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'dipeshbham100@gmail.com'); // Change this
define('SMTP_PASS', 'tjkf ivmw dfyl tpyw'); // Change this (Gmail App Password)
define('SMTP_FROM_NAME', SITE_NAME);
define('ENABLE_ACCOUNT_EMAILS', true);

// Payment Config
define('ESEWA_QR', BASE_URL . '/assets/img/esewa_qr.png');
define('KHALTI_QR', BASE_URL . '/assets/img/khalti_qr.png');
define('PRO_PRICE', 999); // NPR per year

// Create DB connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    $errorTitle = 'Database Connection Error';
    $errorMessage = 'Unable to connect to the database. Please check configuration and try again.';
    $errorCode = 500;
    http_response_code($errorCode);
    require __DIR__ . '/../includes/error_view.php';
    exit;
}
