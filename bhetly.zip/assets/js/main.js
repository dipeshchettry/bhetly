// ============================================================
// NFC Card Pro - Main JavaScript
// ============================================================

document.addEventListener('DOMContentLoaded', function () {

  // ---- Sidebar Toggle ----
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('mainContent');
  const sidebarToggle = document.getElementById('sidebarToggle');
  let overlay;

  function createOverlay() {
    overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', closeSidebar);
  }
  createOverlay();

  function openSidebar() {
    if (sidebar) {
      sidebar.classList.add('open');
      overlay.style.display = 'block';
    }
  }

  function closeSidebar() {
    if (sidebar) {
      sidebar.classList.remove('open');
      overlay.style.display = 'none';
    }
  }

  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (window.matchMedia('(max-width: 992px)').matches) {
        sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
      } else {
        sidebar.classList.toggle('collapsed');
        if(mainContent) mainContent.classList.toggle('expanded');
      }
    });
  }

  // ---- Password Toggle ----
  document.querySelectorAll('.input-eye').forEach(eye => {
    eye.addEventListener('click', function () {
      const target = document.getElementById(this.dataset.target);
      if (!target) return;
      if (target.type === 'password') {
        target.type = 'text';
        this.classList.replace('fa-eye', 'fa-eye-slash');
      } else {
        target.type = 'password';
        this.classList.replace('fa-eye-slash', 'fa-eye');
      }
    });
  });

  // ---- Auto-dismiss alerts ----
  document.querySelectorAll('.alert-auto-dismiss').forEach(el => {
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.5s';
      setTimeout(() => el.remove(), 500);
    }, 4000);
  });

  // ---- Modal system ----
  document.querySelectorAll('[data-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const modal = document.getElementById(btn.dataset.modal);
      if (modal) modal.classList.add('show');
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const modal = btn.closest('.modal-overlay');
      if (modal) modal.classList.remove('show');
    });
  });

  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', e => {
      if (e.target === modal) modal.classList.remove('show');
    });
  });

  // ---- Drag & Drop Sort for Links ----
  const linkList = document.getElementById('linkList');
  if (linkList && typeof Sortable !== 'undefined') {
    new Sortable(linkList, {
      animation: 150,
      ghostClass: 'sortable-ghost',
      onEnd: function () {
        const ids = [...linkList.querySelectorAll('[data-id]')].map(el => el.dataset.id);
        fetch(window.BASE_URL + '/api/sort_links.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ order: ids })
        });
      }
    });
  }

  // ---- Image Preview ----
  document.querySelectorAll('.img-upload-input').forEach(input => {
    input.addEventListener('change', function () {
      const preview = document.getElementById(this.dataset.preview);
      if (preview && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => { preview.src = e.target.result; };
        reader.readAsDataURL(this.files[0]);
      }
    });
  });

  // ---- Confirm Delete ----
  document.querySelectorAll('[data-confirm]').forEach(btn => {
    btn.addEventListener('click', function (e) {
      if (!confirm(this.dataset.confirm || 'Are you sure?')) {
        e.preventDefault();
        e.stopPropagation();
      }
    });
  });

  // ---- Copy to clipboard ----
  document.querySelectorAll('[data-copy]').forEach(btn => {
    btn.addEventListener('click', function () {
      const text = this.dataset.copy;
      const btnEl = this;
      const orig = btnEl.innerHTML;
      
      const setCopiedState = () => {
        btnEl.innerHTML = '<i class="fas fa-check"></i> Copied!';
        setTimeout(() => { btnEl.innerHTML = orig; }, 2000);
      };

      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(setCopiedState);
      } else {
        // Fallback for non-secure contexts (HTTP not on localhost)
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
          document.execCommand('copy');
          setCopiedState();
        } catch (err) {
          console.error('Fallback: Oops, unable to copy', err);
        }
        textArea.remove();
      }
    });
  });

  // ---- Analytics Chart (Chart.js) ----
  const chartEl = document.getElementById('visitChart');
  if (chartEl && typeof Chart !== 'undefined') {
    const ctx = chartEl.getContext('2d');
    const labels = JSON.parse(chartEl.dataset.labels || '[]');
    const data = JSON.parse(chartEl.dataset.values || '[]');

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Profile Views',
          data: data,
          borderColor: '#6C63FF',
          backgroundColor: 'rgba(108,99,255,0.1)',
          borderWidth: 2.5,
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#6C63FF',
          pointRadius: 4,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#a0a0c0', font: { size: 11 } } },
          y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#a0a0c0', font: { size: 11 } }, beginAtZero: true }
        }
      }
    });
  }

  // ---- Theme color picker sync ----
  const colorPicker = document.getElementById('customColor');
  if (colorPicker) {
    colorPicker.addEventListener('input', function () {
      document.querySelectorAll('.color-preview').forEach(el => {
        el.style.background = this.value;
      });
    });
  }

  // ---- Form Loading State ----
  document.querySelectorAll('form[data-loading]').forEach(form => {
    form.addEventListener('submit', function () {
      const btn = this.querySelector('[type="submit"]');
      if (btn) {
        setTimeout(() => {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner"></span> Saving...';
        }, 10);
      }
    });
  });

});

// Spinner CSS
const spinnerStyle = document.createElement('style');
spinnerStyle.textContent = `.spinner { display: inline-block; width: 14px; height: 14px; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; animation: spin 0.7s linear infinite; } @keyframes spin { to { transform: rotate(360deg); } }`;
document.head.appendChild(spinnerStyle);
