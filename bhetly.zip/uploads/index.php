<?php
// Secure uploads directory - deny PHP execution
header('HTTP/1.0 403 Forbidden');
die('Access Denied');
