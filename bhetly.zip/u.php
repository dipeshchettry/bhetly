<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';
$username = sanitize($_GET['username'] ?? '');
if (!$username) {
  http_response_code(404);
  die('Not found');
}
$profile = getProfileByUsername($username);
if (!$profile) {
  http_response_code(404);
  include __DIR__ . '/404.php';
  exit;
}
$userId = $profile['user_id'];
$links = getSocialLinks($userId);
$items = getPortfolioItems($userId);
$isPro = isPro($userId);
$cardUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$canonicalUrl = BASE_URL . '/' . rawurlencode($username);
$products = [];
if ($isPro) {
  $stmt = $pdo->prepare("SELECT * FROM products WHERE user_id = ? AND is_active = 1 ORDER BY sort_order ASC, created_at DESC");
  $stmt->execute([$userId]);
  $products = $stmt->fetchAll();
}
if (!isLoggedIn() || $_SESSION['user_id'] !== $userId) {
  trackVisit($userId);
}
$theme = $profile['theme'] ?? 'light';
$accentColor = htmlspecialchars($profile['custom_color'] ?? '#0f4c81');
$isDark = $theme === 'dark' || $theme === 'custom';
$profilePic = $profile['profile_picture'] ? UPLOAD_URL . 'profiles/' . $profile['profile_picture'] : null;
$coverPic = $profile['cover_photo'] ? UPLOAD_URL . 'profiles/' . $profile['cover_photo'] : null;
$profileName = htmlspecialchars_decode($profile['name'] ?? 'Unknown', ENT_QUOTES);
$profileName = htmlspecialchars($profileName, ENT_QUOTES, 'UTF-8');

$bioRaw = htmlspecialchars_decode($profile['bio'] ?? '', ENT_QUOTES);
$bio = htmlspecialchars($bioRaw, ENT_QUOTES, 'UTF-8');

$aboutMeRaw = htmlspecialchars_decode($profile['about_me'] ?? '', ENT_QUOTES);
$aboutMe = $aboutMeRaw ? nl2br(htmlspecialchars($aboutMeRaw, ENT_QUOTES, 'UTF-8')) : '';

$phone = htmlspecialchars($profile['phone'] ?? '');
$whatsapp = htmlspecialchars($profile['whatsapp'] ?? '');
$email = ($profile['show_email'] ?? 1) ? htmlspecialchars($profile['email'] ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
  <title><?= $profileName ?> - Digital Identity</title>
  <meta name="description" content="<?= $bio ?: "Connect with $profileName - Digital Identity" ?>">
  <meta property="og:title" content="<?= $profileName ?> - Digital Identity">
  <meta property="og:description" content="<?= $bio ?>">
  <?php if ($profilePic): ?>
  <meta property="og:image" content="<?= $profilePic ?>"><?php endif; ?>
  <link rel="canonical" href="https://bhetly.me/<?php echo urlencode($username); ?>">
  <meta property="og:url" content="<?= $canonicalUrl ?>">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="canonical" href="<?= $canonicalUrl ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.2.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">
  <link rel="icon" type="image/png" href="<?= $profilePic ?: BASE_URL . '/assets/img/fav.png?v=' . time() ?>">
  <style>
    :root {
      --accent:
        <?= $accentColor ?>
      ;
      --accent-rgb: 15, 76, 129;
      --accent-light:
        <?= $accentColor ?>
        18;
      --accent-mid:
        <?= $accentColor ?>
        35;
    }

    <?php if ($isDark): ?>
      :root {
        --bg: #0a0a0f;
        --bg2: #111118;
        --bg3: #1a1a28;
        --surface: #16161f;
        --surface2: #1e1e2e;
        --text: #f0f0ff;
        --text2: #a0a0c8;
        --text3: #606080;
        --border: rgba(255, 255, 255, 0.07);
        --card-shadow: 0 8px 40px rgba(0, 0, 0, 0.5);
        --nav-bg: rgba(10, 10, 15, 0.92);
      }

    <?php else: ?>
      :root {
        --bg: #f5f7ff;
        --bg2: #eef0f9;
        --bg3: #e8eaf5;
        --surface: #ffffff;
        --surface2: #f8f9ff;
        --text: #1a1a2e;
        --text2: #5a5a80;
        --text3: #9090b0;
        --border: rgba(0, 0, 0, 0.07);
        --card-shadow: 0 4px 30px rgba(15, 76, 129, 0.08);
        --nav-bg: rgba(255, 255, 255, 0.95);
      }

    <?php endif; ?>

    *,
    *::before,
    *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      font-family: 'Inter', -apple-system, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.6;
      overflow-x: hidden;
      -webkit-font-smoothing: antialiased;
    }

    a {
      text-decoration: none;
      color: inherit;
    }

    img {
      max-width: 100%;
      display: block;
    }

    /* ===== STICKY NAV ===== */
    .profile-nav {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 100;
      background: var(--nav-bg);
      backdrop-filter: blur(20px) saturate(180%);
      -webkit-backdrop-filter: blur(20px);
      border-bottom: 1px solid var(--border);
      padding: 0.75rem 1.25rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      transition: all 0.3s ease;
    }

    .nav-brand {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      font-weight: 800;
      font-size: 0.9rem;
      color: var(--accent);
    }

    .nav-brand-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid var(--accent);
    }

    .nav-brand-placeholder {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.85rem;
      font-weight: 800;
      color: white;
    }

    .nav-actions {
      display: flex;
      gap: 0.5rem;
      align-items: center;
    }

    .nav-share-btn {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      padding: 0.4rem 0.9rem;
      border-radius: 50px;
      background: var(--accent);
      color: white;
      font-size: 0.78rem;
      font-weight: 700;
      border: none;
      cursor: pointer;
      transition: all 0.2s;
    }

    .nav-share-btn:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .nav-menu {
      display: flex;
      gap: 1.25rem;
      align-items: center;
    }

    .nav-menu a {
      font-size: 0.82rem;
      font-weight: 600;
      color: var(--text2);
      transition: color 0.2s;
      padding: 0.2rem 0;
      border-bottom: 2px solid transparent;
    }

    .nav-menu a:hover {
      color: var(--accent);
      border-bottom-color: var(--accent);
    }

    /* ===== HERO / HEADER ===== */
    .hero-section {
      position: relative;
      padding-top: 60px;
      padding-bottom: 1.5rem;
      display: flex;
      flex-direction: column;
    }

    .hero-cover {
      height: 260px;
      background: linear-gradient(135deg, var(--accent) 0%, #43D9B4 60%, #FF6584 100%);
      position: relative;
      overflow: hidden;
    }

    .hero-cover img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .hero-cover-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(to bottom, transparent 60%, var(--bg) 100%);
    }

    .hero-cover-pattern {
      position: absolute;
      inset: 0;
      background: url("data:image/svg+xml,%3Csvg width='60' height='60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M0 60L60 0H30L0 30M60 60V30L30 60'/%3E%3C/g%3E%3C/svg%3E");
    }

    .hero-body {
      max-width: 900px;
      margin: 0 auto;
      width: 100%;
      padding: 0 1.5rem;
      position: relative;
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 2rem;
      align-items: center;
    }

    .avatar-col {
      position: relative;
    }

    .hero-avatar-wrap {
      margin-top: -70px;
      position: relative;
      z-index: 10;
    }

    .hero-avatar {
      width: 140px;
      height: 140px;
      border-radius: 50%;
      border: 4px solid var(--bg);
      object-fit: cover;
      display: block;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    }

    .hero-avatar-placeholder {
      width: 140px;
      height: 140px;
      border-radius: 50%;
      border: 4px solid var(--bg);
      background: linear-gradient(135deg, var(--accent), #43D9B4);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 3rem;
      font-weight: 900;
      color: white;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    }


    .info-col {
      padding-bottom: 1rem;
      min-width: 0;
    }

    .hero-name {
      font-size: clamp(1.6rem, 4vw, 2.4rem);
      font-weight: 900;
      margin-bottom: 0.2rem;
      line-height: 1.2;
      word-break: break-word;
      display: flex;
      align-items: center;
      justify-content: flex-start;
      gap: 0.4rem;
      flex-wrap: wrap;
    }

    .hero-title {
      font-size: 0.95rem;
      color: var(--accent);
      font-weight: 600;
      margin-bottom: 0.6rem;
    }

    .hero-bio {
      font-size: 0.9rem;
      color: var(--text2);
      line-height: 1.7;
      max-width: 500px;
    }

    /* ===== CONTACT BAR ===== */
    .contact-bar {
      max-width: 900px;
      margin: 1.5rem auto 0;
      padding: 0 1.5rem;
      display: flex;
      flex-wrap: wrap;
      gap: 0.6rem;
    }

    .contact-chip {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      border-radius: 50px;
      background: var(--surface);
      border: 1px solid var(--border);
      font-size: 0.82rem;
      color: var(--text2);
      font-weight: 500;
      transition: all 0.2s;
      cursor: pointer;
    }

    .contact-chip:hover {
      border-color: var(--accent);
      color: var(--accent);
      transform: translateY(-2px);
    }

    .contact-chip i {
      color: var(--accent);
      font-size: 0.8rem;
    }

    /* ===== ACTION BUTTONS ===== */
    .action-strip {
      max-width: 900px;
      margin: 1.25rem auto 0;
      padding: 0 1.5rem;
      display: flex;
      gap: 0.75rem;
      flex-wrap: wrap;
    }

    .action-btn-main {
      display: inline-flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.75rem 1.5rem;
      border-radius: 50px;
      font-weight: 700;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.25s;
      border: none;
    }

    .btn-call-main {
      background: var(--accent);
      color: white;
      box-shadow: 0 4px 15px rgba(15, 76, 129, 0.35);
    }

    .btn-call-main:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(15, 76, 129, 0.45);
    }

    .btn-wa-main {
      background: #25D366;
      color: white;
      box-shadow: 0 4px 15px rgba(37, 211, 102, 0.35);
    }

    .btn-wa-main:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(37, 211, 102, 0.45);
    }

    .btn-email-main {
      background: var(--surface);
      color: var(--text);
      border: 2px solid var(--border);
      box-shadow: var(--card-shadow);
    }

    .btn-email-main:hover {
      border-color: var(--accent);
      color: var(--accent);
      transform: translateY(-3px);
    }

    .btn-save-main {
      background: var(--accent-light);
      color: var(--accent);
      border: 2px solid var(--accent);
      box-shadow: none;
      font-weight: 700;
    }

    .btn-save-main:hover {
      background: var(--accent);
      color: white;
      transform: translateY(-3px);
    }

    /* ===== MAIN LAYOUT ===== */
    .main-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 0.5rem 1.5rem 5rem;
    }

    .grid-layout {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: 1.5rem;
      align-items: start;
    }

    /* ===== SECTION CARD ===== */
    .section-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      overflow: hidden;
      margin-bottom: 1.5rem;
      box-shadow: var(--card-shadow);
      transition: transform 0.2s, box-shadow 0.2s;
    }

    .section-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 1.25rem 1.5rem;
      border-bottom: 1px solid var(--border);
      background: var(--surface2);
    }

    .section-icon {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      background: var(--accent-light);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      flex-shrink: 0;
    }

    .section-title {
      font-size: 0.95rem;
      font-weight: 700;
    }

    .section-body {
      padding: 1.5rem;
    }

    /* ===== SOCIAL LINKS ===== */
    .social-links-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
      gap: 0.75rem;
    }

    .social-link-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
      padding: 1rem 0.5rem;
      border-radius: 14px;
      background: var(--surface2);
      border: 1px solid var(--border);
      font-size: 0.78rem;
      font-weight: 600;
      color: var(--text2);
      cursor: pointer;
      transition: all 0.2s;
      text-align: center;
    }

    .social-link-btn:hover {
      transform: translateY(-4px);
      border-color: var(--accent);
      color: var(--accent);
    }

    .social-link-icon {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      color: white;
      flex-shrink: 0;
      transition: transform 0.2s;
    }

    .social-link-btn:hover .social-link-icon {
      transform: scale(1.1);
    }

    /* ===== PORTFOLIO GRID ===== */
    .portfolio-items-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .port-item-card {
      border-radius: 14px;
      overflow: hidden;
      border: 1px solid var(--border);
      background: var(--surface2);
      transition: all 0.25s;
    }

    .port-item-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
      border-color: var(--accent);
    }

    .port-img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      display: block;
    }

    .port-body {
      padding: 0.85rem;
    }

    .port-title {
      font-size: 0.88rem;
      font-weight: 700;
      margin-bottom: 0.25rem;
    }

    .port-desc {
      font-size: 0.78rem;
      color: var(--text2);
      line-height: 1.5;
    }

    .video-wrap {
      position: relative;
      padding-bottom: 56.25%;
      border-radius: 12px;
      overflow: hidden;
    }

    .video-wrap iframe {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      border: none;
    }

    /* ===== PRODUCTS SECTION ===== */
    .products-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .product-card {
      border-radius: 16px;
      overflow: hidden;
      border: 1px solid var(--border);
      background: var(--surface2);
      transition: all 0.25s;
      position: relative;
    }

    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
      border-color: var(--accent);
    }

    .product-img-wrap {
      position: relative;
      overflow: hidden;
    }

    .product-img {
      width: 100%;
      height: 170px;
      object-fit: cover;
      display: block;
      transition: transform 0.3s;
    }

    .product-card:hover .product-img {
      transform: scale(1.05);
    }

    .product-img-placeholder {
      width: 100%;
      height: 170px;
      background: linear-gradient(135deg, var(--accent-light), var(--bg3));
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      color: var(--accent);
    }

    .product-body {
      padding: 0.85rem;
    }

    .product-name {
      font-size: 0.9rem;
      font-weight: 700;
      margin-bottom: 0.25rem;
      line-height: 1.3;
    }

    .product-desc {
      font-size: 0.75rem;
      color: var(--text2);
      margin-bottom: 0.6rem;
      line-height: 1.5;
    }

    .product-price {
      font-size: 1.1rem;
      font-weight: 800;
      color: var(--accent);
      display: flex;
      align-items: center;
      gap: 0.25rem;
      margin-bottom: 0.75rem;
    }

    .product-price-label {
      font-size: 0.72rem;
      color: var(--text3);
      font-weight: 500;
      margin-left: 0.25rem;
    }

    .product-buy-btn {
      width: 100%;
      padding: 0.6rem;
      background: var(--accent);
      color: white;
      border: none;
      border-radius: 10px;
      font-weight: 700;
      font-size: 0.82rem;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
    }

    .product-buy-btn:hover {
      opacity: 0.88;
      transform: translateY(-2px);
      box-shadow: 0 4px 15px rgba(15, 76, 129, 0.35);
    }

    .pro-badge-inline {
      display: inline-flex;
      align-items: center;
      gap: 0.3rem;
      padding: 0.2rem 0.6rem;
      border-radius: 50px;
      background: linear-gradient(135deg, #FFB547, #FF8C00);
      color: white;
      font-size: 0.68rem;
      font-weight: 700;
      position: absolute;
      top: 0.6rem;
      right: 0.6rem;
      z-index: 2;
    }

    /* ===== SIDEBAR WIDGETS ===== */
    .contact-info-card {
      margin-bottom: 1.5rem;
    }

    .contact-info-list {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }

    .contact-info-item {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.75rem 1rem;
      border-radius: 12px;
      background: var(--surface2);
      border: 1px solid var(--border);
      font-size: 0.85rem;
      transition: all 0.2s;
    }

    .contact-info-item:hover {
      border-color: var(--accent);
      transform: translateX(3px);
    }

    .contact-info-icon {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      background: var(--accent-light);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.9rem;
      flex-shrink: 0;
    }

    .contact-info-label {
      font-size: 0.7rem;
      color: var(--text3);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .contact-info-value {
      font-weight: 600;
      color: var(--text);
      font-size: 0.85rem;
      word-break: break-all;
    }

    /* ===== CTA SAVE CONTACT ===== */
    .save-cta-card {
      background: linear-gradient(135deg, var(--accent) 0%, #43D9B4 100%);
      border-radius: 20px;
      padding: 1.5rem;
      text-align: center;
      color: white;
      margin-bottom: 1.5rem;
      box-shadow: 0 8px 30px rgba(15, 76, 129, 0.3);
    }

    .save-cta-card .icon {
      font-size: 2rem;
      margin-bottom: 0.75rem;
    }

    .save-cta-card h3 {
      font-size: 1.1rem;
      font-weight: 800;
      margin-bottom: 0.5rem;
    }

    .save-cta-card p {
      font-size: 0.82rem;
      opacity: 0.9;
      margin-bottom: 1.25rem;
    }

    .save-cta-btn {
      display: block;
      width: 100%;
      padding: 0.8rem;
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: 2px solid rgba(255, 255, 255, 0.5);
      border-radius: 12px;
      font-weight: 700;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.2s;
      backdrop-filter: blur(10px);
    }

    .save-cta-btn:hover {
      background: rgba(255, 255, 255, 0.35);
      transform: translateY(-2px);
    }

    /* ===== POWERED BY ===== */
    .powered-bar {
      text-align: center;
      padding: 2rem 0 1rem;
      font-size: 0.78rem;
      color: var(--text3);
    }

    .powered-bar a {
      color: var(--accent);
      font-weight: 700;
    }

    /* ===== MOBILE RESPONSIVE ===== */
    @media (max-width: 768px) {
      .hero-body {
        grid-template-columns: 1fr;
        gap: 0.5rem;
        padding: 0 1rem;
      }

      .avatar-col {
        display: flex;
        justify-content: center;
      }

      .hero-avatar-wrap {
        margin-top: -60px;
        text-align: center;
      }

      .info-col {
        text-align: center;
        padding-bottom: 0.5rem;
      }

      .hero-name {
        justify-content: center;
      }

      .hero-bio {
        margin: 0 auto;
      }

      .hero-social-icons {
        justify-content: center;
      }

      .contact-bar {
        padding: 0 1rem;
        justify-content: center;
      }

      .action-strip {
        padding: 0 1rem;
        justify-content: center;
      }

      .action-btn-main {
        font-size: 0.82rem;
        padding: 0.65rem 1.2rem;
      }

      .main-container {
        padding: 0.5rem 1rem 5rem;
      }

      .grid-layout {
        grid-template-columns: 1fr;
      }

      .social-links-grid {
        grid-template-columns: repeat(3, 1fr);
      }

      .portfolio-items-grid {
        grid-template-columns: 1fr 1fr;
        gap: 0.75rem;
      }

      .products-grid {
        grid-template-columns: 1fr 1fr;
        gap: 0.75rem;
      }

      .port-img {
        height: 120px;
      }

      .product-img {
        height: 130px;
      }

      .profile-nav .nav-menu {
        display: none;
      }

      .hero-cover {
        height: 180px;
      }

      .hero-avatar,
      .hero-avatar-placeholder {
        width: 90px;
        height: 90px;
        font-size: 2.2rem;
      }
    }

    @media (max-width: 480px) {
      .products-grid {
        grid-template-columns: 1fr;
      }

      .social-links-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .portfolio-items-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>

<body>

  <!-- Sticky Nav -->
  <nav class="profile-nav">
    <div class="nav-brand">
      <?php if ($profilePic): ?>
        <img src="<?= $profilePic ?>" alt="<?= $profileName ?>" class="nav-brand-avatar">
      <?php else: ?>
        <div class="nav-brand-placeholder"><?= strtoupper(substr($profile['name'], 0, 1)) ?></div>
      <?php endif; ?>
      <?= $profileName ?>
    </div>
    <div class="nav-actions">
      <a href="<?= BASE_URL ?>/login" style="color: var(--primary); font-weight: bold;">Login</a>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero-section">
    <!-- Cover -->
    <div class="hero-cover">
      <?php if ($coverPic): ?>
        <img src="<?= $coverPic ?>" alt="Cover">
      <?php else: ?>
        <div class="hero-cover-pattern"></div>
      <?php endif; ?>
      <div class="hero-cover-overlay"></div>
    </div>

    <!-- Profile Info -->
    <div class="hero-body">
      <div class="avatar-col">
        <div class="hero-avatar-wrap">
          <?php if ($profilePic): ?>
            <img src="<?= $profilePic ?>" alt="<?= $profileName ?>" class="hero-avatar">
          <?php else: ?>
            <div class="hero-avatar-placeholder"><?= strtoupper(substr($profile['name'], 0, 1)) ?></div>
          <?php endif; ?>
        </div>
      </div>
      <div class="info-col">
        <h1 class="hero-name">
          <?= $profileName ?>
          <?php if ($profile['is_verified']): ?>
            <i class="fi fi-sr-badge-check" title="Verified"
              style="color: rgb(0, 129, 251); font-size: 0.85em; display: inline-flex;"></i>
          <?php endif; ?>
        </h1>
        <?php if ($bio): ?>
          <p class="hero-bio"><?= $bio ?></p>
        <?php endif; ?>
        <style>
          .hero-social-icons {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 1rem;
            font-size: 0.8rem;
          }

          .hero-social-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 30px;
            height: 30px;
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 1.1rem;
            background: transparent;
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            text-decoration: none;
          }

          .hero-social-btn:hover {
            background: var(--hover-color, var(--primary));
            color: #ffffffff;
            border-color: var(--hover-color, var(--primary));
            transform: translateY(-4px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
          }
        </style>
        <div class="hero-social-icons">
          <?php if (!empty($profile['address'])): ?>
            <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($profile['address']) ?>"
              target="_blank" class="hero-social-btn" title="<?= htmlspecialchars($profile['address']) ?>"
              style="--hover-color: #ea4335;"><i class="fas fa-map-marker-alt" style="font-size: 0.8rem;"></i></a>
          <?php endif; ?>
          <?php if (!empty($profile['website'])): ?>
            <a href="<?= htmlspecialchars($profile['website']) ?>" target="_blank" class="hero-social-btn" title="Website"
              style="--hover-color: #007bff;"><i class="fas fa-globe" style="font-size: 0.8rem;"></i></a>
          <?php endif; ?>
          <?php if ($email): ?>
            <a href="mailto:<?= $email ?>" class="hero-social-btn" title="Email" style="--hover-color: #ea4335;"><i
                class="fas fa-envelope" style="font-size: 0.8rem;"></i></a>
          <?php endif; ?>
          <?php if ($phone && ($profile['show_phone'] ?? 1)): ?>
            <a href="tel:<?= preg_replace('/[^\+\d]/', '', $phone) ?>" class="hero-social-btn" title="Call"
              style="--hover-color: #00a884;"><i class="fas fa-phone" style="font-size: 0.8rem;"></i></a>
          <?php endif; ?>
          <?php if ($whatsapp): ?>
            <a href="https://wa.me/<?= preg_replace('/[^\+\d]/', '', $whatsapp) ?>" target="_blank"
              class="hero-social-btn" title="WhatsApp" style="--hover-color: #25D366;"><i class="fab fa-whatsapp"
                style="font-size: 0.8rem;"></i></a>
          <?php endif; ?>
          <?php if (!empty($links)): ?>
            <?php foreach ($links as $link):
              $color = getSocialColor($link['platform']);
              $icon = $link['icon'] ?: getSocialIcon($link['platform']);
              ?>
              <a href="<?= BASE_URL ?>/api/track_click.php?id=<?= $link['id'] ?>&u=<?= urlencode($link['url']) ?>"
                target="_blank" class="hero-social-btn" title="<?= htmlspecialchars(ucfirst($link['platform'])) ?>"
                style="--hover-color: <?= $color ?>;">
                <i class="<?= htmlspecialchars($icon) ?>" style="font-size: 0.8rem;"></i>
              </a>
            <?php endforeach; ?>
          <?php endif; ?>
          <a href="<?= BASE_URL ?>/api/generate_vcf.php?u=<?= urlencode($username) ?>" class="hero-social-btn"
            title="Save Contact" style="--hover-color: #FF6584;">
            <i class="fas fa-address-card" style="font-size: 0.8rem;"></i>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Main Content -->
  <div class="main-container">
    <div class="grid-layout">
      <!-- About -->
      <div class="main-col">
        <?php if ($aboutMe): ?>
          <div class="section-card" id="about">
            <div class="section-header">
              <div class="section-title">About</div>
            </div>
            <div class="section-body">
              <div style="color:var(--text-secondary);">
                <?= $aboutMe ?>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <!-- Portfolio -->
        <?php if (!empty($items)): ?>
          <div class="section-card" id="portfolio">
            <div class="section-header">
              <div class="section-title">Portfolio</div>
            </div>
            <div class="section-body">
              <div class="portfolio-items-grid">
                <?php foreach ($items as $item): ?>
                  <div class="port-item-card">
                    <?php if ($item['image_path']): ?>
                      <img src="<?= UPLOAD_URL ?>portfolio/<?= htmlspecialchars($item['image_path']) ?>"
                        alt="<?= htmlspecialchars($item['title']) ?>" class="port-img">
                    <?php elseif ($item['video_url']): ?>
                      <?php
                      preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^\&\s]+)/', $item['video_url'], $m);
                      $ytId = $m[1] ?? '';
                      ?>
                      <?php if ($ytId): ?>
                        <div class="video-wrap">
                          <iframe src="https://www.youtube.com/embed/<?= htmlspecialchars($ytId) ?>" allowfullscreen
                            loading="lazy"></iframe>
                        </div>
                      <?php endif; ?>
                    <?php endif; ?>
                    <div class="port-body">
                      <div class="port-title"><?= htmlspecialchars($item['title']) ?></div>
                      <?php if ($item['description']): ?>
                        <div class="port-desc"><?= htmlspecialchars($item['description']) ?></div>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <!-- Products (Pro Only) -->
        <?php if ($isPro && !empty($products)): ?>
          <div class="section-card" id="products">
            <div class="section-header">
              <div class="section-title">Products &amp; Services</div>
            </div>
            <div class="section-body">
              <div class="products-grid">
                <?php foreach ($products as $prod): ?>
                  <div class="product-card">
                    <div class="product-img-wrap">
                      <?php if ($prod['image_path']): ?>
                        <img src="<?= UPLOAD_URL ?>products/<?= htmlspecialchars($prod['image_path']) ?>"
                          alt="<?= htmlspecialchars($prod['name']) ?>" class="product-img">
                      <?php else: ?>
                        <div class="product-img-placeholder">
                          <i class="fas fa-box-open"></i>
                        </div>
                      <?php endif; ?>
                    </div>
                    <div class="product-body">
                      <div class="product-name"><?= htmlspecialchars($prod['name']) ?></div>
                      <?php if ($prod['description']): ?>
                        <div class="product-desc">
                          <?= htmlspecialchars(substr($prod['description'], 0, 80)) ?>
                          <?= strlen($prod['description']) > 80 ? '...' : '' ?>
                        </div>
                      <?php endif; ?>
                      <div class="product-price">
                        Rs. <?= number_format($prod['price'], 0) ?>
                      </div>
                      <!-- Order Now button -->
                      <button class="product-buy-btn"
                        onclick="openOrderModal(<?= $prod['id'] ?>, '<?= addslashes(htmlspecialchars($prod['name'], ENT_QUOTES)) ?>', <?= $prod['price'] ?>)">
                        <i class="fas fa-shopping-bag"></i> Order Now
                      </button>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </div>

      <!-- Sidebar Column -->
      <div class="sidebar-col">
        <!-- Contact Details Card -->
        <?php if ($email || ($phone && ($profile['show_phone'] ?? 1)) || !empty($profile['address']) || !empty($profile['website']) || !empty($links)): ?>
          <div class="section-card contact-info-card">
            <div class="section-header">
              <div class="section-title">Touch with me</div>
            </div>
            <div class="section-body">
              <div class="contact-info-list">
                <?php if ($email): ?>
                  <a href="mailto:<?= $email ?>" class="contact-info-item">
                    <div class="contact-info-icon"><i class="fas fa-envelope"></i></div>
                    <div>
                      <div class="contact-info-label">Email</div>
                      <div class="contact-info-value"><?= $email ?></div>
                    </div>
                  </a>
                <?php endif; ?>
                <?php if (!empty($profile['address'])): ?>
                  <div class="contact-info-item">
                    <div class="contact-info-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <div>
                      <div class="contact-info-label">Location</div>
                      <div class="contact-info-value"><?= htmlspecialchars($profile['address']) ?></div>
                    </div>
                  </div>
                <?php endif; ?>
                <?php if (!empty($profile['website'])): ?>
                  <a href="<?= htmlspecialchars($profile['website']) ?>" target="_blank" class="contact-info-item">
                    <div class="contact-info-icon"><i class="fas fa-globe"></i></div>
                    <div>
                      <div class="contact-info-label">Website</div>
                      <div class="contact-info-value"><?= htmlspecialchars($profile['website']) ?></div>
                    </div>
                  </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <!-- Quick Links (sidebar) on desktop -->
        <?php if (!empty($links)): ?>
          <div class="section-card" style="display:none;" id="sidebar-links">
            <div class="section-header">
              <div class="section-icon"><i class="fas fa-share-nodes"></i></div>
              <div class="section-title">Quick Links</div>
            </div>
            <div class="section-body">
              <?php foreach ($links as $link):
                $color = getSocialColor($link['platform']);
                $icon = $link['icon'] ?: getSocialIcon($link['platform']);
                ?>
                <a href="<?= BASE_URL ?>/api/track_click.php?id=<?= $link['id'] ?>&u=<?= urlencode($link['url']) ?>"
                  target="_blank"
                  style="display:flex;align-items:center;gap:0.75rem;padding:0.65rem 0.5rem;border-radius:10px;font-size:0.85rem;font-weight:600;color:var(--text2);margin-bottom:0.4rem;transition:all 0.2s;"
                  onmouseover="this.style.color='<?= $color ?>';this.style.paddingLeft='0.75rem'"
                  onmouseout="this.style.color='var(--text2)';this.style.paddingLeft='0.5rem'">
                  <span
                    style="width:32px;height:32px;border-radius:9px;background:<?= $color ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;color:white;font-size:0.9rem;">
                    <i class="<?= htmlspecialchars($icon) ?>"></i>
                  </span>
                  <?= htmlspecialchars(ucfirst($link['platform'])) ?>
                </a>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Powered By -->
    <div class="powered-bar">
      <div style="margin-bottom: 0.6rem; font-size: 0.85rem; color: var(--text2);">
        Copyrights &copy; <?= date("Y") ?> &bull; <a href="<?= BASE_URL ?>" target="_blank"
          style="color: var(--text2); text-decoration: none;"><?= SITE_NAME ?></a>
      </div>
      <div style="display: flex; justify-content: center; align-items: center; gap: 0.6rem; opacity: 0.65;">
        <a href="<?= BASE_URL ?>/privacy"
          style="color: var(--text3); text-decoration: none; border-bottom: 1px dotted var(--text3); padding-bottom: 2px; font-size: 0.8rem;">Privacy
          Policy</a>
        <a href="<?= BASE_URL ?>/terms"
          style="color: var(--text3); text-decoration: none; border-bottom: 1px dotted var(--text3); padding-bottom: 2px; font-size: 0.8rem;">Terms
          of Use</a>
        <a href="mailto:info@dipeshbham.com.np"
          style="color: var(--text3); text-decoration: none; border-bottom: 1px dotted var(--text3); padding-bottom: 2px; font-size: 0.8rem;">Report</a>
        <span style="color: var(--text3); font-size: 0.8rem; margin: 0 0.2rem;">&bull;</span>
        <div style="display: flex; gap: 0.6rem; font-size: 0.85rem; align-items: center;">
          <a href="https://facebook.com/kharrayoo4" target="_blank"
            style="color: var(--text3); transition: color 0.2s; border-bottom: 1px dotted var(--text3); padding-bottom: 2px; display: inline-flex; align-items: center; height: 16px;">
            <i class="fab fa-facebook" style="font-size: 0.95rem;"></i>
          </a>
          <a href="https://instagram.com/kharayoo_official" target="_blank"
            style="color: var(--text3); transition: color 0.2s; border-bottom: 1px dotted var(--text3); padding-bottom: 2px; display: inline-flex; align-items: center; height: 16px;">
            <i class="fab fa-instagram" style="font-size: 0.95rem;"></i>
          </a>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Share profile
    function shareProfile() {
      const url = '<?= $cardUrl ?>';
      const title = '<?= $profileName ?>';
      if (navigator.share) {
        navigator.share({ title, url }).catch(() => copyToClipboard(url));
      } else {
        copyToClipboard(url);
      }
    }

    function copyToClipboard(text) {
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
          showToast('Link copied to clipboard!');
        });
      } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showToast('Link copied!');
      }
    }

    function showToast(msg) {
      const t = document.createElement('div');
      t.textContent = msg;
      t.style.cssText = 'position:fixed;bottom:2rem;left:50%;transform:translateX(-50%);background:#1a1a35;color:#fff;padding:0.75rem 1.5rem;border-radius:50px;font-size:0.85rem;font-weight:600;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,0.3);animation:fadein 0.3s ease';
      document.body.appendChild(t);
      setTimeout(() => t.remove(), 2500);
    }

    // Navbar scroll effect
    window.addEventListener('scroll', () => {
      const nav = document.querySelector('.profile-nav');
      if (window.scrollY > 40) {
        nav.style.boxShadow = '0 4px 20px rgba(0,0,0,0.15)';
      } else {
        nav.style.boxShadow = 'none';
      }
    });

    // Animate elements on scroll
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.section-card').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      observer.observe(el);
    });

  </script>

  <!-- ===== ORDER MODAL ===== -->
  <style>
    .om-overlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.55);
      backdrop-filter: blur(6px);
      z-index: 9000;
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }

    .om-overlay.om-show {
      display: flex !important;
    }

    .om-box {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 20px;
      width: 100%;
      max-width: 480px;
      max-height: 92vh;
      overflow-y: auto;
      box-shadow: 0 24px 70px rgba(0, 0, 0, 0.3);
      animation: omSlide 0.28s cubic-bezier(.22, .61, .36, 1);
    }

    @keyframes omSlide {
      from {
        opacity: 0;
        transform: translateY(30px) scale(0.97);
      }

      to {
        opacity: 1;
        transform: translateY(0) scale(1);
      }
    }

    .om-head {
      padding: 1.25rem 1.5rem;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: var(--surface2);
      border-radius: 20px 20px 0 0;
      position: sticky;
      top: 0;
      z-index: 2;
    }

    .om-title {
      font-size: 1rem;
      font-weight: 800;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: var(--text);
    }

    .om-close {
      background: none;
      border: none;
      font-size: 1.1rem;
      cursor: pointer;
      color: var(--text2);
      padding: 0.3rem;
      border-radius: 6px;
      transition: color 0.2s;
    }

    .om-close:hover {
      color: #dc3545;
    }

    .om-body {
      padding: 1.5rem;
    }

    .om-product-info {
      display: flex;
      align-items: center;
      gap: 0.85rem;
      padding: 0.85rem 1rem;
      border-radius: 12px;
      background: var(--surface2);
      border: 1px solid var(--border);
      margin-bottom: 1.25rem;
    }

    .om-product-icon {
      width: 42px;
      height: 42px;
      border-radius: 10px;
      background: var(--accent-light);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      flex-shrink: 0;
    }

    .om-product-name {
      font-weight: 700;
      font-size: 0.9rem;
      color: var(--text);
    }

    .om-product-price {
      font-size: 0.82rem;
      color: var(--text2);
    }

    .om-group {
      margin-bottom: 1rem;
    }

    .om-label {
      display: block;
      font-size: 0.82rem;
      font-weight: 600;
      color: var(--text);
      margin-bottom: 0.35rem;
    }

    .om-input,
    .om-textarea {
      display: block;
      width: 100%;
      padding: 0.7rem 1rem;
      border: 1.5px solid var(--border);
      border-radius: 10px;
      font-size: 0.9rem;
      font-family: inherit;
      color: var(--text);
      background: var(--surface2);
      outline: none;
      transition: border-color 0.2s, box-shadow 0.2s;
      box-sizing: border-box;
    }

    .om-input:focus,
    .om-textarea:focus {
      border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.12);
    }

    .om-textarea {
      resize: vertical;
      min-height: 80px;
    }

    .om-grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
    }

    @media(max-width:400px) {
      .om-grid-2 {
        grid-template-columns: 1fr;
      }
    }

    .om-foot {
      padding: 1rem 1.5rem;
      border-top: 1px solid var(--border);
      display: flex;
      gap: 0.75rem;
      justify-content: flex-end;
      background: var(--surface2);
      border-radius: 0 0 20px 20px;
    }

    .om-btn-cancel {
      padding: 0.6rem 1.25rem;
      border-radius: 10px;
      border: 1px solid var(--border);
      background: none;
      color: var(--text2);
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }

    .om-btn-cancel:hover {
      background: var(--surface);
    }

    .om-btn-order {
      padding: 0.6rem 1.5rem;
      border-radius: 10px;
      border: none;
      background: var(--accent);
      color: white;
      font-size: 0.875rem;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      transition: transform 0.2s, box-shadow 0.2s, opacity 0.2s;
    }

    .om-btn-order:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 14px rgba(108, 99, 255, 0.35);
    }

    .om-btn-order:disabled {
      opacity: 0.65;
      cursor: not-allowed;
      transform: none;
    }
  </style>

  <div class="om-overlay" id="omOverlay" onclick="if(event.target===this)closeOrderModal()">
    <div class="om-box">
      <div class="om-head">
        <span class="om-title"><i class="fas fa-shopping-bag" style="color:var(--accent);"></i> Place Order</span>
        <button class="om-close" onclick="closeOrderModal()"><i class="fas fa-times"></i></button>
      </div>
      <div class="om-body">
        <div class="om-product-info">
          <div class="om-product-icon"><i class="fas fa-box-open"></i></div>
          <div>
            <div class="om-product-name" id="omProductName">—</div>
            <div class="om-product-price" id="omProductPrice">Rs. 0</div>
          </div>
        </div>

        <div class="om-grid-2">
          <div class="om-group">
            <label class="om-label" for="omName">Your Name <span style="color:#dc3545;">*</span></label>
            <input type="text" id="omName" class="om-input" placeholder="Full name" autocomplete="off">
          </div>
          <div class="om-group">
            <label class="om-label" for="omQty">Quantity <span style="color:#dc3545;">*</span></label>
            <input type="number" id="omQty" class="om-input" value="1" min="1" max="999">
          </div>
        </div>

        <div class="om-grid-2">
          <div class="om-group">
            <label class="om-label" for="omPhone">Phone</label>
            <input type="tel" id="omPhone" class="om-input" placeholder="+977XXXXXXXXXX" autocomplete="off">
          </div>
          <div class="om-group">
            <label class="om-label" for="omEmail">Email</label>
            <input type="email" id="omEmail" class="om-input" placeholder="your@email.com" autocomplete="off">
          </div>
        </div>

        <div class="om-group">
          <label class="om-label" for="omNote">Note / Special Request</label>
          <textarea id="omNote" class="om-textarea"
            placeholder="Any specific requirements, delivery address, etc."></textarea>
        </div>
        <div id="omError" style="color:#dc3545;font-size:0.82rem;margin-top:0.25rem;display:none;"></div>
      </div>
      <div class="om-foot">
        <button class="om-btn-cancel" onclick="closeOrderModal()">Cancel</button>
        <button class="om-btn-order" id="omSubmitBtn" onclick="submitOrder()">
          <i class="fas fa-check"></i> <span id="omBtnText">Confirm Order</span>
        </button>
      </div>
    </div>
  </div>

  <script>
    var _omProductId = null;
    var _omUnitPrice = 0;

    function openOrderModal(productId, productName, unitPrice) {
      _omProductId = productId;
      _omUnitPrice = parseFloat(unitPrice);
      document.getElementById('omProductName').textContent = productName;
      document.getElementById('omProductPrice').textContent = 'Rs. ' + Math.round(_omUnitPrice).toLocaleString();
      document.getElementById('omName').value = '';
      document.getElementById('omQty').value = '1';
      document.getElementById('omPhone').value = '';
      document.getElementById('omEmail').value = '';
      document.getElementById('omNote').value = '';
      document.getElementById('omError').style.display = 'none';
      document.getElementById('omSubmitBtn').disabled = false;
      document.getElementById('omBtnText').textContent = 'Confirm Order';
      document.getElementById('omOverlay').classList.add('om-show');
      setTimeout(function () { document.getElementById('omName').focus(); }, 80);
    }

    function closeOrderModal() {
      document.getElementById('omOverlay').classList.remove('om-show');
    }

    function submitOrder() {
      var name = document.getElementById('omName').value.trim();
      var qty = parseInt(document.getElementById('omQty').value) || 1;
      var phone = document.getElementById('omPhone').value.trim();
      var email = document.getElementById('omEmail').value.trim();
      var note = document.getElementById('omNote').value.trim();
      var errEl = document.getElementById('omError');

      if (!name) {
        errEl.textContent = 'Please enter your name.';
        errEl.style.display = 'block';
        document.getElementById('omName').focus();
        return;
      }
      if (qty < 1) { qty = 1; }

      errEl.style.display = 'none';
      var btn = document.getElementById('omSubmitBtn');
      btn.disabled = true;
      document.getElementById('omBtnText').textContent = 'Placing order…';

      var fd = new FormData();
      fd.append('product_id', _omProductId);
      fd.append('buyer_name', name);
      fd.append('buyer_phone', phone);
      fd.append('buyer_email', email);
      fd.append('quantity', qty);
      fd.append('note', note);

      fetch('<?= BASE_URL ?>/api/place_order.php', { method: 'POST', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (data.success) {
            closeOrderModal();
            var sellerWa = "<?= $whatsapp ? preg_replace('/[^\+\d]/', '', $whatsapp) : '' ?>";
            if (sellerWa) {
              showToast('✅ Order placed! Opening WhatsApp to notify seller...');
              var productName = document.getElementById('omProductName').textContent;
              var text = "Hello! I just placed an order on your profile.\n\n*Product:* " + productName + "\n*Quantity:* " + qty + "\n\n*My Details*\nName: " + name + "\nPhone: " + phone + (note ? "\nNote: " + note : "");
              var waUrl = "https://wa.me/" + sellerWa + "?text=" + encodeURIComponent(text);
              setTimeout(function () {
                window.open(waUrl, '_blank');
              }, 1000);
            } else {
              showToast('✅ Order placed! The seller will contact you soon.');
            }
          } else {
            errEl.textContent = data.error || 'Something went wrong. Please try again.';
            errEl.style.display = 'block';
            btn.disabled = false;
            document.getElementById('omBtnText').textContent = 'Confirm Order';
          }
        })
        .catch(function () {
          errEl.textContent = 'Network error. Please try again.';
          errEl.style.display = 'block';
          btn.disabled = false;
          document.getElementById('omBtnText').textContent = 'Confirm Order';
        });
    }
  </script>

</body>

</html>