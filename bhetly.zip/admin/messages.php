<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

// Handle status updates and deletion
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($_GET['action'] === 'read') {
        $pdo->prepare("UPDATE contact_messages SET status='read' WHERE id=?")->execute([$id]);
    } elseif ($_GET['action'] === 'delete') {
        $pdo->prepare("DELETE FROM contact_messages WHERE id=?")->execute([$id]);
    }
    redirect(BASE_URL . '/admin/messages');
}

// Fetch messages
$stmt = $pdo->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
$messages = $stmt->fetchAll();

$unreadCount = $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE status='new'")->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title"><i class="fas fa-envelope" style="color:var(--primary);"></i> Contact Messages</h2>
    <p class="page-subtitle">View and respond to inquiries from the public site.</p>
  </div>

  <div class="card-box">
    <div class="card-box-header">
      <span class="card-box-title">All Messages (<?= $unreadCount ?> unread)</span>
    </div>
    
    <div class="table-responsive">
      <table class="table-custom">
        <thead>
          <tr>
            <th>Status</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($messages)): ?>
          <tr><td colspan="6" style="text-align:center;padding:2rem;">No messages found.</td></tr>
          <?php else: ?>
          <?php foreach ($messages as $msg): ?>
          <tr style="<?= $msg['status'] === 'new' ? 'background: rgba(108, 99, 255, 0.05); font-weight: 600;' : '' ?>">
            <td>
              <?php if ($msg['status'] === 'new'): ?>
                <span class="badge badge-warning">New</span>
              <?php else: ?>
                <span class="badge badge-secondary">Read</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($msg['first_name'] . ' ' . $msg['last_name']) ?></td>
            <td><a href="mailto:<?= htmlspecialchars($msg['email']) ?>" style="color:var(--primary);"><?= htmlspecialchars($msg['email']) ?></a></td>
            <td><div style="max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?= htmlspecialchars($msg['message']) ?>"><?= nl2br(htmlspecialchars($msg['message'])) ?></div></td>
            <td><span style="color:var(--text-secondary);font-size:0.85rem;"><?= date('M d, Y h:i A', strtotime($msg['created_at'])) ?></span></td>
            <td>
              <?php if ($msg['status'] === 'new'): ?>
                <a href="?action=read&id=<?= $msg['id'] ?>" class="btn btn-secondary btn-icon btn-sm" title="Mark as Read"><i class="fas fa-check"></i></a>
              <?php endif; ?>
              <a href="?action=delete&id=<?= $msg['id'] ?>" class="btn btn-secondary btn-icon btn-sm" style="color:var(--danger);" onclick="return confirm('Delete this message?')" title="Delete"><i class="fas fa-trash"></i></a>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
