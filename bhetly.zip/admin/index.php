<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

// Stats
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$activeToday = $pdo->query("SELECT COUNT(DISTINCT user_id) FROM analytics WHERE visit_date = CURDATE()")->fetchColumn();
$proUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE plan='pro'")->fetchColumn();
$pendingSubs    = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status='pending'")->fetchColumn();
$totalCards     = $pdo->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$totalViews     = $pdo->query("SELECT SUM(visit_count) FROM analytics")->fetchColumn() ?? 0;
// Recent signups
$recentUsers   = $pdo->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 8")->fetchAll();

// Chart - signups per day last 14 days
$signupChart = $pdo->query("SELECT DATE(created_at) as day, COUNT(*) as cnt FROM users WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) GROUP BY day ORDER BY day")->fetchAll();
$cLabels = []; $cValues = [];
for ($i=13; $i>=0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $cLabels[] = date('M d', strtotime($d));
    $f = array_filter($signupChart, fn($r) => $r['day'] === $d);
    $cValues[] = !empty($f) ? (int)array_values($f)[0]['cnt'] : 0;
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title"><i class="fas fa-shield-halved" style="color:var(--primary);"></i> Admin Dashboard</h2>
    <p class="page-subtitle">Platform overview and management</p>
  </div>

  <!-- Stats -->
  <div class="row g-3 mb-4">
    <?php
    $unreadMessages = $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE status='new'")->fetchColumn();
    $cards_data = [
      ['Total Users', $totalUsers, 'users', '#6C63FF', 'fas fa-users'],
      ['Unread Messages', $unreadMessages, '', '#FFB547', 'fas fa-envelope'],
      ['Total Views', number_format($totalViews), '', '#43D9B4', 'fas fa-eye'],
      ['Active Today', $activeToday, '', '#FF6584', 'fas fa-activity'],
      ['NFC Cards', $totalCards, '', '#4FC3F7', 'fas fa-credit-card'],
    ];
    foreach ($cards_data as [$label, $val, $unit, $color, $icon]):
    ?>
    <div class="col-sm-6 col-xl-4 col-xxl-2">
      <div class="stat-card" style="--stat-color:<?= $color ?>;">
        <div class="stat-icon" style="background:<?= $color ?>22;color:<?= $color ?>;"><i class="<?= $icon ?>"></i></div>
        <div class="stat-value"><?= $val ?></div>
        <div class="stat-label"><?= $label ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="row g-3">
    <!-- Signup Chart -->
    <div class="col-12">
      <div class="card-box">
        <div class="card-box-header"><span class="card-box-title">New Signups - Last 14 Days</span></div>
        <div class="chart-container">
          <canvas id="visitChart" data-labels='<?= json_encode($cLabels) ?>' data-values='<?= json_encode($cValues) ?>'></canvas>
        </div>
      </div>
    </div>

    <!-- Recent Users -->
    <div class="col-12">
      <div class="card-box">
        <div class="card-box-header">
          <span class="card-box-title">Recent Users</span>
          <a href="<?= BASE_URL ?>/admin/users" class="btn btn-secondary btn-sm">View All</a>
        </div>
        <div style="overflow-x:auto;">
          <table class="table-custom">
            <thead>
              <tr>
                <th>User</th><th>Username</th><th>Plan</th><th>Joined</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recentUsers as $u): ?>
              <tr>
                <td>
                  <div style="display:flex;align-items:center;gap:0.75rem;">
                    <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;color:white;"><?= strtoupper(substr($u['name'],0,1)) ?></div>
                    <div>
                      <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($u['name']) ?></div>
                      <div style="color:var(--text-muted);font-size:0.75rem;"><?= htmlspecialchars($u['email']) ?></div>
                    </div>
                  </div>
                </td>
                <td><code style="color:var(--primary);font-size:0.82rem;">@<?= htmlspecialchars($u['username']) ?></code></td>
                <td><span class="badge badge-<?= $u['plan'] === 'pro' ? 'warning' : 'secondary' ?>"><?= ucfirst($u['plan']) ?></span></td>
                <td style="color:var(--text-secondary);font-size:0.82rem;"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                <td>
                  <a href="<?= BASE_URL ?>/<?= htmlspecialchars($u['username']) ?>" target="_blank" class="btn btn-secondary btn-icon btn-sm"><i class="fas fa-external-link-alt"></i></a>
                  <a href="<?= BASE_URL ?>/admin/users?edit=<?= $u['id'] ?>" class="btn btn-secondary btn-icon btn-sm"><i class="fas fa-edit"></i></a>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
