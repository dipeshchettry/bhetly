<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

// Orders page removed from admin access for privacy reasons.
redirect(BASE_URL . '/admin/index');
?>
