<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $subId  = intval($_POST['sub_id'] ?? 0);
    $uid    = intval($_POST['user_id'] ?? 0);

    $msg    = sanitize($_POST['admin_message'] ?? '');

    if ($action === 'approve' && $subId && $uid) {
        $pdo->prepare("UPDATE subscriptions SET status='approved', admin_message=?, expires_at=DATE_ADD(CURDATE(), INTERVAL 1 YEAR) WHERE id=?")->execute([$msg, $subId]);
        $pdo->prepare("UPDATE users SET plan='pro', plan_expires_at=DATE_ADD(CURDATE(), INTERVAL 1 YEAR) WHERE id=?")->execute([$uid]);
        setFlash('success', 'Subscription approved! User plan upgraded to Pro.');
    } elseif ($action === 'reject' && $subId) {
        $pdo->prepare("UPDATE subscriptions SET status='rejected', admin_message=? WHERE id=?")->execute([$msg, $subId]);
        setFlash('error', 'Subscription rejected.');
    } else {
        setFlash('error', 'Unknown action.');
    }
    redirect(BASE_URL . '/admin/subscriptions');
}

$status = sanitize($_GET['status'] ?? '');
$where  = $status ? "WHERE s.status='$status'" : "";
$subs   = $pdo->query("SELECT s.*, u.name, u.email, u.username FROM subscriptions s JOIN users u ON s.user_id = u.id $where ORDER BY s.created_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Subscription Management</h2>
    <p class="page-subtitle">Review and approve payment submissions</p>
  </div>

  <div style="display:flex;justify-content:space-between;flex-wrap:wrap;align-items:center;margin-bottom:1.5rem;gap:1rem;">
    <!-- Filter Tabs -->
    <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
      <?php foreach ([''=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$v): ?>
      <a href="?status=<?= $k ?>" class="btn <?= $status===$k ? 'btn-primary' : 'btn-secondary' ?> btn-sm"><?= $v ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="card-box">
    <?php if (empty($subs)): ?>
    <p style="text-align:center;color:var(--text-muted);padding:2rem;">No subscriptions found.</p>
    <?php else: ?>
    <div style="overflow-x:auto;">
      <table class="table-custom">
        <thead>
          <tr><th>User</th><th>Method</th><th>Txn ID</th><th>Amount</th><th>Screenshot</th><th>Status</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($subs as $s): ?>
          <tr>
            <td>
              <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($s['name']) ?></div>
              <div style="color:var(--text-muted);font-size:0.75rem;"><?= htmlspecialchars($s['email']) ?></div>
            </td>
            <td><span class="badge badge-info"><?= ucfirst($s['payment_method']) ?></span></td>
            <td><code style="font-size:0.8rem;"><?= htmlspecialchars($s['transaction_id'] ?: '—') ?></code></td>
            <td style="font-weight:700;">Rs <?= number_format($s['amount']) ?></td>
            <td>
              <?php if ($s['screenshot_path']): ?>
              <a href="<?= UPLOAD_URL ?>payments/<?= htmlspecialchars($s['screenshot_path']) ?>" target="_blank" class="btn btn-secondary btn-sm">
                <i class="fas fa-image"></i> View
              </a>
              <?php else: ?>
              <span style="color:var(--text-muted);">—</span>
              <?php endif; ?>
            </td>
            <td>
              <span class="badge badge-<?= $s['status'] === 'approved' ? 'success' : ($s['status'] === 'pending' ? 'warning' : 'danger') ?>">
                <?= ucfirst($s['status']) ?>
              </span>
            </td>
            <td style="color:var(--text-secondary);font-size:0.8rem;"><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
            <td>
              <?php if ($s['status'] === 'pending'): ?>
              <div style="display:flex;gap:0.5rem;flex-direction:column;">
                <form method="POST">
                  <input type="hidden" name="action" value="approve">
                  <input type="hidden" name="sub_id" value="<?= $s['id'] ?>">
                  <input type="hidden" name="user_id" value="<?= $s['user_id'] ?>">
                  <input type="text" name="admin_message" class="form-control" style="margin-bottom:0.25rem;font-size:0.75rem;padding:0.25rem;" placeholder="Optional approval message">
                  <button type="submit" class="btn btn-success btn-sm" style="width:100%;"><i class="fas fa-check"></i> Approve</button>
                </form>
                <form method="POST">
                  <input type="hidden" name="action" value="reject">
                  <input type="hidden" name="sub_id" value="<?= $s['id'] ?>">
                  <input type="text" name="admin_message" class="form-control" style="margin-bottom:0.25rem;font-size:0.75rem;padding:0.25rem;" placeholder="Reason for rejection">
                  <button type="submit" class="btn btn-danger btn-sm" style="width:100%;"><i class="fas fa-times"></i> Reject</button>
                </form>
              </div>
              <?php else: ?>
                <span class="badge badge-<?= $s['status'] === 'approved' ? 'success' : 'danger' ?>"><?= ucfirst($s['status']) ?></span>
                <?php if ($s['admin_message']): ?>
                  <div style="font-size:0.75rem;color:var(--text-muted);margin-top:0.25rem;max-width:150px;"><i>"<?= htmlspecialchars($s['admin_message']) ?>"</i></div>
                <?php endif; ?>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
