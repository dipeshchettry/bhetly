<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $uid    = intval($_POST['user_id'] ?? 0);

    if ($action === 'delete' && $uid) {
      if ($uid === (int) ($_SESSION['user_id'] ?? 0)) {
        setFlash('error', 'You cannot delete your own admin account from this panel.');
      } else {
        try {
          $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'admin'");
          $stmt->execute([$uid]);

          if ($stmt->rowCount() > 0) {
            setFlash('success', 'User deleted.');
          } else {
            setFlash('error', 'User not found or admin users cannot be deleted.');
          }
        } catch (Throwable $e) {
          setFlash('error', 'Unable to delete user right now. Please try again.');
        }
      }
    } elseif ($action === 'toggle_active' && $uid) {
        $pdo->prepare("UPDATE users SET is_active = 1 - is_active WHERE id = ?")->execute([$uid]);
        setFlash('success', 'User status updated.');
    } elseif ($action === 'toggle_approval' && $uid) {
        $pdo->prepare("UPDATE users SET is_verified = 1 - is_verified WHERE id = ?")->execute([$uid]);
      setFlash('success', 'User approval status updated.');
    } elseif ($action === 'set_plan' && $uid) {
        $plan = in_array($_POST['plan'] ?? '', ['free','pro']) ? $_POST['plan'] : 'free';
        $duration = intval($_POST['duration'] ?? 0);
        $expiresAt = '';
        if ($plan === 'pro' && $duration > 0) {
            $expiresAt = date('Y-m-d', strtotime("+$duration days"));
            $pdo->prepare("UPDATE users SET plan = ?, plan_expires_at = ? WHERE id = ?")->execute([$plan, $expiresAt, $uid]);
        } else {
            $pdo->prepare("UPDATE users SET plan = ?, plan_expires_at = NULL WHERE id = ?")->execute([$plan, $uid]);
        }
        setFlash('success', 'Plan updated to ' . ucfirst($plan) . ($expiresAt ? " (expires: $expiresAt)" : '') . '.');
    } elseif ($action === 'edit_save' && $uid) {
        $name  = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $pdo->prepare("UPDATE users SET name=?, email=? WHERE id=?")->execute([$name, $email, $uid]);
        setFlash('success', 'User updated.');
    }
    redirect(BASE_URL . '/admin/users');
}

// Search / filter
$search = sanitize($_GET['q'] ?? '');
$plan   = in_array($_GET['plan'] ?? '', ['free','pro','']) ? ($_GET['plan'] ?? '') : '';
$page   = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where = "WHERE role != 'admin'";
$params = [];
if ($search) { $where .= " AND (name LIKE ? OR email LIKE ? OR username LIKE ?)"; $params = array_fill(0, 3, "%$search%"); }
if ($plan)   { $where .= " AND plan = ?"; $params[] = $plan; }

$total = $pdo->prepare("SELECT COUNT(*) FROM users $where"); $total->execute($params); $total = $total->fetchColumn();
$users = $pdo->prepare("SELECT u.*, p.profile_picture FROM users u LEFT JOIN profiles p ON u.id = p.user_id $where ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset");
$users->execute($params); $users = $users->fetchAll();
$pages = ceil($total / $perPage);

// Edit user modal data
$editUser = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $s->execute([intval($_GET['edit'])]);
    $editUser = $s->fetch();
}

include __DIR__ . '/../includes/header.php';

$pendingApprovals = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user' AND is_verified = 0")->fetchColumn();
?>

<div class="page-content">
  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
    <div>
      <h2 class="page-title">User Management</h2>
      <p class="page-subtitle"><?= number_format($total) ?> total users Ã¢â‚¬Â¢ <?= number_format((int) $pendingApprovals) ?> pending approvals</p>
    </div>
  </div>

  <!-- Filters -->
  <div class="card-box mb-3">
    <form method="GET" style="display:flex;gap:0.75rem;flex-wrap:wrap;align-items:flex-end;">
      <div style="flex:1;min-width:200px;">
        <label class="form-label">Search</label>
        <div class="input-group">
          <i class="fas fa-search input-icon"></i>
          <input type="text" name="q" class="form-control" placeholder="Name, email, username..." value="<?= htmlspecialchars($search) ?>">
        </div>
      </div>
      <div>
        <label class="form-label">Plan</label>
        <select name="plan" class="form-control">
          <option value="">All Plans</option>
          <option value="free" <?= $plan === 'free' ? 'selected' : '' ?>>Free</option>
          <option value="pro" <?= $plan === 'pro' ? 'selected' : '' ?>>Pro</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Filter</button>
      <a href="<?= BASE_URL ?>/admin/users" class="btn btn-secondary">Reset</a>
    </form>
  </div>

  <!-- Users Table -->
  <div class="card-box">
    <div style="overflow-x:auto;">
      <table class="table-custom">
        <thead>
          <tr><th>#</th><th>User</th><th>Username</th><th>Plan</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($users as $i => $u): ?>
          <tr>
            <td style="color:var(--text-muted);"><?= $offset + $i + 1 ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:0.75rem;">
                <?php if ($u['profile_picture']): ?>
                <img src="<?= UPLOAD_URL ?>profiles/<?= htmlspecialchars($u['profile_picture']) ?>" style="width:34px;height:34px;border-radius:50%;object-fit:cover;">
                <?php else: ?>
                <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;color:white;"><?= strtoupper(substr($u['name'],0,1)) ?></div>
                <?php endif; ?>
                <div>
                  <div style="font-weight:600;font-size:0.88rem;"><?= htmlspecialchars($u['name']) ?></div>
                  <div style="color:var(--text-muted);font-size:0.75rem;"><?= htmlspecialchars($u['email']) ?></div>
                </div>
              </div>
            </td>
            <td><code style="color:var(--primary);font-size:0.82rem;">@<?= htmlspecialchars($u['username']) ?></code></td>
            <td>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="set_plan">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <select name="plan" onchange="this.form.submit()" class="form-control" style="padding:0.3rem 0.5rem;font-size:0.78rem;width:auto;">
                  <option value="free" <?= $u['plan'] === 'free' ? 'selected' : '' ?>>Free</option>
                  <option value="pro" <?= $u['plan'] === 'pro' ? 'selected' : '' ?>>Pro</option>
                </select>
              </form>
              <?php if ($u['plan'] === 'pro' && isset($u['plan_expires_at']) && $u['plan_expires_at']): ?>
              <div style="font-size:0.75rem;color:var(--text-muted);margin-top:0.25rem;">Expires: <?= date('M d, Y', strtotime($u['plan_expires_at'])) ?></div>
              <?php endif; ?>
            </td>
            <td>
              <form method="POST" style="display:inline-block; margin-bottom:5px;">
                <input type="hidden" name="action" value="toggle_active">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button type="submit" class="badge badge-<?= $u['is_active'] ? 'success' : 'danger' ?>" style="border:none;cursor:pointer;background:none;padding:0;">
                  <?= $u['is_active'] ? 'Active' : 'Suspended' ?>
                </button>
              </form>
              <br>
              <form method="POST" style="display:inline-block;">
                <input type="hidden" name="action" value="toggle_approval">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button type="submit" class="badge badge-<?= $u['is_verified'] ? 'info' : 'secondary' ?>" style="border:none;cursor:pointer;background:none;padding:0;">
                  <?= $u['is_verified'] ? '<i class="fas fa-check-circle"></i> Approved' : 'Pending Approval' ?>
                </button>
              </form>
            </td>
            <td style="color:var(--text-secondary);font-size:0.82rem;"><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
            <td>
              <a href="<?= BASE_URL ?>/<?= htmlspecialchars($u['username']) ?>" target="_blank" class="btn btn-secondary btn-icon btn-sm" title="View Card"><i class="fas fa-external-link-alt"></i></a>
              <a href="?edit=<?= $u['id'] ?>" class="btn btn-secondary btn-icon btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this user? This cannot be undone.')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <button type="submit" class="btn btn-danger btn-icon btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($users)): ?>
          <tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:2rem;">No users found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if ($pages > 1): ?>
    <div style="display:flex;justify-content:center;gap:0.5rem;margin-top:1.5rem;flex-wrap:wrap;">
      <?php for ($p = 1; $p <= $pages; $p++): ?>
      <a href="?page=<?= $p ?>&q=<?= urlencode($search) ?>&plan=<?= $plan ?>" class="btn <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?> btn-sm"><?= $p ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Edit User Modal -->
<?php if ($editUser): ?>
<div class="modal-overlay show" id="editUserModal">
  <div class="modal-dialog">
    <div class="modal-header">
      <span class="modal-title">Edit User</span>
      <a href="<?= BASE_URL ?>/admin/users" class="btn-close-modal"><i class="fas fa-times"></i></a>
    </div>
    <div class="modal-body">
      <form method="POST">
        <input type="hidden" name="action" value="edit_save">
        <input type="hidden" name="user_id" value="<?= $editUser['id'] ?>">
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editUser['name']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editUser['email']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" class="form-control" value="@<?= htmlspecialchars($editUser['username']) ?>" disabled style="opacity:0.5;">
          <small style="color:var(--text-muted);font-size:0.78rem;">Username cannot be changed here.</small>
        </div>
        <div class="form-group">
          <label class="form-label">Plan</label>
          <select name="plan" id="planSelect" class="form-control">
            <option value="free" <?= $editUser['plan'] === 'free' ? 'selected' : '' ?>>Free</option>
            <option value="pro" <?= $editUser['plan'] === 'pro' ? 'selected' : '' ?>>Pro</option>
          </select>
        </div>
        <div class="form-group" id="durationGroup" style="display:<?= $editUser['plan'] === 'pro' ? 'block' : 'none' ?>;">
          <label class="form-label">Plan Duration (days)</label>
          <input type="number" name="duration" class="form-control" min="1" max="3650" placeholder="e.g., 365 for 1 year" value="">
          <small style="color:var(--text-muted);font-size:0.78rem;">Leave empty for unlimited or change plan only.</small>
        </div>
        <div class="modal-footer" style="padding:0;border:none;margin-top:1.5rem;">
          <a href="<?= BASE_URL ?>/admin/users" class="btn btn-secondary">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// Show/hide duration field based on plan selection
if (document.getElementById('planSelect')) {
  const planSelect = document.getElementById('planSelect');
  const durationGroup = document.getElementById('durationGroup');
  planSelect.addEventListener('change', function() {
    durationGroup.style.display = this.value === 'pro' ? 'block' : 'none';
  });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
