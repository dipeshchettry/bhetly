﻿<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $cardId = intval($_POST['card_id'] ?? 0);

    if ($action === 'create') {
        $uid  = sanitize($_POST['card_uid'] ?? '');
        $label = sanitize($_POST['card_label'] ?? '');
        $userId = intval($_POST['user_id'] ?? 0) ?: null;
        if ($uid) {
            try {
                $pdo->prepare("INSERT INTO cards (card_uid, card_label, user_id, assigned_at) VALUES (?, ?, ?, ?)")
                    ->execute([$uid, $label, $userId, $userId ? date('Y-m-d H:i:s') : null]);
                setFlash('success', 'NFC Card created!');
            } catch (PDOException $e) {
                setFlash('error', 'Card UID already exists.');
            }
        }
    } elseif ($action === 'assign' && $cardId) {
        $userId = intval($_POST['user_id'] ?? 0) ?: null;
        $pdo->prepare("UPDATE cards SET user_id=?, assigned_at=? WHERE id=?")->execute([$userId, $userId ? date('Y-m-d H:i:s') : null, $cardId]);
        setFlash('success', 'Card assignment updated.');
    } elseif ($action === 'toggle' && $cardId) {
        $pdo->prepare("UPDATE cards SET is_active = 1 - is_active WHERE id=?")->execute([$cardId]);
        setFlash('success', 'Card status toggled.');
    } elseif ($action === 'delete' && $cardId) {
        $pdo->prepare("DELETE FROM cards WHERE id=?")->execute([$cardId]);
        setFlash('success', 'Card deleted.');
    }
    redirect(BASE_URL . '/admin/cards');
}

$cards = $pdo->query("SELECT c.*, u.name as user_name, u.username FROM cards c LEFT JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC")->fetchAll();
$users = $pdo->query("SELECT id, name, username FROM users WHERE role='user' AND is_active=1 ORDER BY name")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
    <div>
      <h2 class="page-title">NFC Card Management</h2>
      <p class="page-subtitle">Assign NFC card UIDs to users</p>
    </div>
    <button class="btn btn-primary" data-modal="createCardModal"><i class="fas fa-plus"></i> Create Card</button>
  </div>

  <div class="card-box">
    <div style="overflow-x:auto;">
      <table class="table-custom">
        <thead>
          <tr><th>Card UID</th><th>Label</th><th>Assigned To</th><th>Redirect URL</th><th>Status</th><th>Assigned At</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($cards as $c): ?>
          <tr>
            <td><code style="color:var(--primary);font-size:0.82rem;"><?= htmlspecialchars($c['card_uid']) ?></code></td>
            <td style="font-size:0.85rem;"><?= htmlspecialchars($c['card_label'] ?: 'â€”') ?></td>
            <td>
              <?php if ($c['user_name']): ?>
              <div style="font-weight:600;font-size:0.85rem;"><?= htmlspecialchars($c['user_name']) ?></div>
              <div style="color:var(--text-muted);font-size:0.75rem;">@<?= htmlspecialchars($c['username']) ?></div>
              <?php else: ?><span style="color:var(--text-muted);">Unassigned</span><?php endif; ?>
            </td>
            <td>
              <code style="font-size:0.77rem;color:var(--text-secondary);"><?= BASE_URL ?>/card.php?id=<?= htmlspecialchars($c['card_uid']) ?></code>
              <button class="btn btn-secondary btn-icon btn-sm" data-copy="<?= BASE_URL ?>/card.php?id=<?= htmlspecialchars($c['card_uid']) ?>" style="margin-left:0.25rem;"><i class="fas fa-copy"></i></button>
            </td>
            <td><span class="badge badge-<?= $c['is_active'] ? 'success' : 'danger' ?>"><?= $c['is_active'] ? 'Active' : 'Inactive' ?></span></td>
            <td style="font-size:0.8rem;color:var(--text-secondary);"><?= $c['assigned_at'] ? date('M d, Y', strtotime($c['assigned_at'])) : 'â€”' ?></td>
            <td>
              <button class="btn btn-secondary btn-icon btn-sm" onclick="openAssign(<?= $c['id'] ?>, <?= $c['user_id'] ?? 'null' ?>)" title="Assign User"><i class="fas fa-user-plus"></i></button>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
                <button type="submit" class="btn btn-secondary btn-icon btn-sm" title="Toggle"><i class="fas fa-power-off"></i></button>
              </form>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this card?')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
                <button type="submit" class="btn btn-danger btn-icon btn-sm"><i class="fas fa-trash"></i></button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($cards)): ?>
          <tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:2rem;">No NFC cards yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Create Card Modal -->
<div class="modal-overlay" id="createCardModal">
  <div class="modal-dialog">
    <div class="modal-header"><span class="modal-title">Create NFC Card</span><button class="btn-close-modal" data-close-modal><i class="fas fa-times"></i></button></div>
    <div class="modal-body">
      <form method="POST">
        <input type="hidden" name="action" value="create">
        <div class="form-group">
          <label class="form-label">Card UID *</label>
          <input type="text" name="card_uid" class="form-control" placeholder="e.g. NFC-001, or UUID from card" required>
        </div>
        <div class="form-group">
          <label class="form-label">Label (optional)</label>
          <input type="text" name="card_label" class="form-control" placeholder="e.g. Blue Card #1">
        </div>
        <div class="form-group">
          <label class="form-label">Assign to User (optional)</label>
          <select name="user_id" class="form-control">
            <option value="">-- Unassigned --</option>
            <?php foreach ($users as $u): ?>
            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?> (@<?= htmlspecialchars($u['username']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="modal-footer" style="padding:0;border:none;margin-top:1.5rem;">
          <button type="button" class="btn btn-secondary" data-close-modal>Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Create</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Assign User Modal -->
<div class="modal-overlay" id="assignModal">
  <div class="modal-dialog">
    <div class="modal-header"><span class="modal-title">Assign Card to User</span><button class="btn-close-modal" data-close-modal><i class="fas fa-times"></i></button></div>
    <div class="modal-body">
      <form method="POST">
        <input type="hidden" name="action" value="assign">
        <input type="hidden" name="card_id" id="assignCardId">
        <div class="form-group">
          <label class="form-label">Select User</label>
          <select name="user_id" id="assignUserId" class="form-control">
            <option value="">-- Unassign --</option>
            <?php foreach ($users as $u): ?>
            <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?> (@<?= htmlspecialchars($u['username']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="modal-footer" style="padding:0;border:none;margin-top:1.5rem;">
          <button type="button" class="btn btn-secondary" data-close-modal>Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fas fa-user-check"></i> Assign</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openAssign(cardId, currentUserId) {
  document.getElementById('assignCardId').value = cardId;
  if (currentUserId) document.getElementById('assignUserId').value = currentUserId;
  document.getElementById('assignModal').classList.add('show');
}
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
