<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$currentAdmin = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  if ($action === 'update_email' && $currentAdmin) {
    $newEmail = sanitize($_POST['email'] ?? '');
    if ($newEmail && $newEmail !== $currentAdmin['email']) {
      // Check if email already exists
      $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND id != ?");
      $check->execute([$newEmail, $_SESSION['user_id']]);
      if ($check->fetchColumn() > 0) {
        setFlash('error', 'Email already in use by another account.');
      } else {
        $pdo->prepare("UPDATE users SET email = ? WHERE id = ?")->execute([$newEmail, $_SESSION['user_id']]);
        setFlash('success', 'Email updated successfully!');
      }
    } else {
      setFlash('error', 'Please enter a valid email address.');
    }
    redirect(BASE_URL . '/admin/settings');
  } elseif ($action === 'upload_qr') {
    $type = $_POST['qr_type'] ?? '';
    $file = $_FILES['qr_image'] ?? null;
    if (in_array($type, ['esewa', 'khalti']) && $file && $file['error'] === UPLOAD_ERR_OK) {
      $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
      if (in_array($ext, ['png', 'jpg', 'jpeg'])) {
        move_uploaded_file($file['tmp_name'], UPLOAD_PATH . "payments/{$type}-qr.png");
        setFlash('success', ucfirst($type) . ' QR Updated Successfully!');
      } else {
        setFlash('error', 'Invalid image format. PNG/JPG only.');
      }
    } else {
      setFlash('error', 'Upload failed. Please provide a valid QR image.');
    }
    redirect(BASE_URL . '/admin/settings');
  }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-content">
  <div class="page-header">
    <h2 class="page-title">Admin Settings</h2>
    <p class="page-subtitle">Manage payment QR codes and admin account</p>
  </div>

  <!-- Admin Account Settings -->
  <div class="row g-4 mb-4">
    <div class="col-lg-6">
      <div class="card-box">
        <div class="card-box-header">
          <span class="card-box-title"><i class="fas fa-user-circle"></i> Admin Account</span>
        </div>
        <form method="POST">
          <input type="hidden" name="action" value="update_email">
          <div class="form-group">
            <label class="form-label">Current Email</label>
            <input type="email" class="form-control" value="<?= htmlspecialchars($currentAdmin['email'] ?? '') ?>"
              disabled style="opacity:0.7;">
          </div>
          <div class="form-group">
            <label class="form-label">New Email Address</label>
            <input type="email" name="email" class="form-control" placeholder="Enter new email address" required>
          </div>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Email</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Payment QR Settings -->
  <?php foreach (['esewa' => ['title' => 'eSewa', 'color' => '#60BB46'], 'khalti' => ['title' => 'Khalti', 'color' => '#5C2D91']] as $key => $data): ?>
    <div class="col-md-6">
      <div class="card-box" style="border-top: 4px solid <?= $data['color'] ?>;">
        <div class="card-box-header">
          <span class="card-box-title" style="color:<?= $data['color'] ?>; font-size:1.2rem; font-weight:800;">
            <?= $key === 'esewa' ? '<i class="fas fa-wallet"></i>' : '<i class="fas fa-mobile-alt"></i>' ?>
            <?= $data['title'] ?> QR Code
          </span>
        </div>

        <div style="display:flex; gap:1.5rem; align-items:center;">
          <!-- Current QR Display -->
          <div style="flex-shrink:0;">
            <?php if (file_exists(UPLOAD_PATH . "payments/{$key}_qr.png")): ?>
              <img src="<?= UPLOAD_URL ?>payments/<?= $key ?>_qr.png?<?= time() ?>"
                style="width:140px; height:140px; object-fit:contain; border-radius:12px; border:2px solid var(--border); background:white; padding:0.5rem;">
            <?php else: ?>
              <div
                style="width:140px; height:140px; background:var(--border); border-radius:12px; display:flex; align-items:center; justify-content:center; color:var(--text-muted); font-weight:600; text-align:center;">
                No QR<br>Uploaded</div>
            <?php endif; ?>
          </div>

          <!-- Upload Form -->
          <div style="flex-grow:1;">
            <form method="POST" enctype="multipart/form-data">
              <input type="hidden" name="action" value="upload_qr">
              <input type="hidden" name="qr_type" value="<?= $key ?>">

              <div class="form-group mb-3">
                <label class="form-label text-muted" style="font-size:0.85rem;">Upload new <?= $data['title'] ?>
                  code</label>
                <input type="file" name="qr_image" class="form-control form-control-sm" accept="image/png, image/jpeg"
                  required>
              </div>
              <button type="submit" class="btn btn-primary btn-sm"
                style="background:<?= $data['color'] ?>; border-color:<?= $data['color'] ?>; width:100%;">
                <i class="fas fa-upload"></i> Upload & Save
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>